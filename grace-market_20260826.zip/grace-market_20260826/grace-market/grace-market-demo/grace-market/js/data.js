/* ============================================================
   은혜마켓 · Mock Seed Data
   Schema field names match the production Mongoose design doc.
   ============================================================ */

const SEED_USERS = [
  {
    _id: 'u_admin', name: '관리자', phone: '010-0000-0000', email: 'admin@grace.demo',
    churchName: '은혜마켓 운영팀', churchRole: '목회자',
    isVerified: true, faithScore: 99, reviewCount: 0, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T08:00:00Z', role: 'ADMIN',
    createdAt: '2026-01-01T00:00:00Z'
  },
  {
    _id: 'u_1', name: '김은혜', phone: '010-1111-1111', email: 'eunhye@demo.kr',
    churchName: '서초사랑교회', churchRole: '성도',
    isVerified: true, faithScore: 42.5, reviewCount: 18, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T07:50:00Z',
    createdAt: '2026-02-15T00:00:00Z'
  },
  {
    _id: 'u_2', name: '박평강', phone: '010-2222-2222', email: 'pyeonggang@demo.kr',
    churchName: '서초사랑교회', churchRole: '성도',
    isVerified: true, faithScore: 38.0, reviewCount: 9, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T07:55:00Z',
    createdAt: '2026-03-04T00:00:00Z'
  },
  {
    _id: 'u_3', name: '이찬양', phone: '010-3333-3333', email: 'chanyang@demo.kr',
    churchName: '강남은혜교회', churchRole: '교역자',
    isVerified: true, faithScore: 45.0, reviewCount: 24, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T08:00:00Z',
    createdAt: '2026-02-28T00:00:00Z'
  },
  {
    _id: 'u_4', name: '최기도', phone: '010-4444-4444', email: 'gido@demo.kr',
    churchName: '강남은혜교회', churchRole: '성도',
    isVerified: false, faithScore: 36.5, reviewCount: 0, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T07:30:00Z',
    createdAt: '2026-08-20T00:00:00Z'
  },
  {
    _id: 'u_5', name: '정성경', phone: '010-5555-5555', email: 'sungkyung@demo.kr',
    churchName: '역삼동 신약성서교회', churchRole: '성도',
    isVerified: true, faithScore: 39.5, reviewCount: 5, reportCount: 0,
    fcmTokens: [], lastSeenAt: '2026-08-26T07:20:00Z',
    createdAt: '2026-04-12T00:00:00Z'
  }
];

const SEED_PRODUCTS = [
  {
    _id: 'p_1', seller: 'u_1',
    title: '찬양용 통기타 (통기타+케이스) 무료나눔',
    description: '주일 찬양팀에서 사용하던 통기타입니다. 상태 양호하며 줄만 새로 교체하면 됩니다.\n케이스와 함께 드려요. 직접 거래 원칙으로 교회 1층 로비에서 만나요.',
    price: 0, isFree: true,
    category: '악기/음향', condition: '사용감있음',
    images: [
      'https://images.unsplash.com/photo-1525201548942-d8732f6617a0?w=600',
      'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=600'
    ],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0276, 37.4979] },
    addressName: '서울 서초구 서초동',
    tradePlace: '서초사랑교회 1층 로비',
    geohash: 'wydme',
    viewCount: 124, likeCount: 18,
    createdAt: '2026-08-25T09:30:00Z'
  },
  {
    _id: 'p_2', seller: 'u_2',
    title: '강해설 주석 성경 (창세기~사사기) 4권 세트',
    description: '목회 준비에 사용했던 강해설 주석 4권 세트입니다. 필기 흔적 약간 있어요. 나눔합니다.',
    price: 0, isFree: true,
    category: '교재/서적', condition: '사용감있음',
    images: ['https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600'],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0301, 37.4969] },
    addressName: '서울 서초구 서초동',
    geohash: 'wydme',
    viewCount: 87, likeCount: 12,
    createdAt: '2026-08-25T14:20:00Z'
  },
  {
    _id: 'p_3', seller: 'u_3',
    title: '찬양 인디언 베이스 + 앰프 일괄 판매',
    description: '찬양팀에서 사용한 인디언 베이스와 50W 앰프 세트입니다. 교회 음향용으로 최고!',
    price: 250000, isFree: false,
    category: '악기/음향', condition: '거의새것',
    images: [
      'https://images.unsplash.com/photo-1564186763535-ebb21ef5277f?w=600',
      'https://images.unsplash.com/photo-1485579149621-3123dd979885?w=600'
    ],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0495, 37.5052] },
    addressName: '서울 강남구 역삼동',
    tradePlace: '강남은혜교회 지하 연습실',
    geohash: 'wydm8',
    viewCount: 215, likeCount: 32,
    createdAt: '2026-08-24T16:45:00Z'
  },
  {
    _id: 'p_4', seller: 'u_5',
    title: '아기용 예배 가방 (무료나눔)',
    description: '아기가 더 이상 안 써서 나눔합니다. 상태 깨끗합니다.',
    price: 0, isFree: true,
    category: '의류/잡화', condition: '거의새것',
    images: ['https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600'],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0364, 37.5012] },
    addressName: '서울 강남구 역삼동',
    geohash: 'wydm8',
    viewCount: 56, likeCount: 8,
    createdAt: '2026-08-25T20:10:00Z'
  },
  {
    _id: 'p_5', seller: 'u_1',
    title: '소형 PA 스피커 1대 (8인치)',
    description: '소규모 모임용 PA 스피커입니다. 8인치 한 대만 판매합니다. 블루투스/SD/USB 지원.',
    price: 80000, isFree: false,
    category: '가전/가구', condition: '사용감있음',
    images: ['https://images.unsplash.com/photo-1545454675-3531b543be5d?w=600'],
    status: '예약중',
    location: { type: 'Point', coordinates: [127.0276, 37.4979] },
    addressName: '서울 서초구 서초동',
    geohash: 'wydme',
    viewCount: 142, likeCount: 15,
    createdAt: '2026-08-23T11:00:00Z'
  },
  {
    _id: 'p_6', seller: 'u_2',
    title: '예배용 성경책 (개역개정, 가죽 커버)',
    description: '예배 시 사용하던 성경책입니다. 가죽 커버 포함, 밑줄 없음.',
    price: 15000, isFree: false,
    category: '성경/기도', condition: '거의새것',
    images: ['https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=600'],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0301, 37.4969] },
    addressName: '서울 서초구 서초동',
    geohash: 'wydme',
    viewCount: 73, likeCount: 9,
    createdAt: '2026-08-26T01:30:00Z'
  },
  {
    _id: 'p_7', seller: 'u_3',
    title: '주일학교 교재 100권 (3-6세)',
    description: '주일학교에서 사용했던 3-6세용 교재 100권 일괄 판매합니다. 깨끗한 상태.',
    price: 50000, isFree: false,
    category: '교재/서적', condition: '거의새것',
    images: [
      'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600',
      'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600'
    ],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0495, 37.5052] },
    addressName: '서울 강남구 역삼동',
    geohash: 'wydm8',
    viewCount: 198, likeCount: 24,
    createdAt: '2026-08-22T08:15:00Z'
  },
  {
    _id: 'p_8', seller: 'u_5',
    title: '찬양용 마이크 2개 일괄 (무선)',
    description: '주일 찬양팀에서 사용한 무선 마이크 2개 세트. 배터리·충전기 포함.',
    price: 120000, isFree: false,
    category: '악기/음향', condition: '사용감있음',
    images: ['https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=600'],
    status: '판매중',
    location: { type: 'Point', coordinates: [127.0364, 37.5012] },
    addressName: '서울 강남구 역삼동',
    geohash: 'wydm8',
    viewCount: 91, likeCount: 11,
    createdAt: '2026-08-26T03:00:00Z'
  }
];

const SEED_CHAT_ROOMS = [
  {
    _id: 'c_1', product: 'p_1', buyer: 'u_2', seller: 'u_1',
    status: '대화중',
    lastMessage: '언제 만나볼 수 있을까요?',
    lastMessageAt: '2026-08-26T07:30:00Z',
    unreadCount: { buyer: 0, seller: 1 },
    createdAt: '2026-08-25T10:00:00Z'
  },
  {
    _id: 'c_2', product: 'p_3', buyer: 'u_1', seller: 'u_3',
    status: '거래예약',
    lastMessage: '주일 오후 2시에 교회에서 뵐게요 🙏',
    lastMessageAt: '2026-08-25T19:45:00Z',
    unreadCount: { buyer: 0, seller: 0 },
    createdAt: '2026-08-24T17:00:00Z'
  }
];

const SEED_MESSAGES = {
  c_1: [
    { _id: 'm_1', room: 'c_1', sender: 'u_2', type: 'text', content: '안녕하세요, 통기타 아직 있나요?', readBy: ['u_2','u_1'], createdAt: '2026-08-25T10:00:00Z' },
    { _id: 'm_2', room: 'c_1', sender: 'u_1', type: 'text', content: '네, 아직 있어요! 누구세요?', readBy: ['u_2','u_1'], createdAt: '2026-08-25T10:05:00Z' },
    { _id: 'm_3', room: 'c_1', sender: 'u_2', type: 'text', content: '서초사랑교회 박평강입니다. 찬양팀에서 쓰려고요.', readBy: ['u_2','u_1'], createdAt: '2026-08-25T10:08:00Z' },
    { _id: 'm_4', room: 'c_1', sender: 'u_1', type: 'text', content: '아 반갑네요! 같은 교회 성도님이에요.', readBy: ['u_2','u_1'], createdAt: '2026-08-25T10:15:00Z' },
    { _id: 'm_5', room: 'c_1', sender: 'u_2', type: 'text', content: '언제 만나볼 수 있을까요?', readBy: ['u_2'], createdAt: '2026-08-26T07:30:00Z' }
  ],
  c_2: [
    { _id: 'm_6', room: 'c_2', sender: 'u_1', type: 'text', content: '베이스 세트 아직 있나요?', readBy: ['u_1','u_3'], createdAt: '2026-08-24T17:00:00Z' },
    { _id: 'm_7', room: 'c_2', sender: 'u_3', type: 'text', content: '네! 주일 찬양팀용으로 쓰시는 거예요?', readBy: ['u_1','u_3'], createdAt: '2026-08-24T17:05:00Z' },
    { _id: 'm_8', room: 'c_2', sender: 'u_1', type: 'text', content: '맞아요. 직접 보고 거래하고 싶어요.', readBy: ['u_1','u_3'], createdAt: '2026-08-25T09:00:00Z' },
    { _id: 'm_9', room: 'c_2', sender: 'u_3', type: 'system', content: '🤝 거래가 예약되었습니다', readBy: ['u_1','u_3'], createdAt: '2026-08-25T19:30:00Z' },
    { _id: 'm_10', room: 'c_2', sender: 'u_3', type: 'text', content: '주일 오후 2시에 교회에서 뵐게요 🙏', readBy: ['u_1','u_3'], createdAt: '2026-08-25T19:45:00Z' }
  ]
};

const SEED_VERIFICATIONS = [
  {
    _id: 'v_1', user: 'u_4', churchName: '강남은혜교회',
    documentType: '교적부', documentUrl: 'demo://church_doc_001.jpg',
    contactPhone: '010-4444-4444',
    status: '대기', reviewedBy: null, reviewedAt: null, rejectReason: null,
    expiresAt: null,
    createdAt: '2026-08-25T12:00:00Z'
  },
  {
    _id: 'v_2', user: 'u_5', churchName: '역삼동 신약성서교회',
    documentType: '주보사진', documentUrl: 'demo://church_doc_002.jpg',
    contactPhone: '010-5555-5555',
    status: '승인', reviewedBy: 'u_admin', reviewedAt: '2026-04-10T10:00:00Z', rejectReason: null,
    expiresAt: '2027-04-10T00:00:00Z',
    createdAt: '2026-04-08T09:00:00Z'
  }
];

const SEED_REPORTS = [
  {
    _id: 'r_1', reporter: 'u_2', targetType: 'Product', target: 'p_7',
    reason: '스팸', description: '같은 물품을 여러 번 중복 등록한 것 같습니다.',
    status: '접수', handledBy: null, handledAt: null,
    createdAt: '2026-08-25T22:10:00Z'
  },
  {
    _id: 'r_2', reporter: 'u_4', targetType: 'User', target: 'u_5',
    reason: '기타', description: '약속 시간에 나타나지 않았어요.',
    status: '처리완료', handledBy: 'u_admin', handledAt: '2026-08-26T02:00:00Z',
    createdAt: '2026-08-24T18:30:00Z'
  }
];

window.GM_DATA = {
  SEED_USERS, SEED_PRODUCTS, SEED_CHAT_ROOMS, SEED_MESSAGES,
  SEED_VERIFICATIONS, SEED_REPORTS
};