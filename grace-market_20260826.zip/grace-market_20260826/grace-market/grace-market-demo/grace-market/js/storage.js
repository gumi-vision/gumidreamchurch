/* ============================================================
   Storage layer (mocks MongoDB + Mongoose in localStorage)
   Schema mirrors the production design doc.
   ============================================================ */

const GM_KEYS = {
  USERS: 'gm.users',
  PRODUCTS: 'gm.products',
  CHAT_ROOMS: 'gm.chatRooms',
  MESSAGES: 'gm.messages',
  VERIFICATIONS: 'gm.verifications',
  REPORTS: 'gm.reports',
  LIKES: 'gm.likes',
  SESSION: 'gm.session',
  THEME: 'gm.theme',
  SEEDED: 'gm.seeded.v2'
};

function _read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
function _write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function _id(prefix) {
  return prefix + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

function seedIfEmpty() {
  if (localStorage.getItem(GM_KEYS.SEEDED)) return;
  // A schema bump re-seeds; drop the previous marker so it can't accumulate.
  localStorage.removeItem('gm.seeded.v1');
  _write(GM_KEYS.USERS, [...window.GM_DATA.SEED_USERS]);
  _write(GM_KEYS.PRODUCTS, [...window.GM_DATA.SEED_PRODUCTS]);
  _write(GM_KEYS.CHAT_ROOMS, [...window.GM_DATA.SEED_CHAT_ROOMS]);
  _write(GM_KEYS.MESSAGES, window.GM_DATA.SEED_MESSAGES);
  _write(GM_KEYS.VERIFICATIONS, [...window.GM_DATA.SEED_VERIFICATIONS]);
  _write(GM_KEYS.REPORTS, [...window.GM_DATA.SEED_REPORTS]);
  _write(GM_KEYS.LIKES, {});
  localStorage.setItem(GM_KEYS.SEEDED, '1');
}

const Store = {
  /* Users */
  listUsers() { return _read(GM_KEYS.USERS, []); },
  getUser(id) { return this.listUsers().find(u => u._id === id); },
  getUserByPhone(phone) { return this.listUsers().find(u => u.phone === phone); },
  createUser(u) {
    const users = this.listUsers();
    const newU = {
      _id: _id('u'), role: 'USER',
      faithScore: 36.5, reviewCount: 0, reportCount: 0,
      fcmTokens: [], createdAt: new Date().toISOString(),
      isVerified: false, ...u
    };
    users.push(newU); _write(GM_KEYS.USERS, users); return newU;
  },
  updateUser(id, patch) {
    const users = this.listUsers();
    const idx = users.findIndex(u => u._id === id);
    if (idx < 0) return null;
    users[idx] = { ...users[idx], ...patch };
    _write(GM_KEYS.USERS, users);
    return users[idx];
  },
  upsertByPhone(phone, payload) {
    const existing = this.getUserByPhone(phone);
    if (existing) return existing;
    return this.createUser(payload);
  },

  /* Products */
  listProducts() { return _read(GM_KEYS.PRODUCTS, []); },
  getProduct(id) { return this.listProducts().find(p => p._id === id); },
  createProduct(p) {
    const products = this.listProducts();
    const newP = {
      _id: _id('p'),
      viewCount: 0, likeCount: 0, status: '판매중',
      createdAt: new Date().toISOString(),
      location: { type: 'Point', coordinates: [127.0276, 37.4979] },
      ...p
    };
    products.unshift(newP); _write(GM_KEYS.PRODUCTS, products); return newP;
  },
  updateProduct(id, patch) {
    const products = this.listProducts();
    const idx = products.findIndex(p => p._id === id);
    if (idx < 0) return null;
    products[idx] = { ...products[idx], ...patch };
    _write(GM_KEYS.PRODUCTS, products);
    return products[idx];
  },
  deleteProduct(id) {
    _write(GM_KEYS.PRODUCTS, this.listProducts().filter(p => p._id !== id));
  },
  incrementView(id) {
    const p = this.getProduct(id); if (!p) return;
    this.updateProduct(id, { viewCount: (p.viewCount || 0) + 1 });
  },

  /* Chat */
  listRooms() { return _read(GM_KEYS.CHAT_ROOMS, []); },
  getRoom(id) { return this.listRooms().find(r => r._id === id); },
  findRoomByProductAndBuyer(productId, buyerId) {
    return this.listRooms().find(r => r.product === productId && r.buyer === buyerId);
  },
  createRoom(r) {
    const rooms = this.listRooms();
    const newR = {
      _id: _id('c'),
      status: '대화중',
      lastMessageAt: new Date().toISOString(),
      unreadCount: { buyer: 0, seller: 0 },
      createdAt: new Date().toISOString(),
      ...r
    };
    rooms.unshift(newR); _write(GM_KEYS.CHAT_ROOMS, rooms); return newR;
  },
  updateRoom(id, patch) {
    const rooms = this.listRooms();
    const idx = rooms.findIndex(r => r._id === id);
    if (idx < 0) return null;
    rooms[idx] = { ...rooms[idx], ...patch };
    _write(GM_KEYS.CHAT_ROOMS, rooms);
    return rooms[idx];
  },
  listMessages() { return _read(GM_KEYS.MESSAGES, {}); },
  getMessages(roomId) {
    const all = this.listMessages(); return all[roomId] || [];
  },
  pushMessage(roomId, msg) {
    const all = this.listMessages();
    if (!all[roomId]) all[roomId] = [];
    const m = {
      _id: _id('m'),
      room: roomId, type: 'text', readBy: [msg.sender],
      createdAt: new Date().toISOString(), ...msg
    };
    all[roomId].push(m); _write(GM_KEYS.MESSAGES, all);
    return m;
  },
  markRead(roomId, userId) {
    const all = this.listMessages();
    const msgs = (all[roomId] || []).map(m =>
      m.readBy.includes(userId) ? m : { ...m, readBy: [...m.readBy, userId] }
    );
    all[roomId] = msgs; _write(GM_KEYS.MESSAGES, all);
    const room = this.getRoom(roomId);
    if (room) {
      const key = room.buyer === userId ? 'buyer' : 'seller';
      this.updateRoom(roomId, { unreadCount: { ...room.unreadCount, [key]: 0 } });
    }
  },

  /* Verifications */
  listVerifications() { return _read(GM_KEYS.VERIFICATIONS, []); },
  createVerification(v) {
    const list = this.listVerifications();
    const newV = {
      _id: _id('v'), status: '대기',
      createdAt: new Date().toISOString(), ...v
    };
    list.unshift(newV); _write(GM_KEYS.VERIFICATIONS, list);
    return newV;
  },
  updateVerification(id, patch) {
    const list = this.listVerifications();
    const idx = list.findIndex(v => v._id === id);
    if (idx < 0) return null;
    list[idx] = { ...list[idx], ...patch };
    _write(GM_KEYS.VERIFICATIONS, list);
    return list[idx];
  },

  /* Likes (찜) — kept per user so the count survives across sessions */
  _likeMap() { return _read(GM_KEYS.LIKES, {}); },
  likedIds(userId) {
    if (!userId) return [];
    return this._likeMap()[userId] || [];
  },
  isLiked(productId, userId) {
    return this.likedIds(userId).includes(productId);
  },
  toggleLike(productId, userId) {
    const map = this._likeMap();
    const mine = map[userId] || [];
    const on = mine.includes(productId);
    map[userId] = on ? mine.filter(id => id !== productId) : [...mine, productId];
    _write(GM_KEYS.LIKES, map);

    const p = this.getProduct(productId);
    if (p) {
      const next = Math.max(0, (p.likeCount || 0) + (on ? -1 : 1));
      this.updateProduct(productId, { likeCount: next });
    }
    return !on;
  },
  listLikedProducts(userId) {
    const ids = this.likedIds(userId);
    return this.listProducts().filter(p => ids.includes(p._id));
  },

  /* Reports */
  listReports() { return _read(GM_KEYS.REPORTS, []); },
  createReport(r) {
    const list = this.listReports();
    const newR = { _id: _id('r'), status: '접수', createdAt: new Date().toISOString(), ...r };
    list.unshift(newR); _write(GM_KEYS.REPORTS, list);
    return newR;
  },
  updateReport(id, patch) {
    const list = this.listReports();
    const idx = list.findIndex(r => r._id === id);
    if (idx < 0) return null;
    list[idx] = { ...list[idx], ...patch };
    _write(GM_KEYS.REPORTS, list);
    return list[idx];
  },

  /* Session */
  getSession() { return _read(GM_KEYS.SESSION, null); },
  setSession(userId) {
    if (!userId) localStorage.removeItem(GM_KEYS.SESSION);
    else _write(GM_KEYS.SESSION, { userId, at: Date.now() });
  },
  logout() { this.setSession(null); },

  /* Helpers: distance (Haversine, km) */
  distance(a, b) {
    if (!a || !b) return null;
    const toRad = d => d * Math.PI / 180;
    const R = 6371;
    const dLat = toRad(b[1] - a[1]);
    const dLng = toRad(b[0] - a[0]);
    const lat1 = toRad(a[1]); const lat2 = toRad(b[1]);
    const x = Math.sin(dLat/2)**2 + Math.sin(dLng/2)**2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  },

  /* Faith score adjustments */
  adjustFaith(userId, delta) {
    const u = this.getUser(userId); if (!u) return;
    const next = Math.max(0, Math.min(100, (u.faithScore || 36.5) + delta));
    this.updateUser(userId, { faithScore: next, reviewCount: (u.reviewCount || 0) + 1 });
  },

  /* Reset (for demo) */
  resetAll() {
    Object.values(GM_KEYS).forEach(k => localStorage.removeItem(k));
    seedIfEmpty();
  }
};

window.Store = Store;