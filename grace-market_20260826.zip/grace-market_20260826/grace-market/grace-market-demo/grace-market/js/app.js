/* ============================================================
   은혜마켓 · UI/UX logic (vanilla JS)
   ============================================================ */

const CATEGORY_LABELS = {
  '성경/기도': '📖 성경/기도',
  '악기/음향': '🎵 악기/음향',
  '교재/서적': '📚 교재/서적',
  '의류/잡화': '👕 의류/잡화',
  '가전/가구': '🛋 가전/가구',
  '기타': '📦 기타'
};
const STATUS_LABELS = {
  '판매중': '판매중', '예약중': '예약중', '거래완료': '완료', '숨김': '숨김'
};

/* ---------- Toast ---------- */
function toast(message, type = 'info') {
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = message;
  stack.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

/* ---------- Modal ---------- */
let _modalLastFocus = null;

function _onModalBackdrop(e) {
  if (e.target === e.currentTarget) closeModal();
}
function _onModalKey(e) {
  if (e.key === 'Escape') closeModal();
}

function openModal(html, onMount) {
  const modal = document.getElementById('modal');
  const content = document.getElementById('modalContent');
  if (!modal || !content) return;
  _modalLastFocus = document.activeElement;
  content.innerHTML = html;
  modal.style.display = 'flex';
  // Re-bind every open: a `once` listener would be consumed by the first click
  // *inside* the dialog, silently breaking backdrop-to-close from then on.
  modal.removeEventListener('click', _onModalBackdrop);
  modal.addEventListener('click', _onModalBackdrop);
  document.addEventListener('keydown', _onModalKey);
  if (typeof onMount === 'function') onMount(content);
  const firstField = content.querySelector('input, select, textarea, button');
  if (firstField) firstField.focus();
}
function closeModal() {
  const modal = document.getElementById('modal');
  if (!modal) return;
  modal.style.display = 'none';
  modal.removeEventListener('click', _onModalBackdrop);
  document.removeEventListener('keydown', _onModalKey);
  if (_modalLastFocus && document.contains(_modalLastFocus)) _modalLastFocus.focus();
  _modalLastFocus = null;
}
window.openModal = openModal;
window.closeModal = closeModal;

/* ---------- Theme ---------- */
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const btn = document.getElementById('themeToggle');
  if (btn) {
    btn.textContent = theme === 'dark' ? '☀️' : '🌙';
    btn.setAttribute('aria-label', theme === 'dark' ? '밝은 테마로 전환' : '어두운 테마로 전환');
  }
  localStorage.setItem('gm.theme', theme);
}
function initTheme() {
  const saved = localStorage.getItem('gm.theme');
  const prefersDark = window.matchMedia
    && window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));
  const btn = document.getElementById('themeToggle');
  if (btn) btn.addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    applyTheme(cur === 'light' ? 'dark' : 'light');
  });
}

/* ---------- Session helpers ---------- */
function currentUser() {
  const s = Store.getSession();
  return s ? Store.getUser(s.userId) : null;
}
function requireLogin(redirect = 'login.html') {
  if (!currentUser()) {
    toast('로그인이 필요합니다', 'info');
    setTimeout(() => location.href = redirect, 600);
    return false;
  }
  return true;
}

/* ---------- Header bindings ---------- */
function bindHeader() {
  const me = currentUser();
  const loginLink = document.getElementById('loginLink');
  const logoutBtn = document.getElementById('logoutBtn');
  const adminLink = document.getElementById('adminLink');

  // The mobile bar's last slot is contextual: sign in, admin console, or sign out.
  const mobileAuth = document.getElementById('mobileAuthLink');
  if (mobileAuth) {
    if (me && me.role === 'ADMIN') {
      mobileAuth.href = 'admin.html';
      mobileAuth.innerHTML = '<span class="ico" aria-hidden="true">🛠</span>관리자';
    } else if (me) {
      mobileAuth.removeAttribute('href');
      mobileAuth.style.cursor = 'pointer';
      mobileAuth.innerHTML = '<span class="ico" aria-hidden="true">↪</span>로그아웃';
      mobileAuth.onclick = () => {
        Store.logout(); toast('로그아웃되었습니다', 'info');
        setTimeout(() => location.href = 'index.html', 400);
      };
    }
  }

  if (me) {
    if (loginLink) loginLink.style.display = 'none';
    if (logoutBtn) {
      logoutBtn.style.display = '';
      logoutBtn.onclick = () => {
        Store.logout(); toast('로그아웃되었습니다', 'info');
        setTimeout(() => location.reload(), 400);
      };
    }
    if (adminLink && me.role === 'ADMIN') adminLink.style.display = '';
  } else {
    if (logoutBtn) logoutBtn.style.display = 'none';
    if (loginLink) loginLink.style.display = '';
    if (adminLink) adminLink.style.display = 'none';
  }

  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav a, .mobile-nav a').forEach(a => {
    if (a.getAttribute('href') === path) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    }
  });

  const fab = document.getElementById('fabChat');
  if (fab) {
    fab.onclick = () => {
      if (!requireLogin()) return;
      location.href = 'chat.html';
    };
  }
}

/* ---------- Utilities ---------- */
function formatRelativeTime(iso) {
  const d = new Date(iso); const now = Date.now();
  const diff = Math.floor((now - d.getTime()) / 1000);
  if (diff < 60) return '방금';
  if (diff < 3600) return Math.floor(diff/60) + '분 전';
  if (diff < 86400) return Math.floor(diff/3600) + '시간 전';
  if (diff < 604800) return Math.floor(diff/86400) + '일 전';
  return d.toLocaleDateString('ko-KR');
}
function formatPrice(p) {
  if (p === 0) return '무료나눔';
  return p.toLocaleString('ko-KR') + '원';
}
function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}
function avatarText(name) {
  return (name || '?').trim().charAt(0);
}

/* ---------- Feed (index.html) ---------- */
function renderFeed() {
  const grid = document.getElementById('feedGrid');
  const empty = document.getElementById('emptyState');
  const search = document.getElementById('searchInput').value.trim().toLowerCase();
  const category = document.getElementById('categoryFilter').value;
  const sort = document.getElementById('sortFilter').value;
  const type = document.getElementById('typeFilter').value;
  const radius = Number(document.getElementById('radiusInput').value);

  document.getElementById('radiusLabel').textContent = radius;

  const userLoc = [127.0276, 37.4979];
  const all = Store.listProducts().filter(p => p.status !== '숨김');
  const withDist = all.map(p => ({
    ...p,
    distanceKm: Store.distance(userLoc, p.location?.coordinates) ?? 999
  }));

  let filtered = withDist.filter(p => p.distanceKm <= radius);
  if (search) {
    filtered = filtered.filter(p =>
      p.title.toLowerCase().includes(search) ||
      (p.description || '').toLowerCase().includes(search) ||
      (p.category || '').toLowerCase().includes(search) ||
      (p.addressName || '').toLowerCase().includes(search)
    );
  }
  if (category) filtered = filtered.filter(p => p.category === category);
  if (type === 'free') filtered = filtered.filter(p => p.isFree || p.price === 0);
  if (type === 'paid') filtered = filtered.filter(p => !p.isFree && p.price > 0);

  if (sort === 'distance') filtered.sort((a, b) => a.distanceKm - b.distanceKm);
  else if (sort === 'latest') filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  else if (sort === 'priceAsc') filtered.sort((a, b) => (a.price||0) - (b.price||0));
  else if (sort === 'priceDesc') filtered.sort((a, b) => (b.price||0) - (a.price||0));

  grid.innerHTML = filtered.map(p => productCardHtml(p)).join('');
  empty.style.display = filtered.length === 0 ? '' : 'none';

  const countEl = document.getElementById('resultCount');
  if (countEl) {
    countEl.innerHTML = filtered.length
      ? `반경 ${radius}km 안에 <strong>${filtered.length}</strong>건`
      : '';
  }

  document.getElementById('statProducts').textContent = Store.listProducts().length;
  document.getElementById('statUsers').textContent = Store.listUsers().filter(u => u.role !== 'ADMIN').length;
  document.getElementById('statChurches').textContent =
    new Set(Store.listUsers().filter(u => u.role !== 'ADMIN').map(u => u.churchName)).size;
}

function productCardHtml(p) {
  const seller = Store.getUser(p.seller);
  const dist = p.distanceKm != null ? p.distanceKm.toFixed(1) + 'km' : '';
  const free = p.isFree || p.price === 0;
  const me = currentUser();
  const liked = me ? Store.isLiked(p._id, me._id) : false;
  return `
    <article class="product-card">
      <div class="img-wrap">
        <img src="${escapeHtml(p.images?.[0] || '')}" alt="${escapeHtml(p.title)}"
             loading="lazy" decoding="async"
             onerror="this.style.visibility='hidden'" />
        ${free ? '<span class="badge-free">무료나눔</span>' : ''}
        ${p.status !== '판매중' ? `<span class="badge-status">${STATUS_LABELS[p.status]}</span>` : ''}
        <button type="button" class="like-btn ${liked ? 'on' : ''}"
                aria-label="${liked ? '찜 해제' : '찜하기'}" aria-pressed="${liked}"
                onclick="toggleLike(event, '${p._id}')">${liked ? '♥' : '♡'}</button>
      </div>
      <div class="body">
        <h3>
          <a class="card-link" href="product.html?id=${p._id}"
             aria-label="${escapeHtml(p.title)} 상세 보기"></a>
          ${escapeHtml(p.title)}
        </h3>
        <div class="meta">
          <span class="price ${free ? 'free' : ''}">${formatPrice(p.price)}</span>
          <span class="dist">${dist}</span>
        </div>
        <div class="meta">
          <span class="seller-badge ${seller?.isVerified ? 'verified' : ''}">${escapeHtml(seller?.churchName || '')}</span>
          <span class="dist">${formatRelativeTime(p.createdAt)}</span>
        </div>
      </div>
    </article>
  `;
}

/* ---------- Like (찜) ---------- */
window.toggleLike = function(e, productId) {
  e.preventDefault();
  e.stopPropagation();
  const me = currentUser();
  if (!me) { toast('로그인 후 찜할 수 있어요', 'info'); return; }

  const nowLiked = Store.toggleLike(productId, me._id);
  const btn = e.currentTarget;
  btn.classList.toggle('on', nowLiked);
  btn.textContent = nowLiked ? '♥' : '♡';
  btn.setAttribute('aria-pressed', String(nowLiked));
  btn.setAttribute('aria-label', nowLiked ? '찜 해제' : '찜하기');
  btn.classList.remove('pop');
  void btn.offsetWidth; // restart the keyframe
  btn.classList.add('pop');
  toast(nowLiked ? '찜 목록에 담았어요' : '찜을 해제했어요', 'success');

  const counter = document.getElementById('likeCounter');
  if (counter) counter.textContent = Store.getProduct(productId)?.likeCount ?? 0;
};

/* ---------- Product detail ---------- */
let _viewCounted = false;

function renderProductPage() {
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const p = Store.getProduct(id);
  const root = document.getElementById('productDetail');
  if (!p) {
    root.innerHTML = `
      <div class="empty-state">
        <div class="emoji">😢</div>
        <h3>물품을 찾을 수 없습니다</h3>
        <p>삭제되었거나 잘못된 주소일 수 있어요.</p>
        <a href="index.html" class="btn btn-primary" style="margin-top:16px">목록으로 돌아가기</a>
      </div>`;
    return;
  }
  // Count a view once per page load — this function also re-runs after
  // status changes, which would otherwise inflate the counter.
  if (!_viewCounted) {
    Store.incrementView(p._id);
    _viewCounted = true;
    p.viewCount = (p.viewCount || 0) + 1;
  }
  const seller = Store.getUser(p.seller);
  const me = currentUser();
  const isOwner = me && seller && me._id === seller._id;
  const liked = me ? Store.isLiked(p._id, me._id) : false;
  root.innerHTML = `
    <div class="gallery">
      <div class="main-img" id="mainImg" role="img"
           aria-label="${escapeHtml(p.title)} 대표 사진"
           style="background-image:url('${p.images?.[0] || ''}')"></div>
      ${(p.images || []).length > 1 ? `
        <div class="thumbs">
          ${p.images.map((src, i) => `
            <button type="button" class="thumb ${i === 0 ? 'active' : ''}"
                 data-src="${escapeHtml(src)}"
                 aria-label="사진 ${i + 1}번 보기"
                 style="background-image:url('${escapeHtml(src)}')"
                 onclick="selectThumb(this)"></button>
          `).join('')}
        </div>
      ` : ''}
    </div>
    <div class="info">
      <span class="seller-badge">${CATEGORY_LABELS[p.category] || p.category} · ${escapeHtml(seller?.churchName || '')}</span>
      <h1>${escapeHtml(p.title)}</h1>
      <div class="price-row">
        <span class="price ${p.isFree || p.price === 0 ? 'free' : ''}">${formatPrice(p.price)}</span>
        <span class="tag tag-info">${p.condition}</span>
        <span class="tag ${p.status === '판매중' ? 'tag-success' : p.status === '예약중' ? 'tag-warning' : 'tag-danger'}">${STATUS_LABELS[p.status]}</span>
      </div>
      <div class="meta-grid">
        <div><div class="label">거래 지역</div><strong>${escapeHtml(p.addressName || '미정')}</strong></div>
        <div><div class="label">희망 거래 장소</div><strong>${escapeHtml(p.tradePlace || '채팅으로 협의')}</strong></div>
        <div><div class="label">등록일</div><strong>${formatRelativeTime(p.createdAt)}</strong></div>
        <div><div class="label">조회 · 찜</div><strong>${p.viewCount}회 · <span id="likeCounter">${p.likeCount || 0}</span>명</strong></div>
      </div>
      <h3>상세 설명</h3>
      <div class="description">${escapeHtml(p.description)}</div>
      <div class="seller-card">
        <div class="avatar">${avatarText(seller?.name)}</div>
        <div class="meta">
          <div class="name">${escapeHtml(seller?.name || '')} ${seller?.isVerified ? '<span class="seller-badge verified">교인증</span>' : ''}</div>
          <div class="sub">${escapeHtml(seller?.churchName || '')} · ${seller?.churchRole || ''}</div>
        </div>
        <div class="faith">
          <strong>${(seller?.faithScore || 36.5).toFixed(1)}°</strong>
          <span>믿음온도</span>
        </div>
      </div>
      ${isOwner ? `
        <div class="actions">
          <button class="btn btn-outline" onclick="toggleProductStatus('${p._id}')">상태 변경</button>
          <button class="btn btn-danger" onclick="deleteProductConfirm('${p._id}')">삭제</button>
          <button class="btn btn-outline btn-icon-only" aria-label="공유하기"
                  onclick="shareProduct('${p._id}')">🔗</button>
        </div>
      ` : me ? `
        <div class="actions">
          <button class="btn btn-primary" onclick="startChat('${p._id}')">💬 1:1 채팅하기</button>
          <button class="btn btn-outline btn-icon-only like-detail ${liked ? 'on' : ''}"
                  aria-label="${liked ? '찜 해제' : '찜하기'}" aria-pressed="${liked}"
                  onclick="toggleLike(event, '${p._id}')">${liked ? '♥' : '♡'}</button>
          <button class="btn btn-outline btn-icon-only" aria-label="공유하기"
                  onclick="shareProduct('${p._id}')">🔗</button>
          <button class="btn btn-outline btn-icon-only" aria-label="신고하기"
                  onclick="reportTarget('Product','${p._id}')">🚩</button>
        </div>
      ` : `
        <div class="actions">
          <a href="login.html" class="btn btn-primary btn-block">로그인하고 거래하기</a>
        </div>
      `}
      <div class="trade-note">
        <span>🛡️</span>
        <div><strong>안전 거래 안내</strong> · 은혜마켓은 직거래를 원칙으로 합니다.
        선입금 요구, 외부 링크 결제는 사기일 수 있으니 반드시 만나서 물품을 확인하세요.</div>
      </div>
    </div>
  `;
}

window.shareProduct = function(id) {
  const p = Store.getProduct(id);
  const url = location.origin + location.pathname + '?id=' + id;
  if (navigator.share) {
    navigator.share({ title: p?.title || '은혜마켓', url }).catch(() => {});
    return;
  }
  if (navigator.clipboard) {
    navigator.clipboard.writeText(url)
      .then(() => toast('링크를 복사했어요', 'success'))
      .catch(() => toast('링크 복사에 실패했어요', 'error'));
  } else {
    toast('이 브라우저는 공유를 지원하지 않아요', 'error');
  }
};
window.selectThumb = function(el) {
  document.getElementById('mainImg').style.backgroundImage = `url('${el.dataset.src}')`;
  document.querySelectorAll('.gallery .thumbs .thumb').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
};
window.toggleProductStatus = function(id) {
  const p = Store.getProduct(id);
  const next = p.status === '판매중' ? '예약중' : p.status === '예약중' ? '거래완료' : '판매중';
  Store.updateProduct(id, { status: next });
  toast(`물품 상태가 "${STATUS_LABELS[next]}"(으)로 변경되었습니다`, 'success');
  renderProductPage();
};
window.deleteProductConfirm = function(id) {
  openModal(`
    <h3>물품을 삭제할까요?</h3>
    <p>삭제 후에는 복구할 수 없습니다.</p>
    <div class="actions">
      <button class="btn btn-ghost" onclick="closeModal()">취소</button>
      <button class="btn btn-danger" onclick="confirmDelete('${id}')">삭제</button>
    </div>
  `);
};
window.confirmDelete = function(id) {
  Store.deleteProduct(id); closeModal();
  toast('물품이 삭제되었습니다', 'success');
  setTimeout(() => location.href = 'index.html', 600);
};

/* ---------- Chat start ---------- */
window.startChat = function(productId) {
  const me = currentUser();
  if (!me) { toast('로그인이 필요합니다', 'info'); return location.href = 'login.html'; }
  const product = Store.getProduct(productId);
  if (!product) return;
  let room = Store.findRoomByProductAndBuyer(productId, me._id);
  if (!room) {
    room = Store.createRoom({
      product: productId, buyer: me._id, seller: product.seller,
      lastMessage: '대화를 시작합니다'
    });
  }
  location.href = `chat.html?room=${room._id}`;
};

window.reportTarget = function(type, id) {
  const me = currentUser();
  if (!me) return location.href = 'login.html';
  openModal(`
    <h3>신고하기</h3>
    <p>접수된 신고는 운영팀이 확인 후 조치합니다.</p>
    <label class="field"><span>신고 사유</span>
      <select id="reportReason">
        <option value="스팸">스팸/홍보</option>
        <option value="사기">사기 의심</option>
        <option value="욕설">욕설/비방</option>
        <option value="기타">기타</option>
      </select>
    </label>
    <label class="field"><span>상세 내용 (선택)</span>
      <textarea id="reportDesc" rows="3" maxlength="300" placeholder="어떤 점이 문제였는지 알려주세요."></textarea>
    </label>
    <div class="actions">
      <button class="btn btn-ghost" onclick="closeModal()">취소</button>
      <button class="btn btn-danger" onclick="submitReport('${type}','${id}')">신고 접수</button>
    </div>
  `);
};
window.submitReport = function(type, id) {
  const reason = document.getElementById('reportReason').value;
  const description = document.getElementById('reportDesc').value.trim();
  const me = currentUser();
  Store.createReport({
    reporter: me._id, targetType: type, target: id, reason, description
  });
  closeModal();
  toast('신고가 접수되었습니다', 'success');
};

/* ---------- New product ---------- */
function bindNewProductForm() {
  const form = document.getElementById('newProductForm');
  if (!form) return;
  const imageInput = document.getElementById('imageInput');
  const addBtn = document.getElementById('addImageBtn');
  const imageList = document.getElementById('imageList');
  const isFree = document.getElementById('isFree');
  const priceInput = document.getElementById('price');

  let images = [];

  function renderImages() {
    imageList.innerHTML = images.map((src, i) => `
      <div class="thumb-item" style="background-image:url('${src}')">
        <button type="button" aria-label="사진 ${i + 1} 삭제" onclick="removeImage(${i})">×</button>
        ${i === 0 ? '<span class="cover-tag">대표</span>' : ''}
      </div>
    `).join('');
    addBtn.disabled = images.length >= 5;
    addBtn.textContent = images.length >= 5 ? '최대 5장까지' : '+ 사진 추가';
  }
  window.removeImage = function(i) {
    images.splice(i, 1); renderImages();
  };

  isFree.addEventListener('change', () => {
    if (isFree.checked) priceInput.value = 0;
  });

  addBtn.addEventListener('click', () => imageInput.click());
  imageInput.addEventListener('change', e => {
    const files = Array.from(e.target.files);
    const room = 5 - images.length;
    if (files.length > room) {
      toast(`사진은 최대 5장까지예요 (${room > 0 ? room + '장만 추가됨' : '추가 불가'})`, 'error');
    }
    files.slice(0, Math.max(0, room)).forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => { images.push(ev.target.result); renderImages(); };
      reader.readAsDataURL(file);
    });
    imageInput.value = '';
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!requireLogin()) return;
    const me = currentUser();
    const title = document.getElementById('title').value.trim();
    const category = document.getElementById('category').value;
    const condition = document.getElementById('condition').value;
    const price = Number(document.getElementById('price').value) || 0;
    const free = isFree.checked;
    const description = document.getElementById('description').value.trim();
    const addressName = document.getElementById('addressName').value.trim();
    const tradePlace = document.getElementById('tradePlace').value.trim();
    if (images.length === 0) { toast('사진을 1장 이상 첨부해 주세요', 'error'); return; }
    if (!title || !description) { toast('제목과 설명을 입력해 주세요', 'error'); return; }

    const product = Store.createProduct({
      seller: me._id, title, category, condition,
      price: free ? 0 : price, isFree: free,
      description, addressName, tradePlace, images
    });
    toast('물품이 등록되었습니다', 'success');
    setTimeout(() => location.href = `product.html?id=${product._id}`, 600);
  });
}

/* ---------- My page ---------- */
function renderMypage() {
  const me = currentUser();
  const root = document.getElementById('mypageContent');
  if (!me) {
    root.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🔒</div>
        <h3>로그인이 필요합니다</h3>
        <p>마이페이지를 보려면 로그인하세요.</p>
        <a href="login.html" class="btn btn-primary" style="margin-top:16px">로그인하기</a>
      </div>`;
    return;
  }
  const myProducts = Store.listProducts().filter(p => p.seller === me._id);
  const likedProducts = Store.listLikedProducts(me._id);
  const verifications = Store.listVerifications().filter(v => v.user === me._id);
  const latestVerif = verifications[0];
  const isPending = !me.isVerified && latestVerif?.status === '대기';

  root.innerHTML = `
    <div class="profile-header">
      <div class="avatar">${avatarText(me.name)}</div>
      <div>
        <h2>${escapeHtml(me.name)}</h2>
        <div class="sub">${escapeHtml(me.churchName)} · ${me.churchRole}</div>
        <div class="sub">📱 ${escapeHtml(me.phone)}</div>
      </div>
      <div class="faith-card">
        <strong>${(me.faithScore || 36.5).toFixed(1)}°</strong>
        <span>믿음온도 (${me.reviewCount || 0}건 평가)</span>
      </div>
    </div>

    ${me.isVerified ? `
      <div class="verification-banner verified">✅ 교인증이 완료되었습니다 (만료: ${latestVerif?.expiresAt ? new Date(latestVerif.expiresAt).toLocaleDateString('ko-KR') : '미설정'})</div>
    ` : isPending ? `
      <div class="verification-banner pending">
        ⏳ 교인증을 검토하고 있어요 · ${escapeHtml(latestVerif.churchName)} ${escapeHtml(latestVerif.documentType)} 제출 (${formatRelativeTime(latestVerif.createdAt)})
      </div>
    ` : `
      <div class="verification-banner">
        <strong>⛪ 교인증이 필요합니다</strong>
        <p style="margin:8px 0 0">소속 교회 교적부/주보 사진을 제출하면 <strong>교인 인증</strong> 배지를 받을 수 있어요.</p>
        <button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="openChurchVerification()">교인증 제출하기</button>
      </div>
    `}

    <h3 class="section-title">내 등록 물품 <span class="count">${myProducts.length}</span></h3>
    ${myProducts.length === 0 ? `
      <div class="empty-state">
        <div class="emoji">📦</div>
        <h3>등록한 물품이 없어요</h3>
        <p>첫 물품을 등록해 보세요.</p>
        <a href="new.html" class="btn btn-primary" style="margin-top:12px">물품 등록</a>
      </div>
    ` : `
      <div class="feed-grid">
        ${myProducts.map(p => productCardHtml(p)).join('')}
      </div>
    `}

    <h3 class="section-title">찜한 물품 <span class="count">${likedProducts.length}</span></h3>
    ${likedProducts.length === 0 ? `
      <div class="empty-state">
        <div class="emoji">♡</div>
        <h3>찜한 물품이 없어요</h3>
        <p>관심 있는 물품의 하트를 눌러 모아보세요.</p>
        <a href="index.html" class="btn btn-outline" style="margin-top:12px">물품 둘러보기</a>
      </div>
    ` : `
      <div class="feed-grid">
        ${likedProducts.map(p => productCardHtml(p)).join('')}
      </div>
    `}

    <h3 class="section-title">최근 거래 활동</h3>
    ${Store.listRooms().filter(r => r.buyer === me._id || r.seller === me._id).length === 0 ? `
      <div class="empty-state"><p>거래 내역이 없습니다.</p></div>
    ` : `
      <div class="chat-list">
        ${Store.listRooms()
          .filter(r => r.buyer === me._id || r.seller === me._id)
          .map(r => {
            const other = r.buyer === me._id ? r.seller : r.buyer;
            const product = Store.getProduct(r.product);
            const otherUser = Store.getUser(other);
            return `
              <button type="button" class="chat-row" onclick="location.href='chat.html?room=${r._id}'">
                <div class="avatar-sm">${avatarText(otherUser?.name)}</div>
                <div class="body">
                  <div class="top">
                    <div class="name">${escapeHtml(otherUser?.name || '')} · ${escapeHtml(product?.title || '')}</div>
                    <div class="time">${formatRelativeTime(r.lastMessageAt)}</div>
                  </div>
                  <div class="msg">${escapeHtml(r.lastMessage || '')}</div>
                </div>
                <span class="tag tag-info">${r.status}</span>
              </button>
            `;
          }).join('')}
      </div>
    `}
  `;
}

window.openChurchVerification = function() {
  openModal(`
    <h3>교인증 제출</h3>
    <p>아래 정보를 입력하면 운영팀이 검토합니다 (1~2 영업일).</p>
    <label class="field"><span>소속 교회</span>
      <input id="cvChurch" type="text" placeholder="예: 서초사랑교회" />
    </label>
    <label class="field"><span>인증 자료</span>
      <select id="cvType">
        <option value="교적부">교적부 사본</option>
        <option value="주보사진">주보 사진 (이름 포함)</option>
        <option value="목회자추천">목회자 추천</option>
      </select>
    </label>
    <label class="field"><span>연락처</span>
      <input id="cvPhone" type="tel" placeholder="010-0000-0000" />
    </label>
    <small class="hint">※ 제출 자료는 90일간 보관 후 자동 파기됩니다.</small>
    <div class="actions">
      <button class="btn btn-ghost" onclick="closeModal()">취소</button>
      <button class="btn btn-primary" onclick="submitChurchVerification()">제출</button>
    </div>
  `);
};
window.submitChurchVerification = function() {
  const me = currentUser();
  const church = document.getElementById('cvChurch').value.trim();
  const type = document.getElementById('cvType').value;
  const phone = document.getElementById('cvPhone').value.trim();
  if (!church || !phone) { toast('모든 항목을 입력해 주세요', 'error'); return; }
  Store.createVerification({
    user: me._id, churchName: church, documentType: type,
    contactPhone: phone, documentUrl: 'demo://submitted.jpg'
  });
  closeModal();
  toast('교인증이 제출되었습니다', 'success');
  setTimeout(() => renderMypage(), 400);
};

/* ---------- Chat list ---------- */
function renderChatList() {
  const me = currentUser();
  const root = document.getElementById('chatContent');
  if (!me) {
    root.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🔒</div>
        <h3>로그인이 필요합니다</h3>
        <p>채팅을 사용하려면 로그인하세요.</p>
        <a href="login.html" class="btn btn-primary" style="margin-top:16px">로그인하기</a>
      </div>`;
    return;
  }

  const params = new URLSearchParams(location.search);
  const roomId = params.get('room');
  if (roomId) return renderChatRoom(roomId);

  const rooms = Store.listRooms().filter(r => r.buyer === me._id || r.seller === me._id);
  root.innerHTML = `
    <h1 class="page-title">채팅</h1>
    ${rooms.length === 0 ? `
      <div class="empty-state">
        <div class="emoji">💬</div>
        <h3>아직 대화가 없어요</h3>
        <p>물품 상세에서 1:1 채팅을 시작해 보세요.</p>
        <a href="index.html" class="btn btn-primary" style="margin-top:12px">물품 보러가기</a>
      </div>
    ` : `
      <div class="chat-list">
        ${rooms.map(r => {
          const other = r.buyer === me._id ? r.seller : r.buyer;
          const product = Store.getProduct(r.product);
          const otherUser = Store.getUser(other);
          const unread = (r.buyer === me._id ? r.unreadCount?.buyer : r.unreadCount?.seller) || 0;
          return `
            <button type="button" class="chat-row" onclick="location.href='chat.html?room=${r._id}'">
              <div class="avatar-sm">${avatarText(otherUser?.name)}</div>
              <div class="body">
                <div class="top">
                  <div class="name">${escapeHtml(otherUser?.name || '')} <small style="color:var(--text-muted);font-weight:400">· ${escapeHtml(product?.title || '')}</small></div>
                  <div class="time">${formatRelativeTime(r.lastMessageAt)}</div>
                </div>
                <div class="msg">${escapeHtml(r.lastMessage || '')}</div>
              </div>
              ${unread > 0 ? `<span class="unread">${unread}</span>` : `<span class="tag tag-info">${r.status}</span>`}
            </button>
          `;
        }).join('')}
      </div>
    `}
  `;
}

function renderChatRoom(roomId) {
  const me = currentUser();
  const room = Store.getRoom(roomId);
  if (!room) {
    document.getElementById('chatContent').innerHTML =
      '<div class="empty-state"><div class="emoji">😢</div><h3>대화방을 찾을 수 없습니다</h3></div>';
    return;
  }
  if (room.buyer !== me._id && room.seller !== me._id) {
    toast('접근 권한이 없습니다', 'error');
    setTimeout(() => location.href = 'chat.html', 600);
    return;
  }
  const product = Store.getProduct(room.product);
  const otherId = room.buyer === me._id ? room.seller : room.buyer;
  const other = Store.getUser(otherId);
  const isSeller = room.seller === me._id;

  Store.markRead(roomId, me._id);

  function renderMessages() {
    const msgs = Store.getMessages(roomId);
    return `
      ${room.status === '거래예약' ? `
        <div class="chat-trade-bar">
          <span>🤝 거래 예약 중 · 약속 장소: <strong>${escapeHtml(product?.tradePlace || product?.addressName || '채팅으로 협의')}</strong></span>
          ${isSeller ? `<button class="btn btn-success btn-sm" onclick="tradeComplete('${roomId}')">거래완료 처리</button>` : ''}
        </div>
      ` : room.status === '거래완료' ? `
        <div class="chat-trade-bar done">
          <span>✅ 거래가 완료되었습니다 · 상대방의 매너를 평가해 주세요</span>
        </div>
      ` : isSeller ? `
        <div class="chat-trade-bar">
          <span>💡 거래가 확정되면 예약을 잡아 주세요.</span>
          <button class="btn btn-primary btn-sm" onclick="tradeReserve('${roomId}')">거래 약속 잡기</button>
        </div>
      ` : `
        <div class="chat-trade-bar idle">
          <span>💬 판매자가 거래 예약을 잡아주길 기다리고 있어요.</span>
        </div>
      `}
      <div class="chat-messages" id="msgList">
        ${msgs.map(m => {
          const cls = m.sender === me._id ? 'me' : (m.type === 'system' ? 'system' : '');
          return `<div class="msg-bubble ${cls}">
            ${escapeHtml(m.content || '')}
            <span class="time">${new Date(m.createdAt).toLocaleTimeString('ko-KR', { hour:'2-digit', minute:'2-digit' })}</span>
          </div>`;
        }).join('')}
      </div>
      <form class="chat-input" onsubmit="sendMessage(event, '${roomId}')">
        <input id="msgInput" type="text" placeholder="메시지를 입력하세요…" autocomplete="off" />
        <button class="btn btn-primary btn-sm" type="submit">전송</button>
      </form>
      ${room.status === '거래완료' && !hasReviewed(room, me._id) ? `
        <form class="card review-form" onsubmit="submitReview(event, '${roomId}', '${otherId}')">
          <h4>매너 평가 · ${escapeHtml(other?.name || '')}님의 믿음온도</h4>
          <div class="review-scores" role="radiogroup" aria-label="매너 평가 점수">
            <input type="radio" name="reviewScore" id="rs3" value="3" checked /><label for="rs3">😊 친절해요 +3</label>
            <input type="radio" name="reviewScore" id="rs1" value="1" /><label for="rs1">🙂 좋아요 +1</label>
            <input type="radio" name="reviewScore" id="rs0" value="0" /><label for="rs0">😐 보통 ±0</label>
            <input type="radio" name="reviewScore" id="rsm1" value="-1" /><label for="rsm1">😕 별로예요 -1</label>
          </div>
          <label class="field">
            <span>한 줄 코멘트 (선택)</span>
            <input id="reviewComment" type="text" maxlength="60" placeholder="예: 시간 약속을 잘 지켜주셨어요" />
          </label>
          <div class="actions"><button class="btn btn-primary btn-sm" type="submit">평가 보내기</button></div>
        </form>
      ` : ''}
    `;
  }

  const root = document.getElementById('chatContent');
  root.innerHTML = `
    <a href="chat.html" class="back-link">← 채팅 목록</a>
    <div class="chat-room" style="margin-top:16px">
      <div class="chat-header">
        <div class="avatar-sm">${avatarText(other?.name)}</div>
        <div class="meta">
          <div class="name">${escapeHtml(other?.name || '')} ${other?.isVerified ? '<span class="seller-badge verified">교인증</span>' : ''}</div>
          <div class="sub" style="color:var(--text-muted);font-size:12px">${escapeHtml(other?.churchName || '')} · 상품: ${escapeHtml(product?.title || '')}</div>
        </div>
        ${product ? `<a href="product.html?id=${product._id}" class="btn btn-outline btn-sm">물품 보기</a>` : ''}
      </div>
      ${renderMessages()}
    </div>
  `;

  const msgList = document.getElementById('msgList');
  if (msgList) msgList.scrollTop = msgList.scrollHeight;
  const input = document.getElementById('msgInput');
  if (input) input.focus();
}

function hasReviewed(room, userId) {
  // simplistic: once a system "평가 완료" message exists from this user, skip
  const msgs = Store.getMessages(room._id);
  return msgs.some(m => m.sender === userId && m.type === 'system' && m.content.includes('평가 완료'));
}

window.sendMessage = function(e, roomId) {
  e.preventDefault();
  const me = currentUser();
  const input = document.getElementById('msgInput');
  const text = input.value.trim();
  if (!text) return;
  Store.pushMessage(roomId, { sender: me._id, type: 'text', content: text });
  // bump unread for other side
  const room = Store.getRoom(roomId);
  const key = room.buyer === me._id ? 'seller' : 'buyer';
  Store.updateRoom(roomId, {
    lastMessage: text, lastMessageAt: new Date().toISOString(),
    unreadCount: { ...room.unreadCount, [key]: (room.unreadCount[key] || 0) + 1 }
  });
  renderChatRoom(roomId);
};

window.tradeReserve = function(roomId) {
  const me = currentUser();
  const room = Store.getRoom(roomId);
  Store.updateRoom(roomId, { status: '거래예약' });
  Store.pushMessage(roomId, {
    sender: me._id, type: 'system',
    content: '🤝 거래가 예약되었습니다'
  });
  Store.updateProduct(room.product, { status: '예약중' });
  toast('거래 예약이 등록되었습니다', 'success');
  renderChatRoom(roomId);
};
window.tradeComplete = function(roomId) {
  const me = currentUser();
  const room = Store.getRoom(roomId);
  Store.updateRoom(roomId, { status: '거래완료' });
  Store.pushMessage(roomId, {
    sender: me._id, type: 'system',
    content: '✅ 거래가 완료되었습니다'
  });
  Store.updateProduct(room.product, { status: '거래완료' });
  toast('거래가 완료되었습니다', 'success');
  renderChatRoom(roomId);
};

window.submitReview = function(e, roomId, targetUserId) {
  e.preventDefault();
  const me = currentUser();
  const picked = document.querySelector('input[name="reviewScore"]:checked');
  const delta = Number(picked ? picked.value : 0);
  const comment = document.getElementById('reviewComment').value.trim();
  Store.adjustFaith(targetUserId, delta);
  Store.pushMessage(roomId, {
    sender: me._id, type: 'system',
    content: `⭐ 평가 완료${comment ? ' · ' + comment : ''}`
  });
  toast('평가가 전송되었습니다', 'success');
  renderChatRoom(roomId);
};

/* ---------- Admin ---------- */
let _adminTab = 'verify';

function renderAdmin() {
  const me = currentUser();
  const root = document.getElementById('adminContent');
  if (!me || me.role !== 'ADMIN') {
    root.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🔒</div>
        <h3>관리자 권한이 필요합니다</h3>
        <p>데모에서는 전화번호 <strong>010-0000-0000</strong>으로 로그인하면 관리자 모드를 체험할 수 있어요.</p>
        <a href="login.html" class="btn btn-primary" style="margin-top:16px">로그인하기</a>
      </div>`;
    return;
  }
  const verifs = Store.listVerifications();
  const pending = verifs.filter(v => v.status === '대기');
  const reports = Store.listReports();
  const openReports = reports.filter(r => r.status === '접수');

  root.innerHTML = `
    <h1 class="page-title">관리자 콘솔</h1>
    <p class="page-sub">교인증 요청과 신고를 검토·처리합니다 (Demo).</p>
    <div class="stat-bar">
      <div><strong>${pending.length}</strong><span>교인증 대기</span></div>
      <div><strong>${verifs.filter(v => v.status === '승인').length}</strong><span>교인증 승인</span></div>
      <div><strong>${openReports.length}</strong><span>미처리 신고</span></div>
      <div><strong>${Store.listUsers().filter(u => u.role !== 'ADMIN').length}</strong><span>전체 교인</span></div>
    </div>
    <div class="admin-tabs" role="tablist">
      <button class="tab ${_adminTab === 'verify' ? 'active' : ''}" role="tab"
              aria-selected="${_adminTab === 'verify'}"
              onclick="switchAdminTab('verify')">교인증 큐 (${pending.length})</button>
      <button class="tab ${_adminTab === 'report' ? 'active' : ''}" role="tab"
              aria-selected="${_adminTab === 'report'}"
              onclick="switchAdminTab('report')">신고 관리 (${openReports.length})</button>
    </div>
    ${_adminTab === 'verify' ? adminVerifyPanel(verifs, pending) : adminReportPanel(reports, openReports)}
  `;
}

window.switchAdminTab = function(tab) { _adminTab = tab; renderAdmin(); };

function adminVerifyPanel(verifs, pending) {
  const handled = verifs.filter(v => v.status !== '대기').slice(0, 5);
  return `
    <h3 class="section-title">대기 중 <span class="count">${pending.length}</span></h3>
    ${pending.length === 0 ? '<div class="empty-state"><div class="emoji">✅</div><h3>대기 중인 요청이 없습니다</h3><p>새 교인증이 제출되면 여기에 표시됩니다.</p></div>' : ''}
    ${pending.map(v => {
      const u = Store.getUser(v.user);
      return `
        <div class="admin-card">
          <div class="top">
            <div>
              <strong>${escapeHtml(u?.name || '알 수 없음')}</strong>
              <span style="color:var(--text-muted);font-size:12.5px;display:block">${escapeHtml(v.churchName)} · ${escapeHtml(v.documentType)}</span>
              <div style="margin-top:5px;font-size:12px;color:var(--text-muted)">📱 ${escapeHtml(v.contactPhone)} · 🕒 ${formatRelativeTime(v.createdAt)}</div>
            </div>
            <span class="tag tag-warning">대기</span>
          </div>
          <div class="doc-preview">📎 제출 자료: ${escapeHtml(v.documentUrl)}</div>
          <div class="actions">
            <button class="btn btn-ghost btn-sm" onclick="verifAction('${v._id}','거절')">거절</button>
            <button class="btn btn-success btn-sm" onclick="verifAction('${v._id}','승인')">승인</button>
          </div>
        </div>`;
    }).join('')}
    <h3 class="section-title">최근 처리 내역</h3>
    ${handled.length === 0 ? '<div class="empty-state"><p>처리 내역이 없습니다.</p></div>' : handled.map(v => {
      const u = Store.getUser(v.user);
      return `
        <div class="admin-card">
          <div class="top">
            <div>
              <strong>${escapeHtml(u?.name || '알 수 없음')}</strong>
              <div style="font-size:12.5px;color:var(--text-muted)">${escapeHtml(v.churchName)} · ${escapeHtml(v.documentType)}</div>
            </div>
            <span class="tag ${v.status === '승인' ? 'tag-success' : 'tag-danger'}">${v.status}</span>
          </div>
        </div>`;
    }).join('')}
  `;
}

function reportTargetLabel(r) {
  if (r.targetType === 'Product') {
    const p = Store.getProduct(r.target);
    return p ? `물품 · ${escapeHtml(p.title)}` : '물품 · (삭제됨)';
  }
  const u = Store.getUser(r.target);
  return u ? `사용자 · ${escapeHtml(u.name)}` : '사용자 · (탈퇴)';
}

function adminReportPanel(reports, open) {
  const handled = reports.filter(r => r.status !== '접수').slice(0, 5);
  return `
    <h3 class="section-title">미처리 신고 <span class="count">${open.length}</span></h3>
    ${open.length === 0 ? '<div class="empty-state"><div class="emoji">🕊️</div><h3>미처리 신고가 없습니다</h3><p>접수된 신고가 모두 처리되었어요.</p></div>' : ''}
    ${open.map(r => {
      const reporter = Store.getUser(r.reporter);
      return `
        <div class="admin-card">
          <div class="top">
            <div>
              <strong>${reportTargetLabel(r)}</strong>
              <div style="font-size:12.5px;color:var(--text-muted);margin-top:3px">
                신고자: ${escapeHtml(reporter?.name || '알 수 없음')} · 🕒 ${formatRelativeTime(r.createdAt)}
              </div>
            </div>
            <span class="tag tag-danger">${escapeHtml(r.reason)}</span>
          </div>
          ${r.description ? `<div class="doc-preview">💬 ${escapeHtml(r.description)}</div>` : ''}
          <div class="actions">
            <button class="btn btn-ghost btn-sm" onclick="reportAction('${r._id}','반려')">반려</button>
            <button class="btn btn-danger btn-sm" onclick="reportAction('${r._id}','처리완료')">처리완료</button>
          </div>
        </div>`;
    }).join('')}
    <h3 class="section-title">최근 처리 내역</h3>
    ${handled.length === 0 ? '<div class="empty-state"><p>처리 내역이 없습니다.</p></div>' : handled.map(r => `
      <div class="admin-card">
        <div class="top">
          <div>
            <strong>${reportTargetLabel(r)}</strong>
            <div style="font-size:12.5px;color:var(--text-muted)">${escapeHtml(r.reason)} · ${formatRelativeTime(r.createdAt)}</div>
          </div>
          <span class="tag ${r.status === '처리완료' ? 'tag-success' : 'tag-info'}">${r.status}</span>
        </div>
      </div>`).join('')}
  `;
}

window.reportAction = function(id, status) {
  Store.updateReport(id, {
    status, handledBy: currentUser()._id, handledAt: new Date().toISOString()
  });
  toast(`신고를 ${status} 처리했습니다`, 'success');
  renderAdmin();
};
window.verifAction = function(id, action) {
  const v = Store.listVerifications().find(x => x._id === id);
  if (!v) return;
  if (action === '승인') {
    Store.updateVerification(id, { status: '승인', reviewedBy: currentUser()._id, reviewedAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 365*86400*1000).toISOString() });
    Store.updateUser(v.user, { isVerified: true });
  } else {
    Store.updateVerification(id, { status: '거절', reviewedBy: currentUser()._id, reviewedAt: new Date().toISOString() });
  }
  toast(`${action} 처리되었습니다`, 'success');
  renderAdmin();
};

/* ---------- Login ---------- */
function bindLoginForm() {
  const form = document.getElementById('loginForm');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const churchName = document.getElementById('churchName').value.trim();
    const churchRole = document.getElementById('churchRole').value;
    if (!name || !phone || !churchName) { toast('모든 항목을 입력해 주세요', 'error'); return; }

    const existing = Store.getUserByPhone(phone);
    const user = existing || Store.createUser({
      name, phone, churchName, churchRole,
      isVerified: phone === '010-0000-0000',
      role: phone === '010-0000-0000' ? 'ADMIN' : 'USER'
    });
    Store.setSession(user._id);
    toast(`${name}님, 환영합니다 🙏`, 'success');
    setTimeout(() => location.href = 'index.html', 600);
  });
}

/* ---------- Init ---------- */
function initIndex() {
  if (!document.getElementById('feedGrid')) return;
  document.getElementById('searchInput').addEventListener('input', renderFeed);
  document.getElementById('categoryFilter').addEventListener('change', renderFeed);
  document.getElementById('sortFilter').addEventListener('change', renderFeed);
  document.getElementById('typeFilter').addEventListener('change', renderFeed);
  document.getElementById('radiusInput').addEventListener('input', renderFeed);
  // distance quick chips
  const chips = document.getElementById('distanceChips');
  [1, 3, 5, 10, 20].forEach(km => {
    const b = document.createElement('button');
    b.className = 'chip' + (km === 5 ? ' active' : '');
    b.textContent = km + 'km';
    b.onclick = () => {
      document.getElementById('radiusInput').value = km;
      document.getElementById('radiusLabel').textContent = km;
      chips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      b.classList.add('active');
      renderFeed();
    };
    chips.appendChild(b);
  });
  renderFeed();
}

/* ---------- Demo reset ---------- */
window.resetDemo = function() {
  openModal(`
    <h3>데모 데이터를 초기화할까요?</h3>
    <p>등록한 물품·채팅·찜·로그인 상태가 모두 지워지고 처음 샘플 데이터로 되돌아갑니다.</p>
    <div class="actions">
      <button class="btn btn-ghost" onclick="closeModal()">취소</button>
      <button class="btn btn-danger" onclick="confirmResetDemo()">초기화</button>
    </div>
  `);
};
window.confirmResetDemo = function() {
  Store.resetAll();
  closeModal();
  toast('데모 데이터를 초기화했습니다', 'success');
  setTimeout(() => location.href = 'index.html', 600);
};

document.addEventListener('DOMContentLoaded', () => {
  seedIfEmpty();
  initTheme();
  bindHeader();
  bindNewProductForm();
  bindLoginForm();
  initIndex();
});