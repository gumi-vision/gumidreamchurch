/* ============================================================
   은혜마켓 · standalone builder
   Bundles the multi-page demo into one hash-routed HTML file.

   Usage:  node build-standalone.mjs
   ============================================================ */

import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), 'grace-market-demo', 'grace-market');
const OUT = join(dirname(fileURLToPath(import.meta.url)), 'grace-market-standalone.html');

/** page file -> hash route */
const ROUTES = {
  'index.html': 'home',
  'product.html': 'product',
  'new.html': 'new',
  'chat.html': 'chat',
  'mypage.html': 'mypage',
  'login.html': 'login',
  'admin.html': 'admin',
};

const read = (p) => readFileSync(join(ROOT, p), 'utf8');

/**
 * Rewrite every page reference to its hash route.
 * A plain string replace (rather than an attribute-aware regex) is deliberate:
 * the same token shows up in HTML attributes, quoted JS strings, AND template
 * literals like `chat.html?room=${id}`. The previous hand-built standalone only
 * handled the quoted forms, so chat/product navigation silently broke.
 */
function toHashRoutes(text) {
  let out = text;
  for (const [file, route] of Object.entries(ROUTES)) {
    out = out.split(file).join('#' + route);
  }
  return out;
}

/** Pull the body of a page, minus the chrome we render once at the top level. */
function extractView(file) {
  const html = read(file);
  let body = html.slice(html.indexOf('<body>') + '<body>'.length, html.lastIndexOf('</body>'));

  const strip = [
    /<a href="#feed" class="skip-link">[\s\S]*?<\/a>/g,
    /<header class="site-header">[\s\S]*?<\/header>/g,
    /<nav class="mobile-nav"[\s\S]*?<\/nav>/g,
    /<div class="modal-backdrop"[\s\S]*?<\/div>\s*<\/div>/g,
    /<button class="fab"[\s\S]*?<\/button>/g,
    /<footer class="site-footer">[\s\S]*?<\/footer>/g,
    /<script[\s\S]*?<\/script>/g,
    /<!--[\s\S]*?-->/g,
  ];
  for (const re of strip) body = body.replace(re, '');

  return toHashRoutes(body).trim();
}

/** The footer lives once, below the router outlet. */
function extractFooter() {
  const html = read('index.html');
  const m = html.match(/<footer class="site-footer">[\s\S]*?<\/footer>/);
  return m ? toHashRoutes(m[0]) : '';
}

const css = read('css/style.css');
const js = [read('js/data.js'), read('js/storage.js'), read('js/app.js')]
  .map(toHashRoutes)
  .join('\n\n');

const views = Object.entries(ROUTES)
  .map(([file, route]) => `<section class="view" id="view-${route}" hidden>\n${extractView(file)}\n</section>`)
  .join('\n\n');

const router = `
(function () {
  const VALID = ${JSON.stringify(Object.values(ROUTES))};

  function parseHash() {
    const h = (location.hash || '#home').replace(/^#/, '');
    const [path, qs] = h.split('?');
    return { path, params: new URLSearchParams(qs || '') };
  }

  function show(view) {
    document.querySelectorAll('.view').forEach(v => { v.hidden = true; });
    const target = document.getElementById('view-' + view);
    if (target) target.hidden = false;
    document.querySelectorAll('[data-route]').forEach(a => {
      const on = a.dataset.route === view;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    try {
      if (view === 'home'    && typeof renderFeed === 'function') renderFeed();
      if (view === 'product' && typeof renderProductPage === 'function') renderProductPage();
      if (view === 'chat'    && typeof renderChatList === 'function') renderChatList();
      if (view === 'mypage'  && typeof renderMypage === 'function') renderMypage();
      if (view === 'admin'   && typeof renderAdmin === 'function') renderAdmin();
    } catch (e) { console.error('view init', view, e); }
    if (typeof bindHeader === 'function') bindHeader();
    window.scrollTo(0, 0);
  }

  function route() {
    const { path, params } = parseHash();
    window.__gmRawParams = Object.fromEntries(params.entries());
    if (VALID.includes(path)) { show(path); return; }
    // Not a view — treat it as an in-page anchor (e.g. #feed) and keep the
    // current view instead of bouncing the reader back to home.
    const anchor = path && document.getElementById(path);
    if (anchor) { anchor.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    show('home');
  }

  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    e.preventDefault();
    const href = a.getAttribute('href');
    if (location.hash === href) route(); else location.hash = href;
  });

  window.addEventListener('hashchange', route);
  window.addEventListener('DOMContentLoaded', route);
})();

(function () {
  // Pages read their arguments via new URLSearchParams(location.search).get(k).
  // Under hash routing location.search is empty, so serve those reads from the
  // parsed hash query instead.
  const origGet = URLSearchParams.prototype.get;
  URLSearchParams.prototype.get = function (k) {
    if (window.__gmRawParams && Object.prototype.hasOwnProperty.call(window.__gmRawParams, k)) {
      const v = window.__gmRawParams[k];
      return v === '' ? null : v;
    }
    return origGet.call(this, k);
  };
})();
`.trim();

const navLink = (route, icon, label, extra = '') =>
  `<a href="#${route}" data-route="${route}"${extra}><span class="ico" aria-hidden="true">${icon}</span>${label}</a>`;

const out = `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="theme-color" content="#1F4D3F" />
<title>은혜마켓 · 교회 교인 이웃 직거래</title>
<meta name="description" content="같은 교회, 같은 동네 이웃과 믿음으로 함께하는 중고 나눔·거래 플랫폼" />
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='24' fill='%231F4D3F'/%3E%3Cpath d='M44 20h12v18h18v12H56v30H44V50H26V38h18z' fill='%23fff'/%3E%3C/svg%3E" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css" />
<link href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&display=swap" rel="stylesheet" />
<style>
${css}
.view[hidden] { display: none !important; }
</style>
</head>
<body>

<a href="#feed" class="skip-link">본문으로 건너뛰기</a>

<header class="site-header">
  <div class="container header-inner">
    <a href="#home" class="brand" data-route="home">
      <span class="brand-mark" aria-hidden="true">✝</span><span class="brand-name">은혜마켓</span>
    </a>
    <nav class="nav" aria-label="주요 메뉴">
      <a href="#home" data-route="home">홈</a>
      <a href="#chat" data-route="chat">채팅</a>
      <a href="#mypage" data-route="mypage">마이페이지</a>
      <a href="#admin" data-route="admin" id="adminLink" style="display:none">관리자</a>
    </nav>
    <div class="header-actions">
      <button class="icon-btn" id="themeToggle" aria-label="테마 전환">🌙</button>
      <a href="#new" data-route="new" class="btn btn-primary btn-sm desktop-only">+ 물품 등록</a>
      <a href="#login" data-route="login" class="btn btn-ghost btn-sm" id="loginLink">로그인</a>
      <button class="btn btn-ghost btn-sm" id="logoutBtn" style="display:none">로그아웃</button>
    </div>
  </div>
</header>

<main id="appRoot">
${views}
</main>

${extractFooter()}

<button class="fab" id="fabChat" aria-label="채팅 열기">💬</button>

<nav class="mobile-nav" aria-label="모바일 메뉴">
  <div class="mobile-nav-inner">
    ${navLink('home', '🏠', '홈')}
    ${navLink('mypage', '♡', '찜·내정보')}
    ${navLink('new', '＋', '등록', ' class="cta"')}
    ${navLink('chat', '💬', '채팅')}
    ${navLink('login', '👤', '로그인', ' id="mobileAuthLink"')}
  </div>
</nav>

<div class="modal-backdrop" id="modal" style="display:none" role="dialog" aria-modal="true">
  <div class="modal" id="modalContent"></div>
</div>

<script>
${js}
</script>

<script>
${router}
</script>
</body>
</html>
`;

writeFileSync(OUT, out, 'utf8');
console.log(`built ${OUT} (${(Buffer.byteLength(out, 'utf8') / 1024).toFixed(1)} KB, ${Object.keys(ROUTES).length} views)`);
