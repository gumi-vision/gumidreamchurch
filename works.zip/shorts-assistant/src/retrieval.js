const HANGUL_RE = /[가-힣]/;
const PUNCT_RE = /[.,!?;:()[\]{}"'`~^*_=+|\\/<>@#$%&·…“”‘’—–\-]/g;

// Korean is agglutinative (조사/어미 붙음) so plain whitespace tokens miss partial
// matches (e.g. "한국은" vs "한국"). Emit both the whole token and its character
// bigrams for any token containing Hangul, which approximates morpheme overlap
// without a real morphological analyzer.
export function tokenize(text) {
  const tokens = [];
  const words = text
    .toLowerCase()
    .replace(PUNCT_RE, " ")
    .split(/\s+/)
    .filter(Boolean);

  for (const word of words) {
    tokens.push(word);
    if (HANGUL_RE.test(word) && word.length > 2) {
      for (let i = 0; i < word.length - 1; i++) {
        tokens.push(word.slice(i, i + 2));
      }
    }
  }
  return tokens;
}

function termFrequencies(tokens) {
  const tf = new Map();
  for (const t of tokens) {
    tf.set(t, (tf.get(t) || 0) + 1);
  }
  return tf;
}

export function buildBM25Index(docs) {
  const docTokens = docs.map((d) => tokenize(d.text));
  const docTf = docTokens.map(termFrequencies);
  const docLengths = docTokens.map((t) => t.length);
  const avgdl = docLengths.reduce((a, b) => a + b, 0) / (docLengths.length || 1);

  const df = new Map();
  docTf.forEach((tf) => {
    for (const term of tf.keys()) {
      df.set(term, (df.get(term) || 0) + 1);
    }
  });

  return { docTf, docLengths, avgdl, df, N: docs.length };
}

const K1 = 1.5;
const B = 0.75;

export function bm25Search(query, index) {
  const queryTokens = new Set(tokenize(query));
  const { docTf, docLengths, avgdl, df, N } = index;

  return docTf.map((tf, i) => {
    let score = 0;
    for (const term of queryTokens) {
      const termDf = df.get(term);
      if (!termDf) continue;
      const termTf = tf.get(term) || 0;
      if (termTf === 0) continue;
      const idf = Math.log(1 + (N - termDf + 0.5) / (termDf + 0.5));
      const denom = termTf + K1 * (1 - B + (B * docLengths[i]) / avgdl);
      score += idf * ((termTf * (K1 + 1)) / denom);
    }
    return score;
  });
}

export function cosineSimilarity(a, b) {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

function ranksFromScores(scores) {
  const order = scores
    .map((score, i) => ({ i, score }))
    .sort((a, b) => b.score - a.score);
  const ranks = new Array(scores.length);
  order.forEach((entry, rank) => {
    ranks[entry.i] = rank + 1;
  });
  return ranks;
}

const RRF_K = 60;

// Hybrid retrieval: fuse a lexical ranking (BM25) with a semantic ranking
// (embedding cosine similarity) via Reciprocal Rank Fusion. RRF sidesteps the
// problem of BM25 and cosine scores living on incomparable scales — it only
// needs each method's rank order, not its raw magnitude.
export function hybridSearch({ query, docs, bm25Index, docEmbeddings, queryEmbedding, topK = 4 }) {
  const bm25Scores = bm25Search(query, bm25Index);
  const vectorScores = docEmbeddings.map((vec) => cosineSimilarity(vec, queryEmbedding));

  const bm25Ranks = ranksFromScores(bm25Scores);
  const vectorRanks = ranksFromScores(vectorScores);

  const fused = docs.map((doc, i) => ({
    doc,
    bm25Score: bm25Scores[i],
    vectorScore: vectorScores[i],
    bm25Rank: bm25Ranks[i],
    vectorRank: vectorRanks[i],
    rrfScore: 1 / (RRF_K + bm25Ranks[i]) + 1 / (RRF_K + vectorRanks[i]),
  }));

  fused.sort((a, b) => b.rrfScore - a.rrfScore);
  return fused.slice(0, topK);
}
