import trendsData from "./trends-data.json";
import { CATEGORIES } from "./categories.js";
import { KB_DOCS } from "./kb.js";
import { buildBM25Index, hybridSearch } from "./retrieval.js";

const MODEL = "@cf/meta/llama-4-scout-17b-16e-instruct";
const EMBEDDING_MODEL = "@cf/baai/bge-m3";
const KB_EMBEDDINGS_CACHE_KEY = "kb-embeddings-v1";

// BM25 only needs term statistics, which are cheap to recompute per request
// since KB_DOCS is tiny (~20 docs). No need to cache this index.
const BM25_INDEX = buildBM25Index(KB_DOCS);

function buildSystemPrompt() {
  const countryLines = trendsData.countries
    .map(
      (c) =>
        `- ${c.name} (${c.rankLabel}): 인기 카테고리 [${c.categories.join(", ")}] / 포맷 특징: ${c.format} / 차별화 포인트: ${c.differentiator}`
    )
    .join("\n");

  return `당신은 유튜브 쇼츠를 처음 시작하는 한국 크리에이터를 돕는 "수익형 쇼츠 제작 설계 도우미"입니다.
아래는 유튜브 시청량 상위 국가 4곳(이용자 수 기준)과 타겟 시장 한국(시청시간 기준), 총 5개국의 실제 리서치 데이터입니다. 이 데이터를 근거로만 답변하고, 데이터에 없는 통계를 지어내지 마세요.

[국가별 트렌드 데이터]
${countryLines}

[5개국 공통 패턴]
${trendsData.universalPatterns.map((p) => `- ${p}`).join("\n")}

[한국 수익화 최소 요건]
${trendsData.monetizationKR}

사용자가 자신의 채널 주제/목표를 알려주면, 다음 구조로 한국어 실행 계획을 작성하세요:

1. 추천 카테고리 (위 데이터의 보편 카테고리와 사용자의 세부 주제가 어떻게 교집합을 이루는지, 왜 이 조합이 알고리즘/시청자에게 통하는지 이유까지 설명)

2. 훅·포맷 설계 (영상 길이, 첫 3초에 정확히 무엇을 보여줄지 구체적 장면 묘사. "흥미로운 장면을 보여준다" 같은 뭉뚱그린 표현 금지 — 실제로 화면에 무엇이 나오는지 예시를 들 것)

3. 목표 달성 전략 및 성장 예측 (사용자가 숫자 목표를 제시한 경우에만 작성. 다음 순서로 작성하세요:
   (a) 역산 계산: 목표 달성까지 남은 기간을 업로드 빈도로 나눠 총 영상 개수를 계산하고, 이 카테고리 특성상 기대할 수 있는 영상당 평균 조회수·구독 전환율 가정을 명시한 뒤, 그 가정으로 목표에 도달 가능한지 계산 과정을 보여주세요. 목표에 못 미칠 것 같으면 솔직하게 지적하고 대안(카테고리 조정, 업로드 빈도 상향, 협업 등)을 제시하세요.
   (b) 구간별 성장 예측: 위 가정을 그대로 실행했을 때 1개월 차/2개월 차/목표 시점(예: 3개월 차) 각각 예상 구독자 수 범위를 제시하세요. 이건 확정치가 아니라 가정에 기반한 추정치임을 명시하세요.
   (c) 다음 단계: 목표를 달성한 이후, 그다음 마일스톤(목표의 약 2배 수준)까지 가려면 구체적으로 무엇을 바꿔야 하는지(예: 업로드 빈도 상향, 시리즈 확장, 협업, 다른 세부 주제 추가 등) 제시하고 대략적인 예상 소요 기간도 함께 제시하세요.
   사용자가 목표를 입력하지 않았다면 이 섹션 전체를 생략하고, 이후 섹션 번호를 빈칸 없이 다시 순서대로 매기세요.)

4. 참고할 해외 특이점 (반드시 서로 다른 국가 2곳을 골라, 각 국가의 차별화 포인트를 사용자의 세부 주제에 결합했을 때 나오는 구체적인 콘텐츠 아이디어를 한 개씩 제시. 국가 이름과 차별화 포인트를 그대로 나열하지 말고 "이렇게 응용하면 이런 영상이 나온다"까지 이어갈 것)

5. 이 채널만의 차별화 포인트 (반드시 사용자의 세부 주제에서만 나올 수 있는 구체적인 소재·캐릭터·시리즈명·훅 아이디어를 1~2개 제시. "진정성 있게", "꾸준히", "차별화된 콘텐츠 제공" 같은 다른 채널에도 그대로 쓸 수 있는 뻔한 표현은 절대 쓰지 마세요. 이 문장을 다른 카테고리에 그대로 복사해도 말이 되면 실패입니다.)

6. 4주 실행 체크리스트 (주차별로 구체적인 영상 소재 예시를 포함해서 작성. "콘텐츠 업로드" 같은 뭉뚱그린 표현 대신 어떤 영상을 올릴지 명시)

과장 없이 구체적이고 실행 가능하게 작성하되, 각 섹션은 최소 2~3문장 이상으로 충분히 구체적으로 작성하세요. 뻔하고 일반적인 조언은 실패로 간주합니다.
중요: 사용자가 입력한 채널 주제·목표·업로드 빈도를 반드시 그대로 사용하세요. 절대 다른 주제로 바꾸거나 임의의 목표 수치를 지어내지 마세요.
중요: 한자(漢字)나 영어 단어를 섞지 말고 순수 한국어 단어로만 작성하세요 (예: "挑戰" 대신 "챌린지").`;
}

async function handleHotShorts(request, env) {
  const url = new URL(request.url);
  const category = (url.searchParams.get("category") || "").trim();
  const subcategory = (url.searchParams.get("subcategory") || "").trim();

  if (!CATEGORIES[category] || !CATEGORIES[category].includes(subcategory)) {
    return Response.json({ error: "올바른 카테고리·세부 주제가 필요합니다." }, { status: 400 });
  }

  if (!env.YOUTUBE_API_KEY) {
    return Response.json({ error: "YouTube 미리보기가 아직 설정되지 않았습니다." }, { status: 503 });
  }

  const cacheKey = `hotshorts:${category}:${subcategory}`;
  if (env.PLAN_CACHE) {
    const cached = await env.PLAN_CACHE.get(cacheKey, "json");
    if (cached) {
      return Response.json({ videos: cached, cached: true });
    }
  }

  const searchParams = new URLSearchParams({
    key: (env.YOUTUBE_API_KEY || "").trim(),
    part: "snippet",
    type: "video",
    q: `${subcategory} 쇼츠`,
    videoDuration: "short",
    order: "viewCount",
    regionCode: "KR",
    relevanceLanguage: "ko",
    maxResults: "6",
  });

  const res = await fetch(`https://www.googleapis.com/youtube/v3/search?${searchParams}`);

  if (!res.ok) {
    const errBody = await res.text();
    return Response.json({ error: `YouTube API 오류: ${res.status}`, detail: errBody }, { status: 502 });
  }

  const data = await res.json();
  const videos = (data.items || [])
    .filter((item) => item.id && item.id.videoId)
    .map((item) => ({
      videoId: item.id.videoId,
      title: item.snippet.title,
      channelTitle: item.snippet.channelTitle,
      thumbnail: item.snippet.thumbnails?.medium?.url || item.snippet.thumbnails?.default?.url,
    }));

  if (env.PLAN_CACHE) {
    await env.PLAN_CACHE.put(cacheKey, JSON.stringify(videos), { expirationTtl: 60 * 60 * 6 });
  }

  return Response.json({ videos, cached: false });
}

async function embedTexts(env, texts) {
  const result = await env.AI.run(EMBEDDING_MODEL, { text: texts });
  return result.data;
}

async function getKbEmbeddings(env) {
  if (env.PLAN_CACHE) {
    const cached = await env.PLAN_CACHE.get(KB_EMBEDDINGS_CACHE_KEY, "json");
    if (cached && cached.length === KB_DOCS.length) {
      return cached;
    }
  }

  const vectors = await embedTexts(env, KB_DOCS.map((d) => d.text));

  if (env.PLAN_CACHE) {
    await env.PLAN_CACHE.put(KB_EMBEDDINGS_CACHE_KEY, JSON.stringify(vectors), {
      expirationTtl: 60 * 60 * 24 * 30,
    });
  }

  return vectors;
}

async function handleChat(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "요청 본문이 올바른 JSON이 아닙니다." }, { status: 400 });
  }

  const message = (body.message || "").trim();
  if (!message) {
    return Response.json({ error: "메시지를 입력해주세요." }, { status: 400 });
  }
  if (message.length > 500) {
    return Response.json({ error: "메시지가 너무 깁니다 (500자 이내)." }, { status: 400 });
  }

  const [docEmbeddings, [queryEmbedding]] = await Promise.all([
    getKbEmbeddings(env),
    embedTexts(env, [message]),
  ]);

  const results = hybridSearch({
    query: message,
    docs: KB_DOCS,
    bm25Index: BM25_INDEX,
    docEmbeddings,
    queryEmbedding,
    topK: 4,
  });

  const context = results
    .map((r, i) => `[참고자료 ${i + 1}] ${r.doc.text}`)
    .join("\n\n");

  const systemPrompt = `당신은 "쇼츠 설계 도우미" 서비스의 챗봇입니다. 아래 참고 자료에 근거해서만 한국어로 짧고 정확하게 답변하세요.
참고 자료에 없는 내용은 추측하지 말고, 모르면 모른다고 솔직히 답하세요. 답변은 3~5문장 이내로 간결하게 작성하세요.
한자(漢字)를 섞지 말고 순수 한국어로만 답변하세요.

${context}`;

  const result = await env.AI.run(MODEL, {
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: message },
    ],
    max_tokens: 500,
    temperature: 0.3,
  });

  const answer = (result.response || "답변을 생성하지 못했습니다. 다시 시도해주세요.").replace(
    /挑戰/g,
    "챌린지"
  );

  return Response.json({
    answer,
    sources: results.map((r) => ({
      id: r.doc.id,
      bm25Rank: r.bm25Rank,
      vectorRank: r.vectorRank,
      rrfScore: Number(r.rrfScore.toFixed(4)),
    })),
  });
}

async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function handlePlan(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "요청 본문이 올바른 JSON이 아닙니다." }, { status: 400 });
  }

  const category = (body.category || "").trim();
  const subcategory = (body.subcategory || "").trim();
  const goal = (body.goal || "").trim();
  const uploadsPerWeek = (body.uploadsPerWeek || "").trim();

  if (!CATEGORIES[category]) {
    return Response.json({ error: "올바른 카테고리를 선택해주세요." }, { status: 400 });
  }
  if (!CATEGORIES[category].includes(subcategory)) {
    return Response.json({ error: "올바른 세부 주제를 선택해주세요." }, { status: 400 });
  }

  const niche = `${category} - ${subcategory}`;
  const cacheKey = await sha256Hex(`v5|${niche}|${goal}|${uploadsPerWeek}`);

  if (env.PLAN_CACHE) {
    const cached = await env.PLAN_CACHE.get(cacheKey);
    if (cached) {
      return Response.json({ plan: cached, cached: true });
    }
  }

  const userPrompt = `채널 주제/관심 카테고리: ${niche}\n목표: ${goal || "명시 안 함"}\n주간 업로드 가능 횟수: ${uploadsPerWeek || "명시 안 함"}`;

  const result = await env.AI.run(MODEL, {
    messages: [
      { role: "system", content: buildSystemPrompt() },
      { role: "user", content: userPrompt },
    ],
    max_tokens: 2000,
    temperature: 0.35,
  });

  const plan = (result.response || "생성에 실패했습니다. 다시 시도해주세요.").replace(/挑戰/g, "챌린지");

  if (env.PLAN_CACHE) {
    await env.PLAN_CACHE.put(cacheKey, plan, { expirationTtl: 60 * 60 * 24 });
  }

  return Response.json({ plan, cached: false });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/plan" && request.method === "POST") {
      return handlePlan(request, env);
    }

    if (url.pathname === "/api/plan") {
      return Response.json({ error: "POST 요청만 지원합니다." }, { status: 405 });
    }

    if (url.pathname === "/api/hot-shorts" && request.method === "GET") {
      return handleHotShorts(request, env);
    }

    if (url.pathname === "/api/chat" && request.method === "POST") {
      return handleChat(request, env);
    }

    if (url.pathname === "/api/chat") {
      return Response.json({ error: "POST 요청만 지원합니다." }, { status: 405 });
    }

    return new Response("Not found", { status: 404 });
  },
};
