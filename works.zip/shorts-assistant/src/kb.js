import trendsData from "./trends-data.json";
import { CATEGORIES } from "./categories.js";

function buildDocs() {
  const docs = [];

  trendsData.countries.forEach((c) => {
    docs.push({
      id: `country:${c.name}`,
      text: `${c.name} 쇼츠 트렌드 (${c.rankLabel}). 인기 카테고리: ${c.categories.join(
        ", "
      )}. 포맷 특징: ${c.format}. 차별화 포인트: ${c.differentiator}.`,
    });
  });

  docs.push({
    id: "pattern:universal",
    text: `5개국(인도, 미국, 인도네시아, 브라질, 한국) 공통 쇼츠 트렌드 패턴: ${trendsData.universalPatterns.join(
      "; "
    )}.`,
  });

  docs.push({
    id: "monetization:kr",
    text: `한국 유튜브 쇼츠 수익화 최소 요건: ${trendsData.monetizationKR}`,
  });

  Object.entries(CATEGORIES).forEach(([category, subcategories]) => {
    docs.push({
      id: `category:${category}`,
      text: `쇼츠 설계 도우미의 "${category}" 카테고리에서 고를 수 있는 세부 주제: ${subcategories.join(
        ", "
      )}.`,
    });
  });

  docs.push({
    id: "faq:tool",
    text: "쇼츠 설계 도우미는 유튜브 쇼츠를 처음 시작하는 한국 크리에이터를 위한 무료 서비스로, 카테고리·세부 주제·목표·업로드 빈도를 입력하면 5개국 쇼츠 트렌드 리서치를 근거로 추천 카테고리, 훅·포맷 설계, 목표 달성 전략, 해외 벤치마킹, 채널 차별화 포인트, 4주 실행 체크리스트를 만들어 준다.",
  });

  docs.push({
    id: "faq:free",
    text: "이 도구는 Cloudflare Workers AI를 사용해 완전히 무료로 제공되며, 별도의 회원가입이나 결제 없이 누구나 설계안을 생성할 수 있다.",
  });

  docs.push({
    id: "faq:hotshorts",
    text: "세부 주제를 선택하면 YouTube Data API를 통해 해당 주제로 실제 인기 있는 쇼츠 영상 6개를 썸네일과 함께 미리보기로 보여주며, 클릭하면 유튜브에서 바로 볼 수 있다.",
  });

  docs.push({
    id: "faq:goal-projection",
    text: "목표 입력란에 구독자 수 같은 숫자 목표를 적으면, 업로드 빈도와 카테고리 평균 조회수·구독 전환율을 가정해 목표 달성까지 필요한 영상 개수를 역산하고, 1개월·2개월·목표 시점의 예상 구독자 수 구간과 다음 마일스톤까지 필요한 전략을 함께 제시한다.",
  });

  docs.push({
    id: "faq:hook",
    text: "쇼츠는 첫 3초 안에 시청자의 관심을 끄는 훅 설계가 국가와 무관하게 가장 중요한 공통 원칙이며, 자막은 무음 시청이 기본값이라 사실상 필수다.",
  });

  return docs;
}

export const KB_DOCS = buildDocs();
