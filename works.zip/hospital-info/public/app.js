/* ============================================================
   어디로가지 · 프론트엔드
   ============================================================ */

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const n = (v) => Number(v || 0).toLocaleString('ko-KR');

const state = {
  region: localStorage.getItem('wh.region') || '',
  district: localStorage.getItem('wh.district') || '',
  boot: null,
};

function toast(msg, kind = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $('#toastStack').appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('wh.theme', t);
}
applyTheme(localStorage.getItem('wh.theme')
  || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

function openModal(html, onMount) {
  $('#modalBody').innerHTML = html;
  $('#modal').hidden = false;
  if (onMount) onMount($('#modalBody'));
  const f = $('#modalBody').querySelector('input,select,textarea,button');
  if (f) f.focus();
}
const closeModal = () => { $('#modal').hidden = true; };
$('#modal').addEventListener('click', e => { if (e.target === e.currentTarget) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

async function api(path, opts) {
  const res = await fetch(path, opts);
  const d = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(d.error || `요청 실패 (${res.status})`);
  return d;
}

/*
 * 외부 링크는 <a target="_blank" rel="noopener noreferrer"> 만으로 연다.
 *
 * 이전에 window.open 폴백을 뒀다가 버그가 있었다:
 * window.open(url, '_blank', 'noopener') 는 성공해도 명세상 null 을 돌려준다.
 * 그래서 "막혔다"고 오판하고 현재 탭까지 이동시켜, 새 탭이 열리는 동시에
 * 보고 있던 화면도 바뀌었다. 브라우저 기본 동작에 맡기는 편이 정확하다.
 */

/** 심평원 URL 은 스킴이 없거나 공백이 섞여 있는 경우가 있어 정리해서 쓴다. */
function normUrl(u) {
  const s = String(u || '').trim();
  if (!s || s === '-') return null;
  if (/^https?:\/\//i.test(s)) return s;
  if (/^www\./i.test(s) || /\.(kr|com|net|org)/i.test(s)) return 'http://' + s;
  return null;
}

/**
 * 병원 공식 홈페이지 주소. 심평원이 준 주소를 그대로 쓴다.
 * 접속 가능 여부를 서버에서 판정해 대체하려 했으나, 엣지에서의 결과가
 * 이용자 브라우저와 달라 정상 사이트를 걸러내는 오탐이 많았다.
 */
function siteLink(h) {
  const u = normUrl(h.url);
  return u ? { url: u, live: true } : { url: null, live: false };
}

const searchUrl = (...parts) =>
  `https://search.naver.com/search.naver?query=${encodeURIComponent(parts.filter(Boolean).join(' '))}`;

/** 새 탭으로 여는 링크. 브라우저 기본 동작에 맡긴다. */
function extLink(url, label, cls = 'btn btn-outline btn-sm') {
  return `<a class="${cls}" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${label}</a>`;
}

/* ---------- 근거 배지 ---------- */
function evidenceHtml(h) {
  const out = [];
  if (h.is_specialized) out.push('<span class="ev spec">⬥ 전문병원 지정</span>');
  if (h.best_grade) out.push(`<span class="ev grade g${h.best_grade}">적정성평가 ${h.best_grade}등급</span>`);
  if (h.cl_name) out.push(`<span class="ev cl">${esc(h.cl_name)}</span>`);
  if (h.dept_sdr) out.push(`<span class="ev">해당과 전문의 ${n(h.dept_sdr)}명</span>`);
  if (h.review_count) out.push(`<span class="ev">후기 ${n(h.review_count)}건</span>`);
  return `<div class="evidence">${out.join('')}</div>`;
}

/* ---------- 부트 ---------- */
async function boot() {
  state.boot = await api('/api/bootstrap');
  const { regions, conditions, freshness } = state.boot;

  $('#regionSelect').innerHTML =
    `<option value="">전국</option>` +
    regions.filter(r => r.hospital_count > 0).map(r =>
      `<option value="${r.slug}"${r.slug === state.region ? ' selected' : ''}>${esc(r.name)} (${n(r.hospital_count)})</option>`
    ).join('');

  $('#condGrid').innerHTML = conditions.map(c => `
    <button class="cond-card" data-cond="${c.slug}">
      <span class="c-top"><span class="c-ico">${c.icon || '🏥'}</span>
        <h3>${esc(c.name)}</h3></span>
      <span class="c-spec">${esc(c.specialty)}</span>
    </button>`).join('');

  $('#statRow').innerHTML = `
    <div class="stat"><span class="s-val num">${n(freshness.hospitals)}</span><span class="s-lab">등록 병원 (병원급 이상)</span></div>
    <div class="stat"><span class="s-val num">${n(freshness.designations)}</span><span class="s-lab">공식 지정 항목</span></div>
    <div class="stat"><span class="s-val num">${n(freshness.evaluations)}</span><span class="s-lab">적정성평가 등급</span></div>
    <div class="stat"><span class="s-val num">${esc((freshness.updated_at || '—').slice(0, 10))}</span><span class="s-lab">최종 수집</span></div>`;

  $('#condGrid').addEventListener('click', e => {
    const b = e.target.closest('[data-cond]');
    if (b) location.hash = `#/c/${b.dataset.cond}`;
  });
  $('#regionSelect').addEventListener('change', e => {
    state.region = e.target.value;
    state.district = '';                       // 시·도가 바뀌면 하위 선택은 초기화
    localStorage.setItem('wh.region', state.region);
    localStorage.setItem('wh.district', '');
    fillDistricts();
    route();
  });
  $('#districtSelect').addEventListener('change', e => {
    state.district = e.target.value;
    localStorage.setItem('wh.district', state.district);
    route();
  });
  fillDistricts();
  $('#themeToggle').addEventListener('click', () =>
    applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'));
  $('#askForm').addEventListener('submit', onAsk);
  window.addEventListener('hashchange', route);
  route();
}

/* ---------- 자연어 질문 ---------- */
async function onAsk(e) {
  e.preventDefault();
  const q = $('#askInput').value.trim();
  if (!q) return;

  const btn = $('#askBtn');
  const out = $('#askResult');
  btn.disabled = true; btn.textContent = '찾는 중…';
  out.innerHTML = `<div class="ask-answer"><div class="sk sk-line" style="width:80%;height:14px"></div>
    <div class="sk sk-line" style="width:60%;height:14px;margin-top:8px"></div></div>`;

  try {
    const d = await api('/api/ask', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q }),
    });

    if (d.emergency) {
      out.innerHTML = `<div class="ask-answer emergency">
        <strong>🚨 응급 상황일 수 있습니다</strong>
        <p>${esc(d.answer)}</p>
        <a class="btn btn-primary btn-sm" href="tel:119">119 전화하기</a></div>`;
      return;
    }

    const chips = d.needCondition
      ? `<div class="cond-chips">${d.conditions.map(c =>
          `<button class="chip-btn" data-cond="${c.slug}">${esc(c.name)}</button>`).join('')}</div>`
      : '';

    const list = (d.hospitals || []).map((h, i) => `
      <a class="ask-hosp" href="#/h/${h.id}/${esc(d.condition.slug)}">
        <span class="rank num">${i + 1}</span>
        <span class="a-body">
          <b>${esc(h.name)}</b>
          <span class="a-meta">${esc(h.region || '')} ${esc(h.district || '')} · ${esc(h.cl_name || '')}</span>
          <span class="evidence">
            ${h.best_grade ? `<span class="ev grade g${h.best_grade}">${esc(d.condition.name)} ${h.best_grade}등급</span>` : ''}
            ${h.dept_sdr ? `<span class="ev">해당과 전문의 ${n(h.dept_sdr)}명</span>` : ''}
          </span>
        </span>
      </a>`).join('');

    out.innerHTML = `
      <div class="ask-answer">
        <p>${esc(d.answer).replace(/\n/g, '<br>')}</p>
        ${d.widened ? `<p class="a-widened">↔ ${esc(d.widened)}</p>` : ''}
        ${chips}
        ${list ? `<div class="ask-list">${list}</div>` : ''}
        ${d.condition ? `<p class="a-basis">근거 · ${esc(d.condition.basis)}</p>` : ''}
      </div>`;

    out.querySelectorAll('[data-cond]').forEach(b =>
      b.addEventListener('click', () => { location.hash = `#/c/${b.dataset.cond}`; }));
  } catch (err) {
    out.innerHTML = `<div class="ask-answer"><p>${esc(err.message)}</p></div>`;
  } finally {
    btn.disabled = false; btn.textContent = '물어보기';
  }
}

/** 선택된 시·도의 시·군·구를 채운다. 전국이면 비활성화. */
function fillDistricts() {
  const sel = $('#districtSelect');
  const region = state.boot.regions.find(r => r.slug === state.region);
  const list = region?.districts || [];

  if (!region || !list.length) {
    sel.innerHTML = '<option value="">시·군·구</option>';
    sel.disabled = true;
    state.district = '';
    return;
  }
  sel.disabled = false;
  sel.innerHTML = `<option value="">${esc(region.name)} 전체</option>` +
    list.map(d => `<option value="${esc(d.code)}"${d.code === state.district ? ' selected' : ''}>${esc(d.name)} (${n(d.n)})</option>`).join('');
}

/* ---------- 라우팅 ---------- */
function show(id) {
  ['home', 'condition', 'hospital', 'status', 'cost', 'privacy']
    .forEach(v => { $(`#view-${v}`).hidden = v !== id; });
  window.scrollTo(0, 0);
}
function route() {
  const h = location.hash || '#/';
  let m = h.match(/^#\/c\/([a-z0-9-]+)/);
  if (m) { show('condition'); return loadCondition(m[1]); }
  // #/h/2/neck-disc — 질환을 거쳐 들어온 경우 그 맥락을 유지한다.
  m = h.match(/^#\/h\/(\d+)(?:\/([a-z0-9-]+))?/);
  if (m) { show('hospital'); return loadHospital(Number(m[1]), m[2] || null); }
  if (/^#\/status/.test(h)) { show('status'); return loadStatus(); }
  if (/^#\/cost/.test(h)) { show('cost'); return loadCost(); }
  if (/^#\/privacy/.test(h)) { return show('privacy'); }   // 정적 문서라 불러올 것이 없다
  show('home');
}

/* ---------- 비용 안내 ---------- */
async function loadCost(q = '') {
  const root = $('#costRoot');
  if (!root.dataset.ready) {
    root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">불러오는 중…</div>`;
  }
  let d;
  try { d = await api('/api/cost' + (q ? `?q=${encodeURIComponent(q)}` : '')); }
  catch (err) {
    root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">${esc(err.message)}</div>`;
    return;
  }
  root.dataset.ready = '1';

  root.innerHTML = `
    <a class="back-link" href="#/">← 처음으로</a>
    <span class="eyebrow">COST & INSURANCE</span>
    <h1 class="cond-title">진료비·보험 안내</h1>
    <p class="cond-summary">
      수술이나 입원을 앞두고 가장 걱정되는 게 비용이죠.
      제도상 정해진 부분은 정확히 알려드리고, 사람마다 달라지는 부분은 어디서 확인해야 하는지 알려드립니다.
    </p>

    ${d.guides.map(g => `<div class="panel">
      <div class="panel-head"><h3>${esc(g.title)}</h3></div>
      <p style="font-size:14px;line-height:1.85;white-space:pre-line;margin:0;color:var(--ink-soft)">${esc(g.body)}</p>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:14px 0 0">근거 · ${esc(g.source_note)}</p>
    </div>`).join('')}

    <div class="panel">
      <div class="panel-head">
        <h3>비급여 항목 찾아보기</h3>
        <span class="hint">${n(d.itemTotal)}개 항목</span>
      </div>
      <p style="font-size:13px;color:var(--ink-soft);margin:0 0 14px">
        아래 항목들은 <b>건강보험이 적용되지 않아 전액 본인 부담</b>입니다.
        받으실 치료에 이런 항목이 포함되는지 진료 전에 물어보세요.
      </p>
      <form class="ask-box" id="costSearch" style="margin-bottom:14px">
        <input id="costQ" type="text" placeholder="예: 인실, 도수치료, 초음파" value="${esc(d.query || '')}" />
        <button class="btn btn-outline" type="submit">검색</button>
      </form>
      ${d.items.length ? `<table class="grades">
        <thead><tr><th>항목</th><th style="text-align:right">분류</th></tr></thead>
        <tbody>${d.items.map(it => `<tr>
          <td>${esc(it.name)}</td>
          <td class="g" style="font-size:12px;color:var(--ink-faint)">${esc(it.major || '')}</td>
        </tr>`).join('')}</tbody></table>`
        : '<div class="empty">검색 결과가 없습니다.</div>'}
      <p style="font-size:12px;color:var(--gold);margin:14px 0 0">⚠️ ${esc(d.priceNotice)}</p>
      <div class="actions-row" style="margin-top:12px">
        <a class="btn btn-outline btn-sm" target="_blank" rel="noopener noreferrer"
           href="https://www.hira.or.kr/rc/nonpay/nonPayDamtSrch.do?pgmid=HIRAA030009000000">심평원 비급여 가격 비교 →</a>
        <a class="btn btn-outline btn-sm" target="_blank" rel="noopener noreferrer"
           href="https://cont.insure.or.kr">내 보험 가입내역 조회 →</a>
      </div>
    </div>

    <div class="panel" style="background:var(--danger-soft);border-color:var(--danger)">
      <div class="panel-head"><h3 style="color:var(--danger)">보험금 계산은 하지 않습니다</h3></div>
      <p style="font-size:13.5px;line-height:1.8;margin:0;color:var(--ink-soft)">
        같은 수술이라도 실손보험 가입 시기·특약·자기부담금에 따라 받는 금액이 크게 달라집니다.
        저희가 임의로 계산해 드리면 잘못된 기대를 드릴 수 있어, <b>금액은 안내하지 않습니다.</b>
        가입하신 보험사에 "이 치료가 보장되는지, 자기부담금이 얼마인지"를 진료 전에 확인하시는 것이 가장 정확합니다.
      </p>
    </div>`;

  $('#costSearch').addEventListener('submit', e => {
    e.preventDefault();
    loadCost($('#costQ').value.trim());
  });
}

/* ---------- 수집 현황 ---------- */
async function loadStatus() {
  const root = $('#statusRoot');
  root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">불러오는 중…</div>`;
  let d;
  try { d = await api('/api/status'); }
  catch (err) {
    root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">${esc(err.message)}</div>`;
    return;
  }

  const badge = (s) => s === 'ok'
    ? '<span class="ev g1">성공</span>'
    : s === 'error' ? '<span class="ev g4">실패</span>' : `<span class="ev">${esc(s)}</span>`;

  root.innerHTML = `
    <a class="back-link" href="#/">← 처음으로</a>
    <span class="eyebrow">DATA PIPELINE</span>
    <h1 class="cond-title">수집 현황</h1>
    <p class="cond-summary">모든 자료는 공공데이터포털 오픈API에서 매일 자동 수집합니다. 어떤 수집원을 어떤 근거로 쓰는지 그대로 공개합니다.</p>

    ${d.ai ? `<div class="panel">
      <div class="panel-head">
        <h3>AI 모델</h3>
        <span class="hint">${d.ai.confirmedAt ? `최근 응답 ${esc(d.ai.confirmedAt)}` : '아직 호출 없음'}</span>
      </div>
      <p style="font-size:13px;color:var(--ink-soft);margin:0 0 12px;line-height:1.7">
        자연어 질문은 Cloudflare Workers AI 로 처리합니다.
        <b>모델이 폐기되면 아래 순서대로 자동 전환</b>되므로 서비스가 멈추지 않습니다.
      </p>
      <div class="evidence">
        ${d.ai.chain.map((m, i) => `<span class="ev ${m === d.ai.active ? 'g1' : ''}">
          ${i + 1}. ${esc(m.replace('@cf/', ''))}${m === d.ai.active ? ' · 사용 중' : ''}</span>`).join('')}
      </div>
    </div>` : ''}

    <div class="panel">
      <div class="panel-head"><h3>수집원</h3><span class="hint">${d.sources.length}개</span></div>
      <table class="grades">
        <thead><tr><th>수집원</th><th>이용 근거</th><th style="text-align:right">상태</th></tr></thead>
        <tbody>${d.sources.map(s => `<tr>
          <td><b>${esc(s.name)}</b>
            <div style="font-size:11.5px;color:var(--ink-faint)">최근 실행 · ${esc(s.last_run_at || '없음')}</div></td>
          <td style="font-size:12.5px;color:var(--ink-soft)">${esc(s.license)}</td>
          <td class="g">${s.enabled
            ? '<span class="ev g1">사용 중</span>'
            : '<span class="ev g5">대기</span>'}</td>
        </tr>`).join('')}</tbody>
      </table>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>최근 실행 기록</h3><span class="hint">최대 20건</span></div>
      ${d.runs.length ? `<table class="grades">
        <thead><tr><th>수집원</th><th>시각</th><th style="text-align:right">결과</th></tr></thead>
        <tbody>${d.runs.map(r => `<tr>
          <td>${esc(r.source || '—')}
            ${r.message ? `<div style="font-size:11.5px;color:var(--g4)">${esc(r.message)}</div>` : ''}</td>
          <td class="num" style="font-size:12.5px">${esc(r.started_at || '')}</td>
          <td class="g">${badge(r.status)} <span class="num" style="font-size:12px">${n(r.inserted)}건</span></td>
        </tr>`).join('')}</tbody></table>`
        : '<div class="empty">실행 기록이 없습니다.</div>'}
    </div>`;
}

/* ---------- 질환별 ---------- */
async function loadCondition(slug) {
  const root = $('#conditionRoot');
  root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">불러오는 중…</div>`;

  let d;
  const p = new URLSearchParams();
  if (state.region) p.set('region', state.region);
  if (state.district) p.set('district', state.district);
  const qs = p.toString() ? `?${p}` : '';
  try { d = await api(`/api/conditions/${slug}${qs}`); }
  catch (err) {
    root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">${esc(err.message)}</div>`;
    return;
  }

  const { condition: c, region, district, orderExplanation, orderCaveat, hospitals } = d;
  const placeLabel = district ? `${region.name} ${district.name}` : (region ? region.name : '전국');
  root.innerHTML = `
    <a class="back-link" href="#/">← 처음으로</a>
    <span class="eyebrow">${esc(c.specialty)}</span>
    <h1 class="cond-title">${esc(c.name)}</h1>
    <p class="cond-summary">${esc(c.summary || '')}</p>

    <div class="basis">
      <h3>이 목록은 무엇을 근거로 하나요?</h3>
      <p>${esc(c.basis_note || '')}</p>
      <ol>${orderExplanation.map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      ${orderCaveat ? `<p style="margin:12px 0 0;font-size:12.5px;color:var(--gold)">
        ⚠️ ${esc(orderCaveat)}</p>` : ''}
      <p style="margin:12px 0 0;font-size:12.5px">
        저희가 평가한 것이 아니라 <b>공표된 자료를 이 순서로 정렬</b>한 것입니다.
        등급은 특정 시점 결과이며 현재 진료 수준을 보장하지 않습니다.
      </p>
    </div>

    <div class="section-head">
      <div><span class="eyebrow">HOSPITALS</span>
        <h2>${esc(placeLabel)} · ${hospitals.length}곳</h2></div>
    </div>

    ${hospitals.length ? `<div class="hosp-list">${hospitals.map((h, i) => `
      <article class="hosp">
        <span class="rank num">${i + 1}</span>
        <div class="h-body">
          <h3><a class="card-link" href="#/h/${h.id}/${esc(c.slug)}" aria-label="${esc(h.name)} 상세"></a>${esc(h.name)}</h3>
          <div class="h-meta">${esc(h.region || '')} ${esc(h.district || '')} · ${esc(h.addr || '')}</div>
          ${evidenceHtml(h)}
        </div>
        <div class="h-side">
          <span class="n num">${n(h.sdr_count)}</span>
          <span class="l">전문의(명)</span>
        </div>
      </article>`).join('')}</div>`
      : `<div class="empty">해당 조건의 병원 정보가 아직 없습니다.<br>지역을 넓히거나 수집이 완료된 뒤 다시 확인해 주세요.</div>`}`;
}

/* ---------- 병원 상세 ---------- */
async function loadHospital(id, condSlug = null) {
  const root = $('#hospitalRoot');
  root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">불러오는 중…</div>`;

  let d;
  try { d = await api(`/api/hospitals/${id}${condSlug ? `?condition=${encodeURIComponent(condSlug)}` : ''}`); }
  catch (err) {
    root.innerHTML = `<a class="back-link" href="#/">← 처음으로</a><div class="empty">${esc(err.message)}</div>`;
    return;
  }

  const { hospital: h, designations, evaluations, departments, doctors,
          reviewSummary, reviews, wait, details, facility, equipment,
          transit, conditionContext: cc } = d;
  const rs = reviewSummary || {};

  // 질환을 거쳐 왔으면 그 질환 정보를 최상단에 놓는다.
  const condPanel = cc ? `
    <div class="panel cond-focus">
      <div class="panel-head">
        <h3>🎯 ${esc(cc.condition.name)} 관련 정보</h3>
        <a class="text-link" href="#/c/${esc(cc.condition.slug)}">다른 병원 비교 →</a>
      </div>
      <div class="kv">
        <div>
          <div class="k">담당 진료과</div>
          <div class="v">${esc(cc.condition.specialty)}</div>
        </div>
        <div>
          <div class="k">${esc(cc.condition.specialty)} 전문의</div>
          <div class="v num">${cc.deptSdr != null ? n(cc.deptSdr) + '명' : '자료 없음'}</div>
        </div>
        <div>
          <div class="k">${esc(cc.condition.name)} 평가등급</div>
          <div class="v">${cc.evaluations.length
            ? cc.evaluations.map(e => `<span class="ev grade g${e.grade}">${e.grade}등급</span>`).join(' ')
            : '<span style="color:var(--ink-faint);font-weight:400">평가 항목 없음</span>'}</div>
        </div>
        <div>
          <div class="k">이 과 대기 제보</div>
          <div class="v num">${cc.wait.sample
            ? (cc.wait.medianDays != null ? cc.wait.medianDays + '일' : '—')
            : '제보 없음'}</div>
        </div>
      </div>
      <p style="font-size:12.5px;color:var(--ink-soft);margin:14px 0 0;line-height:1.7">
        ${esc(cc.condition.basis)}
      </p>

      ${(cc.condition.txConservative || cc.condition.txSurgical || cc.condition.costNote) ? `
      <div class="tx-block">
        <h4>${esc(cc.condition.name)} 치료는 어떻게 하나요?</h4>
        ${cc.condition.txConservative ? `<div class="tx-row">
          <span class="tx-tag conservative">비수술</span>
          <p>${esc(cc.condition.txConservative)}</p></div>` : ''}
        ${cc.condition.txSurgical ? `<div class="tx-row">
          <span class="tx-tag surgical">수술</span>
          <p>${esc(cc.condition.txSurgical)}</p></div>` : ''}
        ${cc.condition.costNote ? `<div class="tx-row cost">
          <span class="tx-tag cost">비용</span>
          <p>${cc.condition.costNote.replace(/&/g,'&amp;').replace(/<(?!\/?b>)/g,'&lt;').replace(/\n/g,'<br>')}</p></div>` : ''}
        <p class="tx-caveat">
          일반적으로 알려진 치료 선택지와 비용 구조를 정리한 것입니다.
          <b>어떤 치료가 적합한지는 검사 결과와 상태에 따라 달라지므로 진료를 통해 결정됩니다.</b>
          금액은 병원·재료·입원기간에 따라 크게 달라지니, 수술 전 병원에 예상 진료비 확인서를 요청하세요.
          <a class="text-link" href="#/cost">진료비·보험 안내 →</a>
        </p>
      </div>` : ''}
      <div class="doctor-note">
        <strong>이 병원의 ${esc(cc.condition.name)} 담당 의료진은?</strong>
        <p>공공데이터에는 <b>의료진 개인 정보가 제공되지 않습니다.</b>
        (심평원 오픈API는 기관 단위까지만 공개합니다.)
        담당 교수·전문의 명단은 병원 공식 홈페이지의 ${esc(cc.condition.specialty)} 의료진 소개에서 확인하실 수 있습니다.</p>
        <div class="actions-row">
          ${siteLink(h).live ? extLink(siteLink(h).url, '병원 홈페이지 →') : ''}
          ${extLink(searchUrl(h.name, cc.condition.specialty, '교수'), `${esc(cc.condition.specialty)} 교수 검색 →`)}
        </div>
        <p style="font-size:11.5px;color:var(--ink-faint);margin:10px 0 0">
          병원 홈페이지 주소는 심평원 등록 정보 기준입니다. 열리지 않으면 옆의 검색을 이용하세요.
        </p>
      </div>
    </div>` : '';

  root.innerHTML = `
    <a class="back-link" href="javascript:history.back()">← 뒤로</a>
    <span class="eyebrow">${esc(h.region || '')} ${esc(h.district || '')}</span>
    <h1 class="cond-title">${esc(h.name)}</h1>
    <div class="evidence" style="margin-bottom:20px">
      ${h.cl_name ? `<span class="ev cl">${esc(h.cl_name)}</span>` : ''}
      ${designations.map(g => `<span class="ev spec">⬥ ${esc(g.kind)}${g.field ? ' · ' + esc(g.field) : ''}</span>`).join('')}
    </div>

    ${condPanel}

    <div class="panel">
      <div class="panel-head"><h3>기본 정보</h3></div>
      <div class="kv">
        <div><div class="k">주소</div><div class="v">${esc(h.addr || '—')}</div></div>
        <div><div class="k">전화</div><div class="v">${h.tel ? `<a class="text-link" href="tel:${esc(h.tel)}">${esc(h.tel)}</a>` : '—'}</div></div>
        <div><div class="k">전체 의사</div><div class="v num">${n(h.dr_total)}명</div></div>
        <div><div class="k">전문의</div><div class="v num">${n(h.sdr_count)}명</div></div>
      </div>
      <div class="actions-row" style="margin-top:16px">
        ${(() => {
          const s = siteLink(h);
          return s.live
            ? extLink(s.url, '공식 홈페이지에서 예약 →', 'btn btn-primary btn-sm')
            : extLink(searchUrl(h.name, '예약'), '홈페이지 검색 →', 'btn btn-primary btn-sm');
        })()}
        ${h.tel ? `<a class="btn btn-outline btn-sm" href="tel:${esc(h.tel)}">전화 문의</a>` : ''}
        ${extLink(`https://map.naver.com/p/search/${encodeURIComponent(h.name)}`, '지도에서 보기')}
      </div>
      <p style="font-size:12px;color:var(--ink-faint);margin:12px 0 0">
        예약은 병원 공식 채널에서만 진행됩니다. 저희는 예약을 대행하지 않습니다.
        상급종합병원은 <b>진료의뢰서</b>가 필요할 수 있습니다.
      </p>
    </div>

    ${details ? `<div class="panel">
      <div class="panel-head"><h3>진료시간 · 주차 · 응급실</h3><span class="hint">심평원 공표</span></div>
      <div class="kv">
        ${details.trmt_weekday ? `<div><div class="k">평일</div><div class="v num">${esc(details.trmt_weekday)}</div></div>` : ''}
        ${details.trmt_sat ? `<div><div class="k">토요일</div><div class="v num">${esc(details.trmt_sat)}</div></div>` : ''}
        ${details.lunch_week ? `<div><div class="k">점심시간</div><div class="v num">${esc(details.lunch_week)}</div></div>` : ''}
        ${details.rcv_week ? `<div><div class="k">접수시간</div><div class="v num">${esc(details.rcv_week)}</div></div>` : ''}
        ${details.no_trmt_sun ? `<div><div class="k">일요일</div><div class="v">${esc(details.no_trmt_sun)}</div></div>` : ''}
        ${details.no_trmt_holi ? `<div><div class="k">공휴일</div><div class="v">${esc(details.no_trmt_holi)}</div></div>` : ''}
      </div>
      <div class="evidence" style="margin-top:14px">
        ${details.emy_day ? '<span class="ev spec">응급실 주간 운영</span>' : ''}
        ${details.emy_night ? '<span class="ev spec">응급실 야간 운영</span>' : ''}
        ${details.park_qty ? `<span class="ev">주차 ${n(details.park_qty)}대</span>` : ''}
        ${details.park_qty ? `<span class="ev">${details.park_paid ? '주차 유료' : '주차 무료'}</span>` : ''}
      </div>
      ${details.emy_tel ? `<p style="font-size:12.5px;color:var(--ink-soft);margin:12px 0 0">
        응급 연락처 <a class="text-link" href="tel:${esc(details.emy_tel)}">${esc(details.emy_tel)}</a></p>` : ''}
      ${details.park_note ? `<p style="font-size:12px;color:var(--ink-faint);margin:8px 0 0">주차 조건 · ${esc(details.park_note)}</p>` : ''}
    </div>` : ''}

    ${facility && facility.beds_total ? `<div class="panel">
      <div class="panel-head">
        <h3>병상 · 시설</h3>
        <span class="hint">심평원 공표${h.nursing_grade ? ` · 간호등급 ${esc(h.nursing_grade)}` : ''}</span>
      </div>
      <div class="kv">
        <div><div class="k">허가 병상</div><div class="v num">${n(facility.beds_total)}개</div></div>
        ${facility.beds_standard ? `<div><div class="k">일반 병상</div><div class="v num">${n(facility.beds_standard)}개</div></div>` : ''}
        ${facility.beds_upper ? `<div><div class="k">상급 병상 <span style="font-weight:400;color:var(--ink-faint)">(1~2인실 등)</span></div><div class="v num">${n(facility.beds_upper)}개</div></div>` : ''}
        ${facility.icu_adult ? `<div><div class="k">중환자실 병상</div><div class="v num">${n(facility.icu_adult)}개</div></div>` : ''}
        ${facility.icu_newborn ? `<div><div class="k">신생아 중환자실 병상</div><div class="v num">${n(facility.icu_newborn)}개</div></div>` : ''}
        ${facility.beds_isolation ? `<div><div class="k">격리 병상</div><div class="v num">${n(facility.beds_isolation)}개</div></div>` : ''}
        ${facility.beds_negative ? `<div><div class="k">음압 격리 병상</div><div class="v num">${n(facility.beds_negative)}개</div></div>` : ''}
        ${facility.op_rooms ? `<div><div class="k">수술실</div><div class="v num">${n(facility.op_rooms)}개</div></div>` : ''}
        ${facility.delivery_rooms ? `<div><div class="k">분만실</div><div class="v num">${n(facility.delivery_rooms)}개</div></div>` : ''}
        ${facility.beds_emergency ? `<div><div class="k">응급실 병상</div><div class="v num">${n(facility.beds_emergency)}개</div></div>` : ''}
      </div>
      <p style="font-size:12px;color:var(--ink-faint);margin:14px 0 0;line-height:1.7">
        공공데이터에는 <b>상급병상 총 수</b>까지만 공개되며, 1인실·2인실별 개수와 요금은 제공되지 않습니다.
        상급병실료는 비급여라 병원이 자율로 정하므로 입원 전 병원에 직접 확인하시거나
        <a class="text-link" href="#/cost">진료비·보험 안내</a>의 심평원 비급여 조회를 이용하세요.
      </p>
    </div>` : ''}

    ${equipment && equipment.length ? `<div class="panel">
      <div class="panel-head"><h3>주요 의료장비</h3><span class="hint">심평원 공표</span></div>
      <div class="evidence">
        ${equipment.map(e => `<span class="ev">${esc(e.name)} ${n(e.qty)}</span>`).join('')}
      </div>
    </div>` : ''}

    ${transit && transit.length ? `<div class="panel">
      <div class="panel-head"><h3>찾아가는 길</h3><span class="hint">심평원 공표</span></div>
      <table class="grades"><tbody>${transit.map(t => `<tr>
        <td><b>${esc(t.kind || '')}</b> ${esc(t.line_no || '')}
          <div style="font-size:12px;color:var(--ink-faint)">${esc(t.arrive || '')} ${esc(t.direction && t.direction !== '-' ? t.direction : '')}</div></td>
        <td class="g num">${esc(t.distance || '')}</td>
      </tr>`).join('')}</tbody></table>
      ${details?.place_name ? `<p style="font-size:12px;color:var(--ink-faint);margin:12px 0 0">
        ${esc(details.place_name)} 기준 ${esc(details.place_dir || '')} ${esc(details.place_dist || '')}</p>` : ''}
    </div>` : ''}

    ${(() => {
      // 항목명이 확인되지 않은 코드는 표에 올리지 않는다.
      // "평가항목 08 · 1등급" 은 이용자에게 아무 의미가 없고, 무슨 항목인지
      // 추측해서 붙이면 의료 정보를 잘못 안내하게 된다.
      const named = evaluations.filter(e => !/^평가항목 /.test(e.subject));
      const unnamed = evaluations.length - named.length;
      return `<div class="panel">
        <div class="panel-head"><h3>적정성평가 등급</h3><span class="hint">심평원 공표</span></div>
        ${named.length ? `<table class="grades">
          <thead><tr><th>평가 항목</th><th>연도</th><th style="text-align:right">등급</th></tr></thead>
          <tbody>${named.map(e => `<tr>
            <td>${esc(e.subject)}</td><td class="num">${esc(e.year || '—')}</td>
            <td class="g">${e.grade ? `<span class="ev grade g${e.grade}">${e.grade}등급</span>` : '—'}</td>
          </tr>`).join('')}</tbody></table>`
          : `<div class="empty">표시할 평가 항목이 없습니다.</div>`}
        ${unnamed ? `<p style="font-size:12px;color:var(--ink-faint);margin:12px 0 0">
          이 병원은 <b>${unnamed}개 항목</b>의 등급을 더 보유하고 있으나,
          항목명 코드 매핑이 확인되기 전까지는 표시하지 않습니다.
          추측해서 이름을 붙이면 잘못된 의료 정보가 되기 때문입니다.</p>` : ''}
      </div>`;
    })()}

    ${departments.length ? `<div class="panel">
      <div class="panel-head"><h3>진료과별 전문의</h3></div>
      <div class="bars">${departments.slice(0, 10).map(dp => `
        <div class="bar"><span>${esc(dp.name)}</span>
          <span class="b-track"><span class="b-fill" style="width:${Math.min(100, dp.sdr_count / Math.max(1, departments[0].sdr_count) * 100)}%"></span></span>
          <span class="b-val">${n(dp.sdr_count)}</span></div>`).join('')}</div>
    </div>` : ''}

    ${doctors.length ? `<div class="panel">
      <div class="panel-head"><h3>의료진</h3><span class="hint">병원 공표 정보</span></div>
      <table class="grades"><tbody>${doctors.map(dc => `<tr>
        <td><b>${esc(dc.name)}</b> ${esc(dc.title || '')}<div style="font-size:12px;color:var(--ink-faint)">${esc(dc.focus_areas || '')}</div></td>
        <td class="g"><a class="text-link" href="${esc(dc.profile_url)}" target="_blank" rel="noopener">원문 →</a></td>
      </tr>`).join('')}</tbody></table>
      <p style="font-size:12px;color:var(--ink-faint);margin:12px 0 0">
        병원이 공표한 전문진료분야를 그대로 옮긴 것으로, 순위나 우열을 뜻하지 않습니다.
      </p>
    </div>` : ''}

    <div class="panel">
      <div class="panel-head"><h3>대기 시간</h3><span class="hint">이용자 제보 ${wait.sample}건</span></div>
      ${wait.sample ? `<div class="kv">
        <div><div class="k">예약까지 (중앙값)</div><div class="v num">${wait.medianDays != null ? wait.medianDays + '일' : '—'}</div></div>
        <div><div class="k">현장 대기 (중앙값)</div><div class="v num">${wait.medianMinutes != null ? wait.medianMinutes + '분' : '—'}</div></div>
      </div>` : `<div class="empty">아직 제보가 없습니다. 추정치를 만들지 않고 제보만 표시합니다.</div>`}
      <div class="actions-row" style="margin-top:14px">
        <button class="btn btn-outline btn-sm" id="waitBtn">대기시간 제보하기</button>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>이용 경험</h3><span class="hint">비의료적 항목만 · ${n(rs.n)}건</span></div>
      ${rs.n ? `<div class="bars">
        ${[['예약 편의', rs.booking], ['대기 시간', rs.wait], ['설명 충분도', rs.explain], ['시설·주차', rs.facility], ['직원 응대', rs.staff]]
          .map(([label, v]) => `<div class="bar"><span>${label}</span>
            <span class="b-track"><span class="b-fill" style="width:${(v || 0) / 5 * 100}%"></span></span>
            <span class="b-val">${v ?? '—'}</span></div>`).join('')}
      </div>
      ${reviews.length ? `<div style="margin-top:16px;display:flex;flex-direction:column;gap:10px">
        ${reviews.filter(r => r.comment).map(r => `
          <div style="font-size:13.5px;border-top:1px solid var(--line-soft);padding-top:10px">
            <b>${esc(r.nickname)}</b>
            <span style="color:var(--ink-faint);font-size:11.5px"> · ${esc((r.created_at || '').slice(0, 10))}</span>
            <div style="color:var(--ink-soft);margin-top:3px">${esc(r.comment)}</div>
          </div>`).join('')}
      </div>` : ''}`
      : `<div class="empty">아직 후기가 없습니다.</div>`}
      <div class="actions-row" style="margin-top:14px">
        <button class="btn btn-primary btn-sm" id="reviewBtn">이용 경험 남기기</button>
      </div>
      <p style="font-size:12px;color:var(--ink-faint);margin:12px 0 0">
        치료 효과·완치 여부에 대한 후기는 수집하지 않습니다.
      </p>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>더 찾아보기</h3><span class="hint">외부 검색</span></div>
      <p style="font-size:13px;color:var(--ink-soft);margin:0 0 12px">
        후기·이용기는 저희가 모아서 보여드리지 않습니다.
        국내 병원 후기 글은 대가성인 경우가 많아 그대로 노출하면 광고를 신뢰 정보로 만들 수 있고,
        의료법상 치료경험담 게시 제한에도 걸립니다.
        대신 <b>직접 판단하실 수 있도록 검색 결과로 연결</b>해 드립니다.
      </p>
      <div class="actions-row">
        ${extLink(`https://search.naver.com/search.naver?where=view&query=${encodeURIComponent(h.name + ' 후기')}`, '네이버 블로그·카페')}
        ${extLink(`https://search.naver.com/search.naver?where=news&query=${encodeURIComponent(h.name)}`, '뉴스')}
        ${extLink(`https://www.google.com/search?q=${encodeURIComponent(h.name + ' 진료 후기')}`, '구글')}
      </div>
      <p style="font-size:11.5px;color:var(--ink-faint);margin:12px 0 0">
        검색 결과에는 광고·협찬 글이 섞여 있습니다. 치료 효과를 단정하는 글은 특히 주의해서 보세요.
      </p>
    </div>

    <p class="copy">출처 · ${esc(h.source_name || '—')} (${esc(h.source_license || '')})</p>`;

  $('#waitBtn').addEventListener('click', () => openWaitModal(h));
  $('#reviewBtn').addEventListener('click', () => openReviewModal(h));
}

/* ---------- 제보 모달 ---------- */
function starRow(key, label) {
  return `<div class="rate-row"><span>${label}</span><span class="stars" data-key="${key}">
    ${[1, 2, 3, 4, 5].map(i => `
      <input type="radio" name="${key}" id="${key}${i}" value="${i}"${i === 4 ? ' checked' : ''} />
      <label for="${key}${i}" data-i="${i}">★</label>`).join('')}
  </span></div>`;
}

function paintStars(root) {
  root.querySelectorAll('.stars').forEach(g => {
    const v = Number(g.querySelector('input:checked')?.value || 0);
    g.querySelectorAll('label').forEach(l => l.classList.toggle('on', Number(l.dataset.i) <= v));
  });
}

function openReviewModal(h) {
  const nick = localStorage.getItem('wh.nick') || '';
  openModal(`
    <h3>이용 경험 남기기</h3>
    <p class="m-sub">${esc(h.name)} · 예약·대기·설명 등 <b>비의료적 경험</b>만 평가해 주세요.</p>
    <label class="field"><span>닉네임 <span class="field-hint">공개 표시 · 실명·연락처 사용 금지</span></span>
      <input id="rvNick" type="text" maxlength="20" value="${esc(nick)}" placeholder="예: 서초맘" /></label>
    ${starRow('booking', '예약 편의성')}
    ${starRow('wait', '대기 시간')}
    ${starRow('explain', '설명 충분도')}
    ${starRow('facility', '시설·주차')}
    ${starRow('staff', '직원 응대')}
    <label class="field" style="margin-top:12px"><span>한 줄 메모 (선택)</span>
      <input id="rvComment" type="text" maxlength="100" placeholder="예: 주차가 편했어요" /></label>
    <p style="font-size:11.5px;color:var(--ink-faint);margin:0;line-height:1.7">
      치료 효과·완치 여부, 본인의 질환·건강 상태는 적지 말아 주세요.
      의료법상 치료경험담은 수집하지 않으며, 작성하신 내용은 공개됩니다.
      <a class="text-link" href="#/privacy">개인정보처리방침</a>
    </p>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="cx">취소</button>
      <button class="btn btn-primary btn-sm" id="ok">등록</button>
    </div>`, (root) => {
    paintStars(root);
    root.addEventListener('change', () => paintStars(root));
    root.querySelector('#cx').addEventListener('click', closeModal);
    root.querySelector('#ok').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const nickname = root.querySelector('#rvNick').value.trim();
      if (!nickname) return toast('닉네임을 입력해주세요', 'err');
      const pick = (k) => Number(root.querySelector(`input[name="${k}"]:checked`).value);
      btn.disabled = true; btn.textContent = '등록 중…';
      try {
        await api('/api/reviews', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            hospitalId: h.id, nickname,
            booking: pick('booking'), wait: pick('wait'), explain: pick('explain'),
            facility: pick('facility'), staff: pick('staff'),
            comment: root.querySelector('#rvComment').value.trim(),
          }),
        });
        localStorage.setItem('wh.nick', nickname);
        closeModal(); toast('등록되었습니다', 'ok'); loadHospital(h.id);
      } catch (err) { btn.disabled = false; btn.textContent = '등록'; toast(err.message, 'err'); }
    });
  });
}

function openWaitModal(h) {
  openModal(`
    <h3>대기시간 제보</h3>
    <p class="m-sub">${esc(h.name)} · 실제 겪으신 시간을 알려주세요. 둘 중 하나만 적어도 됩니다.</p>
    <label class="field"><span>예약까지 걸린 일수</span>
      <input id="wDays" type="number" min="0" placeholder="예: 14" /></label>
    <label class="field"><span>당일 현장 대기 (분)</span>
      <input id="wMin" type="number" min="0" placeholder="예: 40" /></label>
    <label class="field"><span>방문일 (선택)</span>
      <input id="wDate" type="date" /></label>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="cx">취소</button>
      <button class="btn btn-primary btn-sm" id="ok">제보</button>
    </div>`, (root) => {
    root.querySelector('#cx').addEventListener('click', closeModal);
    root.querySelector('#ok').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const days = root.querySelector('#wDays').value;
      const mins = root.querySelector('#wMin').value;
      if (!days && !mins) return toast('둘 중 하나는 입력해주세요', 'err');
      btn.disabled = true; btn.textContent = '전송 중…';
      try {
        await api('/api/wait-reports', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            hospitalId: h.id,
            waitDays: days === '' ? null : Number(days),
            waitMinutes: mins === '' ? null : Number(mins),
            visitedOn: root.querySelector('#wDate').value || null,
          }),
        });
        closeModal(); toast('제보 감사합니다', 'ok'); loadHospital(h.id);
      } catch (err) { btn.disabled = false; btn.textContent = '제보'; toast(err.message, 'err'); }
    });
  });
}

boot().catch(err => toast('초기화 실패: ' + err.message, 'err'));
