-- ============================================================
--  집값다오 · 기준 데이터 시드
--  시세(listings/price_history)는 수집 파이프라인이 채운다.
-- ============================================================

-- 지역 ----------------------------------------------------------
INSERT INTO regions (code, name, cost_index) VALUES
  ('seoul',   '서울',      1.18),
  ('gyeonggi','경기',      1.06),
  ('incheon', '인천',      1.02),
  ('busan',   '부산',      0.96),
  ('daegu',   '대구',      0.94),
  ('daejeon', '대전',      0.95),
  ('gwangju', '광주',      0.93),
  ('ulsan',   '울산',      0.97),
  ('sejong',  '세종',      0.99),
  ('gangwon', '강원',      0.92),
  ('chungbuk','충북',      0.91),
  ('chungnam','충남',      0.92),
  ('jeonbuk', '전북',      0.90),
  ('jeonnam', '전남',      0.90),
  ('gyeongbuk','경북',     0.91),
  ('gyeongnam','경남',     0.93),
  ('jeju',    '제주',      1.09);

-- 카테고리 ------------------------------------------------------
INSERT INTO categories (slug, name, unit, icon, sort_order) VALUES
  ('wallpaper', '벽지·도배',   '평', '🧱', 1),
  ('flooring',  '바닥재·장판', '평', '🪵', 2),
  ('kitchen',   '주방·씽크대', '식', '🍳', 3),
  ('bathroom',  '욕실',        '식', '🚿', 4),
  ('tile',      '타일',        '평', '◻️', 5),
  ('lighting',  '조명',        '식', '💡', 6),
  ('window',    '창호',        '㎡', '🪟', 7),
  ('paint',     '페인트·도장', '평', '🎨', 8);

-- 트렌드 스타일 -------------------------------------------------
-- popularity / trend_delta 는 수집 시 갱신되는 상대 지표.
INSERT INTO styles (slug, name, tagline, description, image_url, popularity, trend_delta, source_note) VALUES
  ('geunbon', '근본이즘',
   '본질만 남기는 정직한 마감',
   '트렌드 코리아 2026이 짚은 흐름. 겉치레를 덜어내고 소재 본연의 질감과 구조를 드러냅니다. 무몰딩·히든도어처럼 선을 지우는 마감과 잘 맞습니다.',
   'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=900', 96, 14,
   'LX Z:IN · 트렌드 코리아 2026'),

  ('warm-minimal', '웜 미니멀',
   '따뜻한 뉴트럴, 차갑지 않은 미니멀',
   '백색 일변도에서 벗어나 크림·오트밀·샌드 계열을 바탕색으로 씁니다. 우드 톤 바닥과 결합해 유행을 덜 타는 조합으로 자리 잡았습니다.',
   'https://images.unsplash.com/photo-1615529182904-14819c35db37?w=900', 92, 8,
   '오늘의집 2026 인테리어 트렌드'),

  ('natural-material', '천연 소재',
   '코르크·대나무·천연 벽지',
   'PVC·합성 소재 대신 천연 소재를 택하는 흐름. 코르크와 대나무 바닥재, 천연 펄프 벽지가 대표적이며 실내 공기질을 중시하는 수요와 맞물립니다.',
   'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=900', 84, 21,
   '월간 THE LIVING 2026 자재 트렌드'),

  ('stone-texture', '스톤 텍스처',
   '천연 석재의 질감을 벽으로',
   '대리석·석재의 시각적·촉각적 질감을 보드에 구현한 하이엔드 벽장재가 거실 아트월과 주방 백스플래시로 확산되고 있습니다.',
   'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=900', 78, 11,
   '월간 THE LIVING 2026 자재 트렌드'),

  ('unfitted-kitchen', '소박한 주방',
   '빌트인을 덜어낸 주방',
   '컬러풀한 풀빌트인에서 벗어나 가구처럼 놓는 소박한 주방으로 회귀하는 중. 요리 공간을 넘어 가족이 머무는 공간으로 재편되고 있습니다.',
   'https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=900', 81, 17,
   '오늘의집 2026 인테리어 트렌드'),

  ('modern-korean', '모던 한국',
   '떡살무늬·단청을 오늘의 문법으로',
   '떡살무늬나 단청 문양을 현대적으로 재해석한 벽지와 패브릭이 포인트 요소로 쓰입니다. 과하지 않게 한 면에만 적용하는 방식이 주류입니다.',
   'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=900', 64, 9,
   'LX Z:IN 스타일 트렌드'),

  ('wood-stone', '우드 & 스톤',
   '유행을 덜 타는 기본값',
   '우드·스톤 계열의 색과 질감은 유행의 영향을 적게 받아 공간을 오래 편안하게 유지합니다. 재시공 주기를 늘리려는 실수요에서 꾸준히 선택됩니다.',
   'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900', 88, 4,
   'LX Z:IN 스타일 트렌드'),

  ('hybrid-durable', '하이브리드 내수',
   '주방·욕실까지 쓰는 바닥재',
   '합성층과 천연층을 조합해 내수성·내구성을 높인 하이브리드 바닥재. 주방, 욕실, 베란다까지 한 자재로 이어 시공하는 사례가 늘고 있습니다.',
   'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=900', 71, 19,
   '월간 THE LIVING 2026 자재 트렌드');

-- 수집원 --------------------------------------------------------
-- license 필드에 수집 근거를 명시한다. 근거 없는 소스는 추가하지 않는다.
INSERT INTO sources (slug, name, adapter, base_url, license, enabled, config) VALUES
  ('g2b-price', '조달청 시설공통자재 가격정보', 'g2bPrice',
   'https://apis.data.go.kr/1230000/PrdctPriceInfoService',
   '공공데이터포털 오픈API · 이용허락범위 제한없음', 0,
   '{"note":"data.go.kr 에서 발급받은 serviceKey 를 G2B_SERVICE_KEY 시크릿으로 등록하면 활성화됩니다."}'),

  ('partner-feed', '제휴사 상품 피드', 'partnerFeed', NULL,
   '제휴 계약에 따른 상품 피드(JSON/CSV) 수신', 0,
   '{"note":"제휴사에서 받은 피드 URL 을 config.feedUrl 에 넣고 enabled=1 로 바꾸세요."}'),

  ('vendor-submit', '업체 직접 등록', 'vendorSubmit', NULL,
   '업체가 본인 견적을 직접 등록 (약관 동의)', 1,
   '{"note":"/api/vendor/listings 로 업체가 직접 올린 견적"}'),

  ('sample', '샘플 시세 생성기', 'sample', NULL,
   '데모용 합성 데이터 · 실제 거래가 아님', 1,
   '{"note":"실제 수집원을 붙이기 전까지 화면을 채우는 용도"}');

-- 제품/자재 -----------------------------------------------------
-- source_id 4 = sample. 실제 수집 데이터로 교체되면 출처가 바뀐다.
INSERT INTO products (category_id, name, brand, spec, image_url, source_id) VALUES
  (1, '합지벽지 도배 시공', '국내산 합지', '2.5평 1롤 · 초배 포함',
     'https://images.unsplash.com/photo-1620626011761-996317b8d101?w=700', 4),
  (1, '실크벽지 도배 시공', '프리미엄 실크', '5평 1롤 · 초배 포함',
     'https://images.unsplash.com/photo-1615873968403-89e068629265?w=700', 4),
  (1, '천연 펄프 벽지 시공', '친환경 천연지', 'PVC 무첨가 · 저VOC',
     'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=700', 4),
  (1, '석재 질감 벽장재', '하이엔드 보드', '대리석 패턴 · 아트월용',
     'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=700', 4),

  (2, '모노륨 장판 1.8mm', '표준형', '친환경 등급 · 걸레받이 별도',
     'https://images.unsplash.com/photo-1615971677499-5467cbab01c0?w=700', 4),
  (2, '모노륨 장판 2.2mm', '보급형 두께업', '층간소음 완화 · 걸레받이 별도',
     'https://images.unsplash.com/photo-1585128792020-803d29415281?w=700', 4),
  (2, '강화마루 시공', '8mm 클릭형', '생활방수 · 철거 별도',
     'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=700', 4),
  (2, '강마루 시공', '합판마루', '접착식 · 철거 별도',
     'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=700', 4),
  (2, 'SPC 하이브리드 바닥재', '내수 강화형', '주방·욕실 연속 시공 가능',
     'https://images.unsplash.com/photo-1503389152951-9f343605f61e?w=700', 4),
  (2, '코르크 바닥재', '천연 코르크', '단열·흡음 · 저VOC',
     'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=700', 4),

  (3, '주방 상하부장 3.6m', 'PET 도어', '인조대리석 상판 포함 · 철거 별도',
     'https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=700', 4),
  (3, '주방 상하부장 3.6m 하이글로시', '하이글로시 도어', '인조대리석 상판 포함',
     'https://images.unsplash.com/photo-1600489000022-c2086d79f9d4?w=700', 4),
  (3, '아일랜드 식탁 제작', '원목 상판', '1.2m · 콘센트 매립 옵션',
     'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=700', 4),

  (4, '욕실 전체 리모델링', '표준 패키지', '철거·방수·타일·도기·수전 일괄',
     'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=700', 4),

  (5, '포세린 타일 600각 시공', '수입 포세린', '거실·주방 바닥',
     'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=700', 4),
  (5, '헥사곤 타일 시공', '무광 헥사곤', '욕실·주방 벽면 포인트',
     'https://images.unsplash.com/photo-1584622781564-1d987f7333c1?w=700', 4),

  (6, '무타공 레일조명', '트랙 3m', 'LED 스팟 6구 · 조광 옵션',
     'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700', 4),

  (7, '이중창 교체 (PVC)', '시스템 이중창', '24mm 로이유리 · 철거 포함',
     'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=700', 4),

  (8, '친환경 수성페인트 도장', '저VOC 수성', '2회 도장 · 퍼티 별도',
     'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=700', 4);

-- 제품 × 스타일 매핑 --------------------------------------------
INSERT INTO product_styles (product_id, style_id) VALUES
  (2, 1), (2, 2),
  (3, 3), (3, 2),
  (4, 4), (4, 1),
  (1, 2),
  (5, 2), (6, 2),
  (7, 7), (8, 7), (8, 1),
  (9, 8), (9, 7),
  (10, 3), (10, 8),
  (11, 5), (11, 2),
  (12, 5),
  (13, 5), (13, 7),
  (14, 4),
  (15, 4), (15, 7),
  (16, 6), (16, 4),
  (17, 1),
  (18, 1),
  (19, 3), (19, 2);
