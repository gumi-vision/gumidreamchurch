-- ============================================================
--  집값다오 · Interior material price & negotiation marketplace
--  D1 (SQLite) schema
-- ============================================================

DROP TABLE IF EXISTS bids;
DROP TABLE IF EXISTS price_history;
DROP TABLE IF EXISTS listings;
DROP TABLE IF EXISTS product_styles;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS styles;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS regions;
DROP TABLE IF EXISTS crawl_runs;
DROP TABLE IF EXISTS sources;

-- 지역 (시·도) --------------------------------------------------
CREATE TABLE regions (
  id        INTEGER PRIMARY KEY,
  code      TEXT NOT NULL UNIQUE,
  name      TEXT NOT NULL,
  -- 수도권 대비 자재·인건비 가중치. 시세 추정 및 지역 비교에 사용.
  cost_index REAL NOT NULL DEFAULT 1.0
);

-- 자재 카테고리 -------------------------------------------------
CREATE TABLE categories (
  id         INTEGER PRIMARY KEY,
  slug       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  -- 가격 비교 단위: 평, m, 개, 식(일괄)
  unit       TEXT NOT NULL,
  icon       TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- 트렌드 스타일 -------------------------------------------------
CREATE TABLE styles (
  id          INTEGER PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  tagline     TEXT,
  description TEXT,
  image_url   TEXT,
  -- 검색량/저장수 기반 인기 점수 (수집 시 갱신)
  popularity  INTEGER NOT NULL DEFAULT 0,
  trend_delta INTEGER NOT NULL DEFAULT 0,
  source_note TEXT,
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 제품/자재 -----------------------------------------------------
CREATE TABLE products (
  id           INTEGER PRIMARY KEY,
  category_id  INTEGER NOT NULL REFERENCES categories(id),
  name         TEXT NOT NULL,
  brand        TEXT,
  spec         TEXT,
  image_url    TEXT,
  -- 출처 추적: 어떤 수집원에서 왔는지 항상 남긴다
  source_id    INTEGER REFERENCES sources(id),
  source_url   TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_products_category ON products(category_id);

CREATE TABLE product_styles (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  style_id   INTEGER NOT NULL REFERENCES styles(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, style_id)
);

-- 업체 견적 (ask) ------------------------------------------------
-- 크림의 "즉시 구매가"에 해당. 업체가 걸어둔 판매/시공 호가.
CREATE TABLE listings (
  id          INTEGER PRIMARY KEY,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  region_id   INTEGER NOT NULL REFERENCES regions(id),
  vendor      TEXT NOT NULL,
  price       INTEGER NOT NULL,
  unit        TEXT NOT NULL,
  min_qty     REAL NOT NULL DEFAULT 1,
  includes_labor INTEGER NOT NULL DEFAULT 1,
  status      TEXT NOT NULL DEFAULT 'open',   -- open | matched | closed
  source_id   INTEGER REFERENCES sources(id),
  source_url  TEXT,
  captured_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_listings_product ON listings(product_id, region_id, status);
CREATE INDEX idx_listings_price   ON listings(product_id, price);

-- 소비자 입찰 (bid) ---------------------------------------------
-- 크림의 "즉시 판매가"에 해당. 소비자가 제시한 희망가.
CREATE TABLE bids (
  id          INTEGER PRIMARY KEY,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  region_id   INTEGER NOT NULL REFERENCES regions(id),
  bidder      TEXT NOT NULL,
  price       INTEGER NOT NULL,
  qty         REAL NOT NULL DEFAULT 1,
  memo        TEXT,
  status      TEXT NOT NULL DEFAULT 'open',   -- open | matched | expired
  matched_listing_id INTEGER REFERENCES listings(id),
  expires_at  TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_bids_product ON bids(product_id, region_id, status);

-- 일별 시세 스냅샷 ----------------------------------------------
CREATE TABLE price_history (
  id          INTEGER PRIMARY KEY,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  region_id   INTEGER NOT NULL REFERENCES regions(id),
  captured_on TEXT NOT NULL,                  -- YYYY-MM-DD
  low_price   INTEGER NOT NULL,
  avg_price   INTEGER NOT NULL,
  high_price  INTEGER NOT NULL,
  sample_size INTEGER NOT NULL DEFAULT 0,
  UNIQUE (product_id, region_id, captured_on)
);
CREATE INDEX idx_history_lookup ON price_history(product_id, region_id, captured_on);

-- 수집원 --------------------------------------------------------
CREATE TABLE sources (
  id          INTEGER PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  -- adapter 이름. src/crawler.js 의 ADAPTERS 키와 일치해야 한다.
  adapter     TEXT NOT NULL,
  base_url    TEXT,
  -- 수집 근거를 남겨 법적 검토를 추적 가능하게 한다.
  license     TEXT NOT NULL,
  enabled     INTEGER NOT NULL DEFAULT 1,
  config      TEXT,                            -- JSON
  last_run_at TEXT
);

CREATE TABLE crawl_runs (
  id          INTEGER PRIMARY KEY,
  source_id   INTEGER REFERENCES sources(id),
  started_at  TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  status      TEXT NOT NULL DEFAULT 'running', -- running | ok | error | skipped
  inserted    INTEGER NOT NULL DEFAULT 0,
  updated     INTEGER NOT NULL DEFAULT 0,
  message     TEXT
);
CREATE INDEX idx_runs_source ON crawl_runs(source_id, started_at);
