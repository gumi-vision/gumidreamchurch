/* ============================================================
   집값다오 · 프론트엔드
   ============================================================ */

const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const state = {
  region: localStorage.getItem('im.region') || 'seoul',
  category: null,
  style: null,
  sort: 'popular',
  q: '',
  bootstrap: null,
};

/* ---------- 포맷 ---------- */
const won = (n) => n == null ? '—' : Number(n).toLocaleString('ko-KR') + '원';
function compact(n) {
  if (n == null) return '—';
  if (n >= 1_000_000) return (n / 10_000).toFixed(0) + '만';
  if (n >= 10_000) return (n / 10_000).toFixed(1).replace(/\.0$/, '') + '만';
  return Number(n).toLocaleString('ko-KR');
}

/* ---------- Toast ---------- */
function toast(msg, kind = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $('#toastStack').appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

/* ---------- Theme ---------- */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('im.theme', t);
  const b = $('#themeToggle');
  if (b) b.setAttribute('aria-label', t === 'dark' ? '밝은 테마로 전환' : '어두운 테마로 전환');
}
applyTheme(localStorage.getItem('im.theme')
  || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

/* ---------- Modal ---------- */
function openModal(html, onMount) {
  const backdrop = $('#modal');
  $('#modalBody').innerHTML = html;
  backdrop.hidden = false;
  if (onMount) onMount($('#modalBody'));
  const first = $('#modalBody').querySelector('input, select, textarea, button');
  if (first) first.focus();
}
function closeModal() { $('#modal').hidden = true; }
$('#modal').addEventListener('click', e => { if (e.target === e.currentTarget) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

/* ---------- API ---------- */
async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `요청 실패 (${res.status})`);
  return data;
}

/* ---------- 부트스트랩 ---------- */
async function boot() {
  state.bootstrap = await api('/api/bootstrap');
  const { regions, categories, styles, freshness } = state.bootstrap;

  $('#regionSelect').innerHTML = regions
    .map(r => `<option value="${r.code}"${r.code === state.region ? ' selected' : ''}>${esc(r.name)}</option>`)
    .join('');

  $('#catTabs').innerHTML =
    `<button class="chip active" data-cat="">전체</button>` +
    categories.map(c => `<button class="chip" data-cat="${c.slug}">${c.icon} ${esc(c.name)}</button>`).join('');

  $('#styleRail').innerHTML = styles.map((s, i) => `
    <button class="style-card" data-style="${s.slug}">
      <div class="s-img"><img src="${esc(s.image_url)}" alt="${esc(s.name)} 스타일 예시" loading="lazy" /></div>
      <div class="s-body">
        <div class="s-top">
          <h3>${esc(s.name)}</h3>
          <span class="rank-pill ${s.trend_delta >= 15 ? 'hot' : ''}">${s.trend_delta >= 15 ? '급상승' : '#' + (i + 1)}</span>
        </div>
        <span class="s-tag">${esc(s.tagline)}</span>
        <span class="s-src">출처 · ${esc(s.source_note || '—')}</span>
      </div>
    </button>`).join('');

  if (freshness?.latest) {
    $('#freshness').innerHTML =
      `최종 수집 <b>${esc(freshness.latest)}</b> · 열린 호가 <b>${Number(freshness.open_listings).toLocaleString('ko-KR')}</b>건`;
  } else {
    $('#freshness').textContent = '아직 수집된 시세가 없습니다';
  }

  $('#footNote').innerHTML =
    '시세는 수집원에서 받은 참고용 데이터로, 실제 계약가는 현장 실측·자재 등급·시공 난이도에 따라 달라집니다. ' +
    '수집원과 이용 근거는 <a href="/api/status" target="_blank" rel="noopener">수집 상태</a>에서 확인할 수 있습니다.';

  bindEvents();
  route();
}

function bindEvents() {
  $('#regionSelect').addEventListener('change', e => {
    state.region = e.target.value;
    localStorage.setItem('im.region', state.region);
    route();
  });

  $('#catTabs').addEventListener('click', e => {
    const btn = e.target.closest('[data-cat]');
    if (!btn) return;
    state.category = btn.dataset.cat || null;
    $('#catTabs').querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c === btn));
    loadProducts();
  });

  $('#styleRail').addEventListener('click', e => {
    const btn = e.target.closest('[data-style]');
    if (!btn) return;
    const slug = btn.dataset.style;
    state.style = state.style === slug ? null : slug;
    $('#styleRail').querySelectorAll('.style-card')
      .forEach(c => c.classList.toggle('active', c.dataset.style === state.style));
    $('#clearStyle').hidden = !state.style;
    loadProducts();
  });

  $('#clearStyle').addEventListener('click', () => {
    state.style = null;
    $('#styleRail').querySelectorAll('.style-card').forEach(c => c.classList.remove('active'));
    $('#clearStyle').hidden = true;
    loadProducts();
  });

  $('#sortSelect').addEventListener('change', e => { state.sort = e.target.value; loadProducts(); });

  let t;
  $('#searchInput').addEventListener('input', e => {
    clearTimeout(t);
    t = setTimeout(() => { state.q = e.target.value.trim(); loadProducts(); }, 250);
  });

  $('#themeToggle').addEventListener('click', () => {
    applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
  });

  $('#disclaimerLink').addEventListener('click', e => { e.preventDefault(); showDisclaimer(); });

  window.addEventListener('hashchange', route);
}

/* ---------- 라우팅 ---------- */
function route() {
  const hash = location.hash || '#/';
  const m = hash.match(/^#\/p\/(\d+)/);
  if (m) {
    $('#view-list').hidden = true;
    $('#view-detail').hidden = false;
    loadDetail(Number(m[1]));
  } else {
    $('#view-detail').hidden = true;
    $('#view-list').hidden = false;
    loadProducts();
  }
  window.scrollTo(0, 0);
}

/* ---------- 목록 ---------- */
function skeletonGrid(n = 8) {
  return Array.from({ length: n }, () => `
    <div class="sk-card">
      <div class="sk sk-img"></div>
      <div class="sk-body">
        <div class="sk sk-line" style="width:80%"></div>
        <div class="sk sk-line" style="width:50%"></div>
        <div class="sk sk-line" style="width:65%"></div>
      </div>
    </div>`).join('');
}

async function loadProducts() {
  const grid = $('#productGrid');
  grid.innerHTML = skeletonGrid();
  $('#emptyState').hidden = true;

  const p = new URLSearchParams({ region: state.region, sort: state.sort });
  if (state.category) p.set('category', state.category);
  if (state.style) p.set('style', state.style);
  if (state.q) p.set('q', state.q);

  try {
    const data = await api('/api/products?' + p);
    renderTicker(data.products);

    const regionName = state.bootstrap.regions.find(r => r.code === state.region)?.name || '';
    $('#resultLine').innerHTML = `${esc(regionName)} 기준 <b>${data.count}</b>개 자재`;

    if (!data.products.length) {
      grid.innerHTML = '';
      $('#emptyState').hidden = false;
      return;
    }
    grid.innerHTML = data.products.map(cardHtml).join('');
  } catch (err) {
    grid.innerHTML = '';
    $('#emptyState').hidden = false;
    toast(err.message, 'err');
  }
}

function deltaBadge(pct) {
  if (pct == null) return '';
  const cls = pct < 0 ? 'down' : pct > 0 ? 'up' : '';
  if (!cls) return '';
  return `<span class="delta-badge ${cls}">${pct > 0 ? '▲' : '▼'} ${Math.abs(pct)}%</span>`;
}

function cardHtml(p) {
  return `
    <article class="card">
      <div class="c-img">
        <img src="${esc(p.image_url)}" alt="${esc(p.name)}" loading="lazy" decoding="async"
             onerror="this.style.visibility='hidden'" />
        <span class="c-cat">${esc(p.category)}</span>
        ${deltaBadge(p.change_pct)}
      </div>
      <div class="c-body">
        <h3><a class="card-link" href="#/p/${p.id}" aria-label="${esc(p.name)} 상세"></a>${esc(p.name)}</h3>
        <div class="c-spec">${esc(p.spec || p.brand || '')}</div>
        <div class="quote-rows">
          <div class="qrow ask">
            <span class="q-label">즉시 시공가</span>
            ${p.ask == null
              ? '<span class="q-none">호가 없음</span>'
              : `<span class="q-val num">${compact(p.ask)}<span class="q-unit">원/${esc(p.unit)}</span></span>`}
          </div>
          <div class="qrow bid">
            <span class="q-label">최고 입찰가</span>
            ${p.bid == null
              ? '<span class="q-none">입찰 없음</span>'
              : `<span class="q-val num">${compact(p.bid)}<span class="q-unit">원/${esc(p.unit)}</span></span>`}
          </div>
        </div>
      </div>
    </article>`;
}

function renderTicker(products) {
  const picks = products.filter(p => p.ask != null).slice(0, 5);
  if (!picks.length) { $('#tickerRail').innerHTML = ''; return; }
  $('#tickerRail').innerHTML = picks.map(p => {
    const d = p.change_pct;
    const cls = d == null || d === 0 ? 'flat' : d < 0 ? 'down' : 'up';
    const label = d == null ? '변동 없음' : `${d > 0 ? '▲' : d < 0 ? '▼' : '—'} ${Math.abs(d)}%`;
    return `
      <div class="tick">
        <span class="t-name">${esc(p.name)}</span>
        <span class="t-price num">${compact(p.ask)}<span class="t-unit">원/${esc(p.unit)}</span></span>
        <span class="t-delta ${cls}">${label}</span>
      </div>`;
  }).join('');
}

/* ---------- 상세 ---------- */
async function loadDetail(id) {
  const root = $('#detailRoot');
  root.innerHTML = `<div class="back-link">← 돌아가기</div><div class="sk" style="height:340px;border-radius:18px"></div>`;

  let d;
  try {
    d = await api(`/api/products/${id}?region=${encodeURIComponent(state.region)}`);
  } catch (err) {
    root.innerHTML = `<a class="back-link" href="#/">← 목록으로</a>
      <div class="empty"><div class="emoji">🔍</div><h3>${esc(err.message)}</h3></div>`;
    return;
  }

  const { product, region, asks, bids, history, byRegion, styles } = d;
  const bestAsk = asks[0]?.price ?? null;
  const bestBid = bids[0]?.price ?? null;
  const spread = bestAsk != null && bestBid != null ? bestAsk - bestBid : null;

  root.innerHTML = `
    <a class="back-link" href="#/">← 목록으로</a>

    <div class="detail-top">
      <div class="detail-hero">
        <img src="${esc(product.image_url)}" alt="${esc(product.name)}" />
        <div class="detail-meta">
          <span class="tag">${esc(product.category)}</span>
          ${product.brand ? `<span class="tag">${esc(product.brand)}</span>` : ''}
          ${styles.map(s => `<span class="tag style">${esc(s.name)}</span>`).join('')}
        </div>
      </div>

      <div>
        <span class="eyebrow">${esc(region.name)} 기준</span>
        <h1 class="detail-title">${esc(product.name)}</h1>
        <p class="detail-sub">${esc(product.spec || '')}</p>

        <div class="quote-board">
          <div class="qb ask">
            <span class="qb-label">즉시 시공가</span>
            <span class="qb-price num">${bestAsk == null ? '—' : Number(bestAsk).toLocaleString('ko-KR')}<span class="qb-unit">원/${esc(product.unit)}</span></span>
            <span class="qb-sub">${asks.length}개 업체 호가 중 최저</span>
          </div>
          <div class="qb bid">
            <span class="qb-label">최고 입찰가</span>
            <span class="qb-price num">${bestBid == null ? '—' : Number(bestBid).toLocaleString('ko-KR')}<span class="qb-unit">원/${esc(product.unit)}</span></span>
            <span class="qb-sub">${bids.length}건 입찰 중 최고</span>
          </div>
        </div>

        <div class="spread-note">
          <span aria-hidden="true">💡</span>
          <div>${spread == null
            ? '아직 양쪽 호가가 모이지 않았어요. 희망가를 걸어두면 업체가 맞춰올 때 자동으로 체결됩니다.'
            : spread <= 0
              ? '<b>지금 바로 체결 가능한 구간</b>입니다. 입찰가가 시공가에 도달했어요.'
              : `현재 <b>${Number(spread).toLocaleString('ko-KR')}원</b>의 간극이 있어요. 이 사이에 희망가를 걸면 흥정이 시작됩니다.`}
          </div>
        </div>

        <div class="detail-actions">
          <button class="btn btn-bid" id="bidBtn">희망가 걸기</button>
          <button class="btn btn-outline" id="vendorBtn">업체 견적 등록</button>
        </div>
      </div>
    </div>

    <div class="chart-card">
      <div class="panel-head">
        <h3>시세 추이 · ${esc(region.name)}</h3>
        <span class="hint">최저가 기준 · 일 1회 수집</span>
      </div>
      ${chartHtml(history)}
    </div>

    <div class="book">
      <div class="panel">
        <div class="panel-head"><h3>업체 호가</h3><span class="hint">낮은 순</span></div>
        ${asks.length ? `<div class="book-list">${asks.map((a, i) => `
          <div class="book-row ${i === 0 ? 'best' : ''}">
            <div class="b-who">${esc(a.vendor)}<div class="b-sub">${a.includes_labor ? '시공 포함' : '자재만'} · ${esc(a.source || '—')}</div></div>
            <div class="b-price num">${Number(a.price).toLocaleString('ko-KR')}</div>
          </div>`).join('')}</div>`
          : '<div class="book-list"><div class="book-empty">등록된 호가가 없습니다</div></div>'}
      </div>

      <div class="panel">
        <div class="panel-head"><h3>희망가 입찰</h3><span class="hint">높은 순</span></div>
        ${bids.length ? `<div class="book-list bids">${bids.map((b, i) => `
          <div class="book-row ${i === 0 ? 'best' : ''}">
            <div class="b-who">${esc(b.bidder)}<div class="b-sub">${esc(b.memo || '희망가 대기 중')}</div></div>
            <div class="b-price num">${Number(b.price).toLocaleString('ko-KR')}</div>
          </div>`).join('')}</div>`
          : '<div class="book-list bids"><div class="book-empty">아직 입찰이 없습니다. 첫 희망가를 걸어보세요.</div></div>'}
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>지역별 최저 시공가</h3><span class="hint">${byRegion.length}개 지역</span></div>
      ${regionBars(byRegion, region.code)}
    </div>

    <p class="copy" style="border:0;padding-top:8px">
      출처 · ${esc(product.source_name || '—')} (${esc(product.source_license || '근거 미기재')})
    </p>`;

  $('#bidBtn').addEventListener('click', () => openBidModal(product, region, bestAsk));
  $('#vendorBtn').addEventListener('click', () => openVendorModal(product, region));
}

/* ---------- 차트 (의존성 없이 직접 그림) ---------- */
function chartHtml(history) {
  if (!history || history.length < 2) {
    return `<div class="chart-empty">시세 데이터를 모으는 중입니다 · 수집 2일차부터 추이가 표시됩니다</div>`;
  }
  const W = 800, H = 150, PAD = 8;
  const lows = history.map(h => h.low_price);
  const min = Math.min(...lows), max = Math.max(...lows);
  const span = max - min || 1;

  const pts = history.map((h, i) => {
    const x = PAD + (i / (history.length - 1)) * (W - PAD * 2);
    const y = PAD + (1 - (h.low_price - min) / span) * (H - PAD * 2);
    return [x, y];
  });

  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = `${line} L${pts.at(-1)[0].toFixed(1)},${H} L${pts[0][0].toFixed(1)},${H} Z`;
  const last = pts.at(-1);
  const first = history[0].low_price, latest = history.at(-1).low_price;
  const pct = ((latest - first) / first * 100).toFixed(1);
  const rising = latest >= first;

  return `
    <div class="chart-wrap">
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img"
           aria-label="최근 ${history.length}일 최저가 추이, ${pct}% 변동">
        <defs>
          <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="var(--brand)" stop-opacity=".26" />
            <stop offset="100%" stop-color="var(--brand)" stop-opacity="0" />
          </linearGradient>
        </defs>
        <path d="${area}" fill="url(#cg)" />
        <path d="${line}" fill="none" stroke="var(--brand)" stroke-width="2"
              stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" />
        <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="4"
                fill="var(--brand)" stroke="var(--surface)" stroke-width="2" vector-effect="non-scaling-stroke" />
      </svg>
      <div class="panel-head" style="margin:12px 0 0">
        <span class="hint">${esc(history[0].captured_on)} → ${esc(history.at(-1).captured_on)}</span>
        <span class="num" style="font-weight:700;color:${rising ? 'var(--ask)' : 'var(--down)'}">
          ${rising ? '▲' : '▼'} ${Math.abs(pct)}% · ${Number(latest).toLocaleString('ko-KR')}원
        </span>
      </div>
    </div>`;
}

function regionBars(rows, currentCode) {
  if (!rows.length) return '<div class="chart-empty">지역 시세가 아직 없습니다</div>';
  const max = Math.max(...rows.map(r => r.ask));
  return `<div class="region-bars">${rows.map(r => `
    <div class="rbar ${r.code === currentCode ? 'is-current' : ''}">
      <span class="r-name">${esc(r.name)}</span>
      <span class="r-track"><span class="r-fill" style="width:${(r.ask / max * 100).toFixed(1)}%"></span></span>
      <span class="r-price num">${compact(r.ask)}</span>
    </div>`).join('')}</div>`;
}

/* ---------- 입찰 ---------- */
function openBidModal(product, region, bestAsk) {
  const nick = localStorage.getItem('im.nick') || '';
  const suggested = bestAsk ? Math.round(bestAsk * 0.9 / 1000) * 1000 : '';

  openModal(`
    <h3>희망가 걸기</h3>
    <p class="m-sub">${esc(product.name)} · ${esc(region.name)}</p>
    ${bestAsk ? `<div class="price-preview">
      <span>현재 즉시 시공가</span><b>${Number(bestAsk).toLocaleString('ko-KR')}원/${esc(product.unit)}</b>
    </div>` : ''}
    <label class="field"><span>닉네임</span>
      <input id="bidNick" type="text" maxlength="20" value="${esc(nick)}" placeholder="예: 신혼집준비" />
    </label>
    <label class="field"><span>희망가 <span class="field-hint">(${esc(product.unit)}당)</span></span>
      <input id="bidPrice" type="number" min="1" step="1000" value="${suggested}" />
    </label>
    <label class="field"><span>수량 <span class="field-hint">(${esc(product.unit)})</span></span>
      <input id="bidQty" type="number" min="1" step="0.5" value="1" />
    </label>
    <label class="field"><span>메모 <span class="field-hint">(선택)</span></span>
      <input id="bidMemo" type="text" maxlength="60" placeholder="예: 10월 중 시공 희망" />
    </label>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="cancelBid">취소</button>
      <button class="btn btn-bid btn-sm" id="submitBid">입찰하기</button>
    </div>`, (root) => {
    root.querySelector('#cancelBid').addEventListener('click', closeModal);
    root.querySelector('#submitBid').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const bidder = root.querySelector('#bidNick').value.trim();
      const price = Number(root.querySelector('#bidPrice').value);
      const qty = Number(root.querySelector('#bidQty').value) || 1;
      const memo = root.querySelector('#bidMemo').value.trim();

      if (!bidder) return toast('닉네임을 입력해주세요', 'err');
      if (!price || price <= 0) return toast('희망가를 입력해주세요', 'err');

      btn.disabled = true;
      btn.textContent = '전송 중…';
      try {
        const r = await api('/api/bids', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId: product.id, region: region.code, bidder, price, qty, memo }),
        });
        localStorage.setItem('im.nick', bidder);
        closeModal();
        if (r.matched) {
          toast(`체결! ${r.matchedWith.vendor} · ${Number(r.matchedWith.price).toLocaleString('ko-KR')}원`, 'ok');
        } else {
          toast('입찰 등록 완료 · 업체가 맞춰오면 자동 체결됩니다', 'ok');
        }
        loadDetail(product.id);
      } catch (err) {
        btn.disabled = false;
        btn.textContent = '입찰하기';
        toast(err.message, 'err');
      }
    });
  });
}

function openVendorModal(product, region) {
  openModal(`
    <h3>업체 견적 등록</h3>
    <p class="m-sub">${esc(product.name)} · ${esc(region.name)}</p>
    <label class="field"><span>업체명</span>
      <input id="vName" type="text" maxlength="40" placeholder="예: 한결시공" />
    </label>
    <label class="field"><span>견적가 <span class="field-hint">(${esc(product.unit)}당)</span></span>
      <input id="vPrice" type="number" min="1" step="1000" />
    </label>
    <label class="field"><span>시공 포함 여부</span>
      <select id="vLabor">
        <option value="1">시공 포함</option>
        <option value="0">자재만</option>
      </select>
    </label>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="cancelV">취소</button>
      <button class="btn btn-primary btn-sm" id="submitV">등록</button>
    </div>`, (root) => {
    root.querySelector('#cancelV').addEventListener('click', closeModal);
    root.querySelector('#submitV').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const vendor = root.querySelector('#vName').value.trim();
      const price = Number(root.querySelector('#vPrice').value);
      const includesLabor = root.querySelector('#vLabor').value === '1';
      if (!vendor || !price) return toast('업체명과 견적가를 입력해주세요', 'err');

      btn.disabled = true; btn.textContent = '등록 중…';
      try {
        await api('/api/vendor/listings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId: product.id, region: region.code, vendor, price, includesLabor }),
        });
        closeModal();
        toast('견적이 등록되었습니다', 'ok');
        loadDetail(product.id);
      } catch (err) {
        btn.disabled = false; btn.textContent = '등록';
        toast(err.message, 'err');
      }
    });
  });
}

function showDisclaimer() {
  const srcs = state.bootstrap?.styles?.length ? '' : '';
  openModal(`
    <h3>데이터 출처와 면책</h3>
    <p class="m-sub">이 서비스가 데이터를 다루는 원칙입니다.</p>
    <ul style="font-size:13.5px;line-height:1.75;color:var(--ink-soft);padding-left:18px;margin:0 0 16px">
      <li>모든 시세에는 <b style="color:var(--ink)">수집원과 이용 근거</b>가 함께 기록됩니다.</li>
      <li>공식 오픈API·제휴 피드·업체 직접등록만 사용하며, 타사 사이트의 사진이나 콘텐츠를 무단 복제하지 않습니다.</li>
      <li>HTML 수집이 필요한 경우 robots.txt를 확인하고 허용된 경로만 수집합니다.</li>
      <li>표시 가격은 참고용이며, 실제 계약가는 실측·자재 등급·시공 난이도에 따라 달라집니다.</li>
    </ul>
    <div class="modal-actions">
      <a class="btn btn-outline btn-sm" href="/api/status" target="_blank" rel="noopener">수집 상태 보기</a>
      <button class="btn btn-primary btn-sm" id="okD">확인</button>
    </div>${srcs}`, (root) => {
    root.querySelector('#okD').addEventListener('click', closeModal);
  });
}

boot().catch(err => {
  document.querySelector('#productGrid').innerHTML = '';
  toast('초기화 실패: ' + err.message, 'err');
});
