import { runIngestion, todayISO } from './crawler.js';

const json = (data, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });

const bad = (message, status = 400) => json({ error: message }, status);

/* ---------- 조회 ---------- */

async function getBootstrap(env) {
  const [regions, categories, styles, freshness] = await Promise.all([
    env.DB.prepare('SELECT code, name FROM regions ORDER BY id').all(),
    env.DB.prepare('SELECT slug, name, unit, icon FROM categories ORDER BY sort_order').all(),
    env.DB.prepare(
      `SELECT slug, name, tagline, description, image_url, popularity, trend_delta, source_note
         FROM styles ORDER BY popularity DESC`
    ).all(),
    env.DB.prepare(
      `SELECT MAX(captured_on) AS latest,
              (SELECT COUNT(*) FROM listings WHERE status = 'open') AS open_listings
         FROM price_history`
    ).first(),
  ]);

  return json({
    regions: regions.results,
    categories: categories.results,
    styles: styles.results,
    freshness,
  });
}

async function getProducts(env, url) {
  const region = url.searchParams.get('region') || 'seoul';
  const category = url.searchParams.get('category');
  const style = url.searchParams.get('style');
  const sort = url.searchParams.get('sort') || 'popular';
  const q = (url.searchParams.get('q') || '').trim();

  const regionRow = await env.DB.prepare('SELECT id FROM regions WHERE code = ?').bind(region).first();
  if (!regionRow) return bad('알 수 없는 지역입니다');
  const rid = regionRow.id;

  const where = [];
  const binds = [rid, rid, rid, rid, rid];
  if (category) { where.push('c.slug = ?'); binds.push(category); }
  if (style) {
    where.push('EXISTS (SELECT 1 FROM product_styles ps JOIN styles s ON s.id = ps.style_id WHERE ps.product_id = p.id AND s.slug = ?)');
    binds.push(style);
  }
  if (q) { where.push('(p.name LIKE ? OR p.brand LIKE ? OR p.spec LIKE ?)'); binds.push(`%${q}%`, `%${q}%`, `%${q}%`); }

  const orderBy = {
    priceAsc:  'ask IS NULL, ask ASC',
    priceDesc: 'ask IS NULL, ask DESC',
    drop:      'change_pct IS NULL, change_pct ASC',
    popular:   'c.sort_order, p.id',
  }[sort] || 'c.sort_order, p.id';

  const { results } = await env.DB.prepare(
    `SELECT p.id, p.name, p.brand, p.spec, p.image_url,
            c.name AS category, c.slug AS category_slug, c.unit,
            (SELECT MIN(price) FROM listings l
              WHERE l.product_id = p.id AND l.region_id = ? AND l.status = 'open') AS ask,
            (SELECT COUNT(*) FROM listings l
              WHERE l.product_id = p.id AND l.region_id = ? AND l.status = 'open') AS ask_count,
            (SELECT MAX(price) FROM bids b
              WHERE b.product_id = p.id AND b.region_id = ? AND b.status = 'open') AS bid,
            (SELECT COUNT(*) FROM bids b
              WHERE b.product_id = p.id AND b.region_id = ? AND b.status = 'open') AS bid_count,
            -- 7일 전 대비 최저가 변동률
            (SELECT ROUND(
                      (h1.low_price - h2.low_price) * 100.0 / NULLIF(h2.low_price, 0), 1)
               FROM price_history h1
               JOIN price_history h2
                 ON h2.product_id = h1.product_id AND h2.region_id = h1.region_id
              WHERE h1.product_id = p.id AND h1.region_id = ?
                AND h1.captured_on = (SELECT MAX(captured_on) FROM price_history)
                AND h2.captured_on = (
                      SELECT MAX(captured_on) FROM price_history
                       WHERE captured_on <= date((SELECT MAX(captured_on) FROM price_history), '-7 days'))
             ) AS change_pct
       FROM products p
       JOIN categories c ON c.id = p.category_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY ${orderBy}`
  ).bind(...binds).all();

  return json({ region, count: results.length, products: results });
}

async function getProduct(env, id, url) {
  const region = url.searchParams.get('region') || 'seoul';
  const regionRow = await env.DB.prepare('SELECT id, name FROM regions WHERE code = ?').bind(region).first();
  if (!regionRow) return bad('알 수 없는 지역입니다');
  const rid = regionRow.id;

  const product = await env.DB.prepare(
    `SELECT p.id, p.name, p.brand, p.spec, p.image_url,
            c.name AS category, c.slug AS category_slug, c.unit,
            s.name AS source_name, s.license AS source_license
       FROM products p
       JOIN categories c ON c.id = p.category_id
       LEFT JOIN sources s ON s.id = p.source_id
      WHERE p.id = ?`
  ).bind(id).first();
  if (!product) return bad('제품을 찾을 수 없습니다', 404);

  const [asks, bids, history, byRegion, styles] = await Promise.all([
    env.DB.prepare(
      `SELECT l.id, l.vendor, l.price, l.unit, l.includes_labor, l.captured_at, s.name AS source
         FROM listings l LEFT JOIN sources s ON s.id = l.source_id
        WHERE l.product_id = ? AND l.region_id = ? AND l.status = 'open'
        ORDER BY l.price ASC LIMIT 12`
    ).bind(id, rid).all(),

    env.DB.prepare(
      `SELECT id, bidder, price, qty, memo, created_at
         FROM bids
        WHERE product_id = ? AND region_id = ? AND status = 'open'
        ORDER BY price DESC LIMIT 12`
    ).bind(id, rid).all(),

    env.DB.prepare(
      `SELECT captured_on, low_price, avg_price, high_price
         FROM price_history
        WHERE product_id = ? AND region_id = ?
        ORDER BY captured_on ASC LIMIT 60`
    ).bind(id, rid).all(),

    env.DB.prepare(
      `SELECT r.code, r.name,
              MIN(l.price) AS ask,
              COUNT(l.id)  AS ask_count
         FROM regions r
         LEFT JOIN listings l
           ON l.region_id = r.id AND l.product_id = ? AND l.status = 'open'
        GROUP BY r.id
        HAVING ask IS NOT NULL
        ORDER BY ask ASC`
    ).bind(id).all(),

    env.DB.prepare(
      `SELECT s.slug, s.name FROM styles s
         JOIN product_styles ps ON ps.style_id = s.id
        WHERE ps.product_id = ?`
    ).bind(id).all(),
  ]);

  return json({
    product,
    region: { code: region, name: regionRow.name },
    asks: asks.results,
    bids: bids.results,
    history: history.results,
    byRegion: byRegion.results,
    styles: styles.results,
  });
}

/* ---------- 쓰기 ---------- */

async function postBid(env, request) {
  let body;
  try { body = await request.json(); } catch { return bad('JSON 형식이 아닙니다'); }

  const productId = Number(body.productId);
  const price = Math.round(Number(body.price));
  const qty = Number(body.qty) || 1;
  const bidder = String(body.bidder || '').trim().slice(0, 20);
  const memo = String(body.memo || '').trim().slice(0, 200);
  const regionCode = String(body.region || '').trim();

  if (!productId || !price || price <= 0) return bad('제품과 희망가를 확인해주세요');
  if (!bidder) return bad('닉네임을 입력해주세요');

  const region = await env.DB.prepare('SELECT id FROM regions WHERE code = ?').bind(regionCode).first();
  if (!region) return bad('지역을 선택해주세요');

  const product = await env.DB.prepare('SELECT id FROM products WHERE id = ?').bind(productId).first();
  if (!product) return bad('제품을 찾을 수 없습니다', 404);

  // 이미 그 가격 이하의 호가가 있으면 즉시 체결로 처리한다.
  const best = await env.DB.prepare(
    `SELECT id, price, vendor FROM listings
      WHERE product_id = ? AND region_id = ? AND status = 'open'
      ORDER BY price ASC LIMIT 1`
  ).bind(productId, region.id).first();

  const matched = best && best.price <= price;

  const bid = await env.DB.prepare(
    `INSERT INTO bids (product_id, region_id, bidder, price, qty, memo, status, matched_listing_id, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+14 days'))
     RETURNING id, status`
  ).bind(
    productId, region.id, bidder, price, qty, memo || null,
    matched ? 'matched' : 'open', matched ? best.id : null
  ).first();

  if (matched) {
    await env.DB.prepare('UPDATE listings SET status = ? WHERE id = ?').bind('matched', best.id).run();
  }

  return json({
    id: bid.id,
    status: bid.status,
    matched: !!matched,
    matchedWith: matched ? { vendor: best.vendor, price: best.price } : null,
  }, 201);
}

async function postVendorListing(env, request) {
  let body;
  try { body = await request.json(); } catch { return bad('JSON 형식이 아닙니다'); }

  const productId = Number(body.productId);
  const price = Math.round(Number(body.price));
  const vendor = String(body.vendor || '').trim().slice(0, 40);
  const regionCode = String(body.region || '').trim();

  if (!productId || !price || price <= 0 || !vendor) return bad('업체명·제품·가격을 확인해주세요');

  const [region, product, source] = await Promise.all([
    env.DB.prepare('SELECT id FROM regions WHERE code = ?').bind(regionCode).first(),
    env.DB.prepare(
      'SELECT p.id, c.unit FROM products p JOIN categories c ON c.id = p.category_id WHERE p.id = ?'
    ).bind(productId).first(),
    env.DB.prepare("SELECT id FROM sources WHERE slug = 'vendor-submit'").first(),
  ]);
  if (!region) return bad('지역을 선택해주세요');
  if (!product) return bad('제품을 찾을 수 없습니다', 404);

  const row = await env.DB.prepare(
    `INSERT INTO listings (product_id, region_id, vendor, price, unit, includes_labor, source_id)
     VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id`
  ).bind(
    productId, region.id, vendor, price, product.unit,
    body.includesLabor === false ? 0 : 1, source?.id || null
  ).first();

  return json({ id: row.id }, 201);
}

/* ---------- 운영 ---------- */

async function getStatus(env) {
  const [runs, sources] = await Promise.all([
    env.DB.prepare(
      `SELECT r.id, r.status, r.inserted, r.started_at, r.finished_at, r.message, s.name AS source
         FROM crawl_runs r LEFT JOIN sources s ON s.id = r.source_id
        ORDER BY r.started_at DESC LIMIT 20`
    ).all(),
    env.DB.prepare(
      'SELECT slug, name, adapter, license, enabled, last_run_at FROM sources ORDER BY id'
    ).all(),
  ]);
  return json({ runs: runs.results, sources: sources.results, today: todayISO() });
}

function isAdmin(env, request) {
  const key = (env.ADMIN_KEY || '').trim();
  if (!key) return false;
  return request.headers.get('X-Admin-Key') === key;
}

/* ---------- Router ---------- */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const { pathname } = url;

    if (!pathname.startsWith('/api/')) return env.ASSETS.fetch(request);

    try {
      if (pathname === '/api/bootstrap' && request.method === 'GET') return getBootstrap(env);
      if (pathname === '/api/products' && request.method === 'GET') return getProducts(env, url);

      const m = pathname.match(/^\/api\/products\/(\d+)$/);
      if (m && request.method === 'GET') return getProduct(env, Number(m[1]), url);

      if (pathname === '/api/bids' && request.method === 'POST') return postBid(env, request);
      if (pathname === '/api/vendor/listings' && request.method === 'POST') return postVendorListing(env, request);
      if (pathname === '/api/status' && request.method === 'GET') return getStatus(env);

      if (pathname === '/api/admin/crawl' && request.method === 'POST') {
        if (!isAdmin(env, request)) return bad('관리자 키가 필요합니다', 401);
        const only = url.searchParams.get('source');
        return json(await runIngestion(env, { only }));
      }

      return bad('없는 경로입니다', 404);
    } catch (err) {
      return json({ error: '서버 오류', detail: String(err.message || err) }, 500);
    }
  },

  /** 매일 새벽 4시(KST) 수집 */
  async scheduled(event, env, ctx) {
    ctx.waitUntil(runIngestion(env).then(
      r => console.log('ingestion', JSON.stringify(r)),
      e => console.error('ingestion failed', e)
    ));
  },
};
