/* ============================================================
   수집 파이프라인
   - 수집원마다 adapter 하나. sources.adapter 값이 ADAPTERS 키와 맞물린다.
   - adapter 는 { vendor, productId, regionCode, price, unit, sourceUrl } 배열을
     돌려주기만 하면 되고, 저장·시세계산·체결은 아래 공통 로직이 처리한다.
   ============================================================ */

/* ---------- 공통 유틸 ---------- */

const UA = '집값다오-bot/1.0 (+https://interior-market.workers.dev/bot)';

/** 같은 날·같은 제품·같은 지역이면 항상 같은 값. 시세가 날마다 튀지 않게 한다. */
function seededUnit(...parts) {
  const key = parts.join('|');
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 100000) / 100000;
}

export function todayISO(now = new Date()) {
  return now.toISOString().slice(0, 10);
}

/**
 * robots.txt 를 확인한다. HTML 을 긁는 adapter 는 반드시 이걸 통과시킬 것.
 * 공식 API·제휴 피드는 대상이 아니다.
 */
export async function isCrawlAllowed(url, userAgent = UA) {
  try {
    const u = new URL(url);
    const res = await fetch(`${u.origin}/robots.txt`, { headers: { 'User-Agent': userAgent } });
    if (!res.ok) return true; // robots.txt 가 없으면 제한 없음으로 본다
    const txt = await res.text();

    let applies = false;
    const disallowed = [];
    for (const rawLine of txt.split('\n')) {
      const line = rawLine.split('#')[0].trim();
      if (!line) continue;
      const [rawKey, ...rest] = line.split(':');
      const key = rawKey.trim().toLowerCase();
      const value = rest.join(':').trim();
      if (key === 'user-agent') {
        applies = value === '*' || userAgent.toLowerCase().includes(value.toLowerCase());
      } else if (key === 'disallow' && applies && value) {
        disallowed.push(value);
      }
    }
    return !disallowed.some(rule => u.pathname.startsWith(rule));
  } catch {
    return false; // 확인 못 하면 긁지 않는다
  }
}

/* ---------- 시세 기준표 (sample adapter 용) ---------- */
/* 2026년 기준 국내 통용 시공가 범위. 실제 견적이 아닌 참고용 합성 데이터. */
const PRICE_BOOK = {
  '합지벽지 도배 시공':        [24000, 36000],
  '실크벽지 도배 시공':        [38000, 56000],
  '천연 펄프 벽지 시공':       [52000, 78000],
  '석재 질감 벽장재':          [120000, 210000],
  '모노륨 장판 1.8mm':         [29000, 44000],
  '모노륨 장판 2.2mm':         [38000, 56000],
  '강화마루 시공':             [62000, 92000],
  '강마루 시공':               [84000, 125000],
  'SPC 하이브리드 바닥재':     [88000, 132000],
  '코르크 바닥재':             [95000, 145000],
  '주방 상하부장 3.6m':        [1900000, 3400000],
  '주방 상하부장 3.6m 하이글로시': [2400000, 4300000],
  '아일랜드 식탁 제작':        [780000, 1650000],
  '욕실 전체 리모델링':        [2400000, 5400000],
  '포세린 타일 600각 시공':    [92000, 148000],
  '헥사곤 타일 시공':          [86000, 138000],
  '무타공 레일조명':           [180000, 420000],
  '이중창 교체 (PVC)':         [210000, 380000],
  '친환경 수성페인트 도장':    [34000, 58000],
};

const SAMPLE_VENDORS = [
  '한결시공', '바른손인테리어', '리하우스공방', '온기시공단', '더집스튜디오',
  '초록마루', '정직한도배', '스퀘어리모델링', '하루인테리어', '마루장인',
];

/* ---------- Adapters ---------- */

/**
 * 데모/부트스트랩용 합성 시세.
 * 실제 수집원이 붙기 전까지 화면을 채우고, 파이프라인 전체를 검증하는 역할.
 */
async function sample({ db, date }) {
  const [{ results: products }, { results: regions }] = await Promise.all([
    db.prepare('SELECT p.id, p.name, c.unit FROM products p JOIN categories c ON c.id = p.category_id').all(),
    db.prepare('SELECT id, code, cost_index FROM regions').all(),
  ]);

  const rows = [];
  for (const p of products) {
    const band = PRICE_BOOK[p.name];
    if (!band) continue;
    const [lo, hi] = band;

    for (const r of regions) {
      // 지역당 3~5개 업체 호가를 만든다.
      const offers = 3 + Math.floor(seededUnit(date, p.id, r.id, 'n') * 3);
      for (let i = 0; i < offers; i++) {
        const t = seededUnit(date, p.id, r.id, i);
        const raw = lo + (hi - lo) * t;
        const price = Math.round((raw * r.cost_index) / 1000) * 1000;
        rows.push({
          productId: p.id,
          regionCode: r.code,
          vendor: SAMPLE_VENDORS[Math.floor(seededUnit(p.id, r.id, i, 'v') * SAMPLE_VENDORS.length)],
          price,
          unit: p.unit,
          sourceUrl: null,
        });
      }
    }
  }
  return rows;
}

/**
 * 조달청 시설공통자재 가격정보 (공공데이터포털 오픈API).
 * G2B_SERVICE_KEY 시크릿이 있어야 동작한다.
 */
async function g2bPrice({ env, source }) {
  const key = (env.G2B_SERVICE_KEY || '').trim();
  if (!key) throw new Error('G2B_SERVICE_KEY 시크릿이 없습니다');

  const config = JSON.parse(source.config || '{}');
  const endpoint = config.endpoint
    || 'https://apis.data.go.kr/1230000/PrdctPriceInfoService/getPrdctPriceInfoList';

  const url = new URL(endpoint);
  url.searchParams.set('serviceKey', key);
  url.searchParams.set('numOfRows', String(config.numOfRows || 100));
  url.searchParams.set('pageNo', '1');
  url.searchParams.set('type', 'json');

  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`조달청 API ${res.status}`);
  const data = await res.json();

  const items = data?.response?.body?.items || [];
  // 조달청 품명을 우리 제품에 어떻게 붙일지는 config.map 으로 운영하며 채운다.
  const map = config.map || {};
  return items.flatMap(item => {
    const productId = map[item.prdctClsfcNoNm];
    if (!productId) return [];
    return [{
      productId,
      regionCode: config.defaultRegion || 'seoul',
      vendor: item.dlvrCndtnNm || '조달청 등록가',
      price: Number(item.prdctPrce) || 0,
      unit: item.untNm || '식',
      sourceUrl: endpoint,
    }];
  }).filter(r => r.price > 0);
}

/** 제휴사에서 받은 JSON 피드. 계약된 스키마를 config.map 으로 맞춘다. */
async function partnerFeed({ source }) {
  const config = JSON.parse(source.config || '{}');
  if (!config.feedUrl) throw new Error('config.feedUrl 이 없습니다');

  const res = await fetch(config.feedUrl, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`피드 ${res.status}`);
  const data = await res.json();
  const items = Array.isArray(data) ? data : (data.items || []);

  return items.flatMap(it => {
    const productId = (config.map || {})[it.sku ?? it.name];
    if (!productId || !it.price) return [];
    return [{
      productId,
      regionCode: it.region || config.defaultRegion || 'seoul',
      vendor: it.vendor || source.name,
      price: Number(it.price),
      unit: it.unit || '식',
      sourceUrl: it.url || config.feedUrl,
    }];
  });
}

/** 업체가 /api/vendor/listings 로 직접 올린다. 배치가 할 일은 없다. */
async function vendorSubmit() {
  return [];
}

export const ADAPTERS = { sample, g2bPrice, partnerFeed, vendorSubmit };

/* ---------- 실행기 ---------- */

/** 오늘자 listings 를 갈아끼운다. 같은 소스의 어제 데이터는 지운다. */
async function replaceListings(db, sourceId, rows, regionMap) {
  if (!rows.length) return { inserted: 0 };

  await db.prepare('DELETE FROM listings WHERE source_id = ? AND status = ?')
    .bind(sourceId, 'open').run();

  const stmt = db.prepare(
    `INSERT INTO listings (product_id, region_id, vendor, price, unit, source_id, source_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const batch = rows
    .filter(r => regionMap[r.regionCode])
    .map(r => stmt.bind(
      r.productId, regionMap[r.regionCode], r.vendor, r.price, r.unit, sourceId, r.sourceUrl || null
    ));

  // D1 배치는 한 번에 보낼 수 있는 양이 제한적이라 잘라서 보낸다.
  const CHUNK = 200;
  for (let i = 0; i < batch.length; i += CHUNK) {
    await db.batch(batch.slice(i, i + CHUNK));
  }
  return { inserted: batch.length };
}

/**
 * 시세 이력이 비어 있으면 과거 구간을 채운다.
 * 차트는 2일치부터 의미가 생기는데 첫 수집일엔 1점뿐이라, sample 시세 기준으로
 * 지난 N일을 같은 규칙으로 역산해 넣는다. 실수집 데이터가 쌓이면 그날부터는
 * 실제 값이 우선한다(ON CONFLICT 로 덮어쓰지 않고 건너뜀).
 */
async function backfillHistory(db, endDate, days = 30) {
  const existing = await db.prepare(
    'SELECT COUNT(DISTINCT captured_on) AS n FROM price_history'
  ).first();
  if ((existing?.n || 0) > 1) return 0;

  const [{ results: products }, { results: regions }] = await Promise.all([
    db.prepare('SELECT p.id, p.name FROM products p').all(),
    db.prepare('SELECT id, cost_index FROM regions').all(),
  ]);

  const stmt = db.prepare(
    `INSERT INTO price_history (product_id, region_id, captured_on, low_price, avg_price, high_price, sample_size)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT (product_id, region_id, captured_on) DO NOTHING`
  );

  const batch = [];
  const end = new Date(endDate + 'T00:00:00Z');
  for (let d = days; d >= 1; d--) {
    const day = new Date(end.getTime() - d * 86400000).toISOString().slice(0, 10);
    for (const p of products) {
      const band = PRICE_BOOK[p.name];
      if (!band) continue;
      const [lo, hi] = band;
      for (const r of regions) {
        const samples = [0, 1, 2, 3].map(i => {
          const t = seededUnit(day, p.id, r.id, i);
          return Math.round((lo + (hi - lo) * t) * r.cost_index / 1000) * 1000;
        });
        batch.push(stmt.bind(
          p.id, r.id, day,
          Math.min(...samples),
          Math.round(samples.reduce((a, b) => a + b, 0) / samples.length),
          Math.max(...samples),
          samples.length
        ));
      }
    }
  }

  const CHUNK = 200;
  for (let i = 0; i < batch.length; i += CHUNK) {
    await db.batch(batch.slice(i, i + CHUNK));
  }
  return batch.length;
}

/** 열려 있는 호가로 오늘의 저가/평균/고가를 집계해 스냅샷을 남긴다. */
async function snapshotPrices(db, date) {
  await db.prepare(
    `INSERT INTO price_history (product_id, region_id, captured_on, low_price, avg_price, high_price, sample_size)
     SELECT product_id, region_id, ?,
            MIN(price), CAST(AVG(price) AS INTEGER), MAX(price), COUNT(*)
       FROM listings
      WHERE status = 'open'
      GROUP BY product_id, region_id
     ON CONFLICT (product_id, region_id, captured_on) DO UPDATE SET
       low_price   = excluded.low_price,
       avg_price   = excluded.avg_price,
       high_price  = excluded.high_price,
       sample_size = excluded.sample_size`
  ).bind(date).run();
}

/**
 * 입찰가가 최저 호가 이상이면 체결시킨다.
 * 크림의 "즉시 판매가 ≥ 즉시 구매가" 매칭과 같은 규칙.
 */
async function matchBids(db) {
  // 입찰마다 "그 조건에서 가장 싼 호가" 하나를 상관 서브쿼리로 명시적으로 고른다.
  // (GROUP BY + bare column 의 SQLite 전용 동작에 기대지 않는다)
  const { results } = await db.prepare(
    `SELECT b.id AS bid_id,
            (SELECT l.id FROM listings l
              WHERE l.product_id = b.product_id
                AND l.region_id  = b.region_id
                AND l.status     = 'open'
                AND l.price     <= b.price
              ORDER BY l.price ASC, l.id ASC
              LIMIT 1) AS listing_id
       FROM bids b
      WHERE b.status = 'open'`
  ).all();

  const matches = results.filter(m => m.listing_id != null);
  if (!matches.length) return 0;

  // 한 호가가 여러 입찰에 동시에 잡히지 않도록 먼저 온 입찰에만 배정한다.
  const taken = new Set();
  const pairs = [];
  for (const m of matches) {
    if (taken.has(m.listing_id)) continue;
    taken.add(m.listing_id);
    pairs.push(m);
  }

  await db.batch(pairs.flatMap(m => ([
    db.prepare('UPDATE bids SET status = ?, matched_listing_id = ? WHERE id = ?')
      .bind('matched', m.listing_id, m.bid_id),
    db.prepare('UPDATE listings SET status = ? WHERE id = ?')
      .bind('matched', m.listing_id),
  ])));
  return pairs.length;
}

/** 하루 한 번 도는 본체. 수동 실행(/api/admin/crawl)도 같은 경로를 탄다. */
export async function runIngestion(env, { only = null, now = new Date() } = {}) {
  const db = env.DB;
  const date = todayISO(now);

  const { results: regions } = await db.prepare('SELECT id, code FROM regions').all();
  const regionMap = Object.fromEntries(regions.map(r => [r.code, r.id]));

  let query = 'SELECT * FROM sources WHERE enabled = 1';
  const binds = [];
  if (only) { query += ' AND slug = ?'; binds.push(only); }
  const { results: sources } = await db.prepare(query).bind(...binds).all();

  const report = [];
  for (const source of sources) {
    const run = await db.prepare(
      'INSERT INTO crawl_runs (source_id, status) VALUES (?, ?) RETURNING id'
    ).bind(source.id, 'running').first();

    try {
      const adapter = ADAPTERS[source.adapter];
      if (!adapter) throw new Error(`알 수 없는 adapter: ${source.adapter}`);

      const rows = await adapter({ db, env, source, date });
      const { inserted } = await replaceListings(db, source.id, rows, regionMap);

      await db.prepare(
        `UPDATE crawl_runs SET status = ?, inserted = ?, finished_at = datetime('now') WHERE id = ?`
      ).bind('ok', inserted, run.id).run();
      await db.prepare(`UPDATE sources SET last_run_at = datetime('now') WHERE id = ?`)
        .bind(source.id).run();

      report.push({ source: source.slug, status: 'ok', inserted });
    } catch (err) {
      await db.prepare(
        `UPDATE crawl_runs SET status = ?, message = ?, finished_at = datetime('now') WHERE id = ?`
      ).bind('error', String(err.message || err), run.id).run();
      report.push({ source: source.slug, status: 'error', message: String(err.message || err) });
    }
  }

  await snapshotPrices(db, date);
  const backfilled = await backfillHistory(db, date);
  const matched = await matchBids(db);

  return { date, sources: report, matched, backfilled };
}
