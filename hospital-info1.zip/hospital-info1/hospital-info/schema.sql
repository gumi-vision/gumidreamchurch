-- ============================================================
--  어디로가지 · 지역별 병원 정보 (공식 평가 기반)
--
--  설계 원칙
--   1. 우리가 병원·의사에 순위를 매기지 않는다. (의료법 제56조, 시행령 제23조)
--      공표된 공식 평가·지정만 그대로 전달하고 출처를 항상 남긴다.
--   2. 의사는 랭킹 없이 공표된 사실(전문분야·자격)만 인용하고 원문으로 링크한다.
--   3. 후기는 비의료적 경험만 받는다. 치료효과 평가는 수집하지 않는다.
--   4. 대기시간은 추정하지 않는다. 제보 중앙값 + 표본 수를 함께 표시한다.
-- ============================================================

DROP TABLE IF EXISTS wait_reports;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS evaluations;
DROP TABLE IF EXISTS designations;
DROP TABLE IF EXISTS hospital_specialties;
DROP TABLE IF EXISTS hospitals;
DROP TABLE IF EXISTS conditions;
DROP TABLE IF EXISTS specialties;
DROP TABLE IF EXISTS districts;
DROP TABLE IF EXISTS regions;
DROP TABLE IF EXISTS crawl_runs;
DROP TABLE IF EXISTS sources;

-- 지역 --------------------------------------------------------
CREATE TABLE regions (
  id      INTEGER PRIMARY KEY,
  sido_cd TEXT NOT NULL UNIQUE,      -- 심평원 시도코드
  slug    TEXT NOT NULL UNIQUE,
  name    TEXT NOT NULL
);

CREATE TABLE districts (
  id        INTEGER PRIMARY KEY,
  region_id INTEGER NOT NULL REFERENCES regions(id),
  sggu_cd   TEXT NOT NULL UNIQUE,
  name      TEXT NOT NULL
);
CREATE INDEX idx_districts_region ON districts(region_id);

-- 진료과 / 질환 -----------------------------------------------
CREATE TABLE specialties (
  id         INTEGER PRIMARY KEY,
  slug       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  icon       TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- 이용자가 실제로 검색하는 말("목디스크")을 진료과와 공식 평가에 연결한다.
CREATE TABLE conditions (
  id           INTEGER PRIMARY KEY,
  slug         TEXT NOT NULL UNIQUE,
  name         TEXT NOT NULL,
  specialty_id INTEGER NOT NULL REFERENCES specialties(id),
  aka          TEXT,                 -- 동의어(검색용), 쉼표 구분
  summary      TEXT,
  -- 이 질환을 판단할 때 어떤 공식 근거를 쓰는지 이용자에게 그대로 보여준다.
  basis_note   TEXT,
  sort_order   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_conditions_specialty ON conditions(specialty_id);

-- 병원 --------------------------------------------------------
CREATE TABLE hospitals (
  id          INTEGER PRIMARY KEY,
  ykiho       TEXT NOT NULL UNIQUE,  -- 심평원 암호화 요양기호 (타 API 조인키)
  name        TEXT NOT NULL,
  cl_cd       TEXT,
  cl_name     TEXT,                  -- 상급종합 / 종합병원 / 병원
  region_id   INTEGER REFERENCES regions(id),
  district_id INTEGER REFERENCES districts(id),
  emdong      TEXT,
  addr        TEXT,
  post_no     TEXT,
  tel         TEXT,
  url         TEXT,
  lat         REAL,
  lng         REAL,
  estb_dd     TEXT,
  dr_total    INTEGER NOT NULL DEFAULT 0,
  sdr_count   INTEGER NOT NULL DEFAULT 0,   -- 의과 전문의 수
  resident_count INTEGER NOT NULL DEFAULT 0,
  intern_count   INTEGER NOT NULL DEFAULT 0,
  source_id   INTEGER REFERENCES sources(id),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_hosp_region ON hospitals(region_id, cl_cd);
CREATE INDEX idx_hosp_name   ON hospitals(name);

-- 병원이 실제로 운영하는 진료과 (상세정보서비스에서 채움)
CREATE TABLE hospital_specialties (
  hospital_id  INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  specialty_id INTEGER NOT NULL REFERENCES specialties(id),
  sdr_count    INTEGER NOT NULL DEFAULT 0,   -- 해당 과 전문의 수
  PRIMARY KEY (hospital_id, specialty_id)
);

-- 공식 지정 (복지부 전문병원, 상급종합 등) --------------------
CREATE TABLE designations (
  id          INTEGER PRIMARY KEY,
  hospital_id INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,         -- 전문병원 | 상급종합 | 소아야간진료 | 장기이식 ...
  field       TEXT,                  -- 척추 / 관절 / 소아청소년과 ...
  granted_on  TEXT,
  source_id   INTEGER REFERENCES sources(id),
  source_url  TEXT,
  UNIQUE (hospital_id, kind, field)
);
CREATE INDEX idx_desig_field ON designations(kind, field);

-- 적정성평가 등급 (심평원 공표) -------------------------------
CREATE TABLE evaluations (
  id           INTEGER PRIMARY KEY,
  hospital_id  INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  condition_id INTEGER REFERENCES conditions(id),
  subject      TEXT NOT NULL,        -- 평가 항목명 (예: 요추 추간판탈출증 수술)
  grade        INTEGER,              -- 1~5 등급
  year         TEXT,
  source_id    INTEGER REFERENCES sources(id),
  source_url   TEXT,
  UNIQUE (hospital_id, subject, year)
);
CREATE INDEX idx_eval_lookup ON evaluations(condition_id, grade);

-- 의료진: 순위 없이 공표된 사실만 --------------------------------
CREATE TABLE doctors (
  id           INTEGER PRIMARY KEY,
  hospital_id  INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  title        TEXT,                 -- 교수 / 전문의
  specialty_id INTEGER REFERENCES specialties(id),
  focus_areas  TEXT,                 -- 병원이 공표한 전문진료분야 원문
  profile_url  TEXT NOT NULL,        -- 반드시 원문 링크를 남긴다
  source_id    INTEGER REFERENCES sources(id),
  UNIQUE (hospital_id, name, title)
);
CREATE INDEX idx_doctors_hosp ON doctors(hospital_id, specialty_id);

-- 후기: 비의료적 경험 5개 항목만 (치료효과 수집 안 함) -----------
CREATE TABLE reviews (
  id             INTEGER PRIMARY KEY,
  hospital_id    INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  specialty_id   INTEGER REFERENCES specialties(id),
  nickname       TEXT NOT NULL,
  booking_score  INTEGER NOT NULL,   -- 예약 편의성 1~5
  wait_score     INTEGER NOT NULL,   -- 대기 시간
  explain_score  INTEGER NOT NULL,   -- 설명 충분도
  facility_score INTEGER NOT NULL,   -- 시설·주차
  staff_score    INTEGER NOT NULL,   -- 직원 응대
  comment        TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_reviews_hosp ON reviews(hospital_id);

-- 대기시간 제보 (추정 금지, 제보만) ------------------------------
CREATE TABLE wait_reports (
  id           INTEGER PRIMARY KEY,
  hospital_id  INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  specialty_id INTEGER REFERENCES specialties(id),
  wait_days    INTEGER,              -- 예약까지 걸린 일수
  wait_minutes INTEGER,              -- 당일 현장 대기(분)
  visited_on   TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_wait_hosp ON wait_reports(hospital_id, specialty_id);

-- 수집원 ------------------------------------------------------
CREATE TABLE sources (
  id          INTEGER PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  adapter     TEXT NOT NULL,
  base_url    TEXT,
  license     TEXT NOT NULL,         -- 이용 근거를 반드시 남긴다
  enabled     INTEGER NOT NULL DEFAULT 0,
  config      TEXT,
  last_run_at TEXT
);

CREATE TABLE crawl_runs (
  id          INTEGER PRIMARY KEY,
  source_id   INTEGER REFERENCES sources(id),
  started_at  TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  status      TEXT NOT NULL DEFAULT 'running',
  inserted    INTEGER NOT NULL DEFAULT 0,
  updated     INTEGER NOT NULL DEFAULT 0,
  message     TEXT
);
CREATE INDEX idx_runs_source ON crawl_runs(source_id, started_at);
