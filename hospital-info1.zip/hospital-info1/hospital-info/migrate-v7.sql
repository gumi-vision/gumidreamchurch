-- ============================================================
--  v7 — 시설(병상)·의료장비·간호등급·전문병원 지정분야
-- ============================================================

DROP TABLE IF EXISTS hospital_facility;
CREATE TABLE hospital_facility (
  hospital_id   INTEGER PRIMARY KEY REFERENCES hospitals(id) ON DELETE CASCADE,
  org_type      TEXT,     -- 설립구분 (의료법인 등)
  beds_total    INTEGER,  -- permSbdCnt   허가병상
  beds_standard INTEGER,  -- stdSickbdCnt 일반(기준)병상
  beds_upper    INTEGER,  -- hghrSickbdCnt 상급병상(1~2인실 등)
  icu_adult     INTEGER,  -- aduChldSprmCnt 성인·소아 중환자실
  icu_child     INTEGER,  -- chldSprmCnt
  icu_newborn   INTEGER,  -- nbySprmCnt 신생아중환자실
  beds_isolation INTEGER, -- isnrSbdCnt 격리병상
  beds_negative INTEGER,  -- anvirTrrmSbdCnt 음압격리병상
  beds_emergency INTEGER, -- emymCnt 응급실
  op_rooms      INTEGER,  -- soprmCnt 수술실
  delivery_rooms INTEGER, -- partumCnt 분만실
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

DROP TABLE IF EXISTS hospital_equipment;
CREATE TABLE hospital_equipment (
  hospital_id INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,
  name        TEXT NOT NULL,
  qty         INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (hospital_id, code)
);

ALTER TABLE hospitals ADD COLUMN nursing_grade TEXT;   -- 건강보험 간호등급

-- 전문병원 지정분야를 질환에 연결한다.
-- 이 매핑이 있어야 "척추 전문병원"만 허리디스크 상위로 올릴 수 있다.
DROP TABLE IF EXISTS designation_conditions;
CREATE TABLE designation_conditions (
  field        TEXT NOT NULL,
  condition_id INTEGER NOT NULL REFERENCES conditions(id) ON DELETE CASCADE,
  PRIMARY KEY (field, condition_id)
);

-- D1 은 compound SELECT 항 수 제한이 낮아 UNION 체인을 쓸 수 없다. 개별 INSERT 로 넣는다.
INSERT INTO designation_conditions SELECT '척추', id FROM conditions WHERE slug='neck-disc';
INSERT INTO designation_conditions SELECT '척추', id FROM conditions WHERE slug='back-disc';
INSERT INTO designation_conditions SELECT '척추', id FROM conditions WHERE slug='spinal-stenosis';
INSERT INTO designation_conditions SELECT '관절', id FROM conditions WHERE slug='knee-arthritis';
INSERT INTO designation_conditions SELECT '관절', id FROM conditions WHERE slug='shoulder';
INSERT INTO designation_conditions SELECT '심장', id FROM conditions WHERE slug='heart-attack';
INSERT INTO designation_conditions SELECT '뇌혈관', id FROM conditions WHERE slug='stroke';
INSERT INTO designation_conditions SELECT '소아청소년과', id FROM conditions WHERE slug='pediatric-night';
INSERT INTO designation_conditions SELECT '안과', id FROM conditions WHERE slug='cataract';
INSERT INTO designation_conditions SELECT '안과', id FROM conditions WHERE slug='glaucoma';
INSERT INTO designation_conditions SELECT '안과', id FROM conditions WHERE slug='retina';
INSERT INTO designation_conditions SELECT '산부인과', id FROM conditions WHERE slug='childbirth';
INSERT INTO designation_conditions SELECT '유방', id FROM conditions WHERE slug='breast-cancer';
INSERT INTO designation_conditions SELECT '대장항문', id FROM conditions WHERE slug='colon-cancer';

-- 실용정보 어댑터가 시설·장비·간호등급·전문병원분야까지 받도록 확장됐으므로
-- 이미 받아둔 병원도 다시 돌게 한다.
DELETE FROM hospital_details;
UPDATE sources SET enabled = 1, config = '{"limit":25}' WHERE slug = 'hira-facility';
