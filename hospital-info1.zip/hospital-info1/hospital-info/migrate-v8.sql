-- ============================================================
--  v8 — AI 모델 폴백 상태 저장
--  마지막으로 응답에 성공한 모델을 기억해, 죽은 모델을 매 요청마다
--  다시 시도하지 않도록 한다.
-- ============================================================
CREATE TABLE IF NOT EXISTS ai_state (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
