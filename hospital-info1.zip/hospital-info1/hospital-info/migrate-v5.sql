-- ============================================================
--  v5 — 홈페이지 링크 상태 검사
--
--  심평원이 주는 hospUrl 중 상당수가 오래되어 접속되지 않는다.
--  (예: 세브란스 yuhs.or.kr, 강남세브란스 gs.iseverance.com)
--  죽은 링크를 그대로 "공식 홈페이지"라고 내보내면 안 되므로
--  주기적으로 확인해 상태를 남기고, 죽었으면 검색으로 대체한다.
-- ============================================================

ALTER TABLE hospitals ADD COLUMN url_status TEXT;      -- ok | dead | NULL(미확인)
ALTER TABLE hospitals ADD COLUMN url_final TEXT;       -- 리다이렉트 최종 주소
ALTER TABLE hospitals ADD COLUMN url_checked_at TEXT;

CREATE INDEX idx_hosp_urlcheck ON hospitals(url_status, url_checked_at);

INSERT INTO sources (slug, name, adapter, base_url, license, enabled, config) VALUES
  ('link-check', '병원 홈페이지 링크 점검', 'linkCheck', NULL,
   '자체 점검 · 각 병원 공식 홈페이지 접속 가능 여부만 확인(내용 수집 없음)', 1,
   '{"limit":60}')
ON CONFLICT(slug) DO UPDATE SET enabled = 1;
