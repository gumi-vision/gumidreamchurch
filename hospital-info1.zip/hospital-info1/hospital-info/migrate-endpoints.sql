-- 확인된 실제 요청주소로 수집원을 갱신한다.
-- 오퍼레이션명에도 버전 접미사가 붙는 점이 핵심(getSpcHospList1, getDgsbjtInfo2.8).

UPDATE sources
   SET base_url = 'https://apis.data.go.kr/B551182/spclMdlrtHospInfoService1',
       enabled  = 1,
       config   = '{"numOfRows":500}'
 WHERE slug = 'hira-spcl';

UPDATE sources
   SET base_url = 'https://apis.data.go.kr/B551182/MadmDtlInfoService2.8',
       enabled  = 1,
       config   = '{"endpoint":"https://apis.data.go.kr/B551182/MadmDtlInfoService2.8/getDgsbjtInfo2.8","limit":400}'
 WHERE slug = 'hira-detail';

-- 평가정보는 base_url 은 확인됐으나 오퍼레이션명이 아직 미확인이라 비활성 유지.
UPDATE sources
   SET base_url = 'https://apis.data.go.kr/B551182/hospAsmInfoService1',
       config   = '{"note":"오퍼레이션명 확인 후 config.endpoint 에 전체 URL 을 넣고 enabled=1"}'
 WHERE slug = 'hira-asm';
