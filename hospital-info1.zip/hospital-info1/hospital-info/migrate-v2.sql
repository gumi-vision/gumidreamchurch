-- ============================================================
--  v2 — 실용 정보(진료시간·주차·응급실·교통) + 증상 세분화
-- ============================================================

-- 병원 실용 정보 (getDtlInfo2.8) --------------------------------
DROP TABLE IF EXISTS hospital_details;
CREATE TABLE hospital_details (
  hospital_id  INTEGER PRIMARY KEY REFERENCES hospitals(id) ON DELETE CASCADE,
  trmt_weekday TEXT,      -- 평일 진료시간 "08:30 ~ 17:00"
  trmt_sat     TEXT,
  rcv_week     TEXT,      -- 접수시간
  rcv_sat      TEXT,
  lunch_week   TEXT,
  no_trmt_sun  TEXT,      -- 일요일 휴진 여부(원문 그대로)
  no_trmt_holi TEXT,
  emy_day      INTEGER NOT NULL DEFAULT 0,   -- 주간 응급실
  emy_night    INTEGER NOT NULL DEFAULT 0,   -- 야간 응급실
  emy_tel      TEXT,
  park_qty     INTEGER,   -- 주차 가능 대수
  park_paid    INTEGER,   -- 유료 여부
  park_note    TEXT,
  place_name   TEXT,      -- 찾아오는 길 기준점
  place_dir    TEXT,
  place_dist   TEXT,
  updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 교통편 (getTrnsprtInfo2.8) ------------------------------------
DROP TABLE IF EXISTS hospital_transit;
CREATE TABLE hospital_transit (
  id          INTEGER PRIMARY KEY,
  hospital_id INTEGER NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  kind        TEXT,       -- 지하철 / 버스
  line_no     TEXT,
  arrive      TEXT,
  direction   TEXT,
  distance    TEXT,
  UNIQUE (hospital_id, kind, line_no, arrive)
);
CREATE INDEX idx_transit_hosp ON hospital_transit(hospital_id);

-- 진료과 보강 ---------------------------------------------------
INSERT INTO specialties (slug, name, icon, sort_order) VALUES
  ('nephrology', '신장내과', '🫘', 21)
ON CONFLICT(slug) DO NOTHING;

-- 증상 세분화 ---------------------------------------------------
-- 적정성평가 항목이 실제로 존재하는 것만 추가한다.
-- 근거 없는 항목을 늘리면 "찾아봐도 아무 근거가 없는" 화면만 늘어난다.
INSERT INTO conditions (slug, name, specialty_id, aka, summary, basis_note, sort_order) VALUES
  ('pneumonia', '폐렴',
   (SELECT id FROM specialties WHERE slug='pulmo'),
   '폐렴,기침,고열,가래',
   '폐에 생긴 염증. 고령자나 만성질환자에게는 입원이 필요할 수 있습니다.',
   '폐렴 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.', 16),

  ('copd', '만성폐쇄성폐질환',
   (SELECT id FROM specialties WHERE slug='pulmo'),
   'COPD,만성폐쇄성폐질환,폐기종,만성기관지염,숨참',
   '기도가 좁아져 숨쉬기 어려워지는 만성 질환. 흡연이 주요 원인입니다.',
   '만성폐쇄성폐질환 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.', 17),

  ('asthma', '천식',
   (SELECT id FROM specialties WHERE slug='pulmo'),
   '천식,쌕쌕거림,호흡곤란,알레르기',
   '기도의 만성 염증으로 발작적 호흡곤란이 나타납니다.',
   '천식 적정성평가(심평원)는 양호기관만 공개되는 방식이라, 등급이 있는 곳은 양호 판정을 받은 기관입니다.', 18),

  ('diabetes', '당뇨병',
   (SELECT id FROM specialties WHERE slug='internal'),
   '당뇨,당뇨병,혈당,인슐린',
   '혈당 조절이 안 되는 만성 질환. 꾸준한 관리가 핵심입니다.',
   '고혈압·당뇨병 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 만성질환은 가까운 곳에서 꾸준히 보는 것이 더 중요할 수 있습니다.', 19),

  ('hypertension', '고혈압',
   (SELECT id FROM specialties WHERE slug='internal'),
   '고혈압,혈압',
   '혈압이 지속적으로 높은 상태. 합병증 예방을 위한 관리가 중요합니다.',
   '고혈압·당뇨병 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 만성질환은 가까운 곳에서 꾸준히 보는 것이 더 중요할 수 있습니다.', 20),

  ('dialysis', '혈액투석 · 만성콩팥병',
   (SELECT id FROM specialties WHERE slug='nephrology'),
   '혈액투석,투석,만성콩팥병,신부전',
   '콩팥 기능이 떨어져 투석이 필요한 상태. 주 2~3회 정기 방문이 필요합니다.',
   '혈액투석 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 정기적으로 다녀야 하므로 집에서 가까운지가 특히 중요합니다.', 21),

  ('mental-inpatient', '정신건강 입원치료',
   (SELECT id FROM specialties WHERE slug='psychiatry'),
   '정신건강,우울증,입원,정신과',
   '입원 치료가 필요한 정신건강 문제.',
   '정신건강 입원영역 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.', 22),

  ('surgery-infection', '수술 예정 (감염 예방)',
   (SELECT id FROM specialties WHERE slug='surgery'),
   '수술,감염예방,항생제,수술부위감염',
   '수술을 앞두고 있다면 감염 예방 관리 수준을 함께 보세요.',
   '수술부위 감염예방 항생제 적정성평가와 마취 적정성평가 등급(심평원 공표)을 근거로 합니다.', 23)
ON CONFLICT(slug) DO NOTHING;

-- 새 질환을 평가항목에 연결 (기존 매핑에 추가) --------------------
UPDATE sources
   SET config = json_set(config, '$.conditionMap',
         json_object(
           '01', 'stroke',
           '03', 'dialysis',
           '05', 'surgery-infection',
           '06', 'heart-attack',
           '12', 'colon-cancer',
           '13', 'stomach-cancer',
           '14', 'breast-cancer',
           '15', 'lung-cancer',
           '16', 'asthma',
           '17', 'copd',
           '18', 'pneumonia',
           '20', 'childbirth',
           '22', 'mental-inpatient',
           '24', 'diabetes'
         ),
         '$.cursorPage', 1)
 WHERE slug = 'hira-asm';

-- 실용정보 수집원 등록 -------------------------------------------
INSERT INTO sources (slug, name, adapter, base_url, license, enabled, config) VALUES
  ('hira-facility', '심평원 의료기관 실용정보(진료시간·교통)', 'hiraFacility',
   'https://apis.data.go.kr/B551182/MadmDtlInfoService2.8',
   '공공데이터포털 오픈API · 심평원 제공 (data.go.kr/data/15001699)', 1,
   '{"limit":40}')
ON CONFLICT(slug) DO UPDATE SET enabled = 1;
