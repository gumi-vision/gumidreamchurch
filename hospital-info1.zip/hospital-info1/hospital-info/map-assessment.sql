-- ============================================================
--  활용가이드(2025-02-19)의 asmGrd 코드표를 반영한다.
--  코드명은 문서 원문 그대로 쓰고, 추측으로 만들지 않는다.
-- ============================================================

-- 코드명이 바뀌므로 기존 "평가항목 NN" 행은 비우고 다시 받는다.
DELETE FROM evaluations;

UPDATE sources
   SET enabled = 1,
       config = json_object(
         'endpoint',   'https://apis.data.go.kr/B551182/hospAsmInfoService1/getHospAsmInfo1',
         'numOfRows',  500,
         'pagesPerRun', 25,
         'cursorPage', 1,
         'itemNames', json_object(
           '01', '급성기뇌졸중',
           '03', '혈액투석',
           '04', '의료급여정신과',
           '05', '수술부위 감염예방 항생제',
           '06', '관상동맥우회술',
           '07', '급성상기도감염 항생제 처방률',
           '08', '주사제 처방률',
           '09', '약품목수',
           '10', '요양병원',
           '12', '대장암',
           '13', '위암',
           '14', '유방암',
           '15', '폐암',
           '16', '천식',
           '17', '만성폐쇄성폐질환',
           '18', '폐렴',
           '19', '중환자실',
           '20', '신생아중환자실',
           '21', '마취',
           '22', '정신건강 입원영역',
           '23', '급성하기도감염 항생제 처방률',
           '24', '고혈압·당뇨병'
         ),
         -- 질환과 직접 대응하는 항목만 연결한다. 억지로 갖다 붙이지 않는다.
         'conditionMap', json_object(
           '01', 'stroke',
           '06', 'heart-attack',
           '12', 'colon-cancer',
           '13', 'stomach-cancer',
           '14', 'breast-cancer',
           '15', 'lung-cancer',
           '20', 'childbirth'
         )
       )
 WHERE slug = 'hira-asm';

-- ------------------------------------------------------------
-- 근거 안내문 정정
-- 척추·관절·백내장·간암은 적정성평가 항목이 존재하지 않는다.
-- 없는 근거를 있다고 쓰면 안 되므로, 실제로 쓰는 근거만 적는다.
-- ------------------------------------------------------------
UPDATE conditions SET basis_note =
  '척추 질환은 심평원 적정성평가 항목에 포함되어 있지 않습니다. 그래서 이 목록은 해당 진료과(신경외과) 전문의 수와 병원 종별만으로 정렬했습니다. 전문병원 지정 배지가 보이더라도 어느 분야 전문병원인지는 공개 API로 확인할 수 없어 순서에 반영하지 않았습니다. 수술 여부는 보존치료 경과에 따라 달라지므로 병원 선택보다 진단이 먼저입니다.'
 WHERE slug IN ('neck-disc', 'back-disc', 'spinal-stenosis');

UPDATE conditions SET basis_note =
  '관절 질환은 심평원 적정성평가 항목에 포함되어 있지 않습니다. 해당 진료과(정형외과) 전문의 수와 병원 종별로 정렬했으며, 수술을 고려한다면 마취 적정성평가 등급이 있는 병원인지 함께 확인해 보세요.'
 WHERE slug IN ('knee-arthritis', 'shoulder');

UPDATE conditions SET basis_note =
  '백내장은 심평원 적정성평가 항목에 포함되어 있지 않습니다. 안과 전문의 수와 병원 종별로 정렬했습니다.'
 WHERE slug = 'cataract';

UPDATE conditions SET basis_note =
  '간암은 별도 적정성평가 항목이 없습니다. 위·대장·유방·폐암과 달리 등급 자료가 공개되지 않아, 혈액종양내과 전문의 수와 병원 종별로 정렬했습니다.'
 WHERE slug = 'liver-cancer';

UPDATE conditions SET basis_note =
  '위암 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.'      WHERE slug = 'stomach-cancer';
UPDATE conditions SET basis_note =
  '대장암 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.'    WHERE slug = 'colon-cancer';
UPDATE conditions SET basis_note =
  '폐암 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.'      WHERE slug = 'lung-cancer';
UPDATE conditions SET basis_note =
  '유방암 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다.'    WHERE slug = 'breast-cancer';
UPDATE conditions SET basis_note =
  '급성기뇌졸중 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 다만 뇌졸중은 시간이 가장 중요하므로, 응급 상황에서는 등급을 따지지 말고 119 또는 가장 가까운 응급실로 가세요.'
 WHERE slug = 'stroke';
UPDATE conditions SET basis_note =
  '관상동맥우회술 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 응급 상황에서는 등급보다 가장 가까운 병원이 우선입니다.'
 WHERE slug = 'heart-attack';
UPDATE conditions SET basis_note =
  '신생아중환자실 적정성평가 등급(심평원 공표)을 1순위 근거로 사용합니다. 분만 가능 여부는 병원에 직접 확인이 필요합니다.'
 WHERE slug = 'childbirth';
UPDATE conditions SET basis_note =
  '소아 야간·휴일 진료 실시기관 지정(심평원 공표)과 소아청소년과 전문의 수를 근거로 합니다. 적정성평가에는 소아 전용 항목이 없어 등급은 반영되지 않습니다.'
 WHERE slug = 'pediatric-night';
