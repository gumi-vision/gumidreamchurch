UPDATE sources
   SET enabled = 1,
       config  = '{"endpoint":"https://apis.data.go.kr/B551182/hospAsmInfoService1/getHospAsmInfo1","numOfRows":500,"pagesPerRun":25,"cursorPage":1,"itemNames":{},"conditionMap":{}}'
 WHERE slug = 'hira-asm';
