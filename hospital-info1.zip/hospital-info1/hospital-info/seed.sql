-- ============================================================
--  기준 데이터 시드
--  지역(regions/districts)은 하드코딩하지 않고 심평원 응답에서
--  자동 생성한다. 코드 체계가 바뀌어도 따라간다.
-- ============================================================

-- 진료과 ------------------------------------------------------
INSERT INTO specialties (slug, name, icon, sort_order) VALUES
  ('neurosurgery',  '신경외과',        '🧠',  1),
  ('orthopedics',   '정형외과',        '🦴',  2),
  ('neurology',     '신경과',          '⚡',  3),
  ('rehab',         '재활의학과',      '🧑‍🦼',  4),
  ('oncology',      '혈액종양내과',    '🎗️',  5),
  ('surgery',       '외과',            '🔬',  6),
  ('radonc',        '방사선종양학과',  '☢️',  7),
  ('pediatrics',    '소아청소년과',    '🧒',  8),
  ('internal',      '내과',            '🩺',  9),
  ('cardiology',    '순환기내과',      '❤️', 10),
  ('gastro',        '소화기내과',      '🫀', 11),
  ('pulmo',         '호흡기내과',      '🫁', 12),
  ('obgyn',         '산부인과',        '🤰', 13),
  ('urology',       '비뇨의학과',      '💧', 14),
  ('ophthalmology', '안과',            '👁️', 15),
  ('ent',           '이비인후과',      '👂', 16),
  ('dermatology',   '피부과',          '🧴', 17),
  ('psychiatry',    '정신건강의학과',  '🧘', 18),
  ('emergency',     '응급의학과',      '🚑', 19),
  ('familymed',     '가정의학과',      '👨‍👩‍👧', 20);

-- 질환 · 이용자 검색어 -----------------------------------------
-- basis_note: "무엇을 근거로 보여주는가"를 화면에 그대로 노출한다.
INSERT INTO conditions (slug, name, specialty_id, aka, summary, basis_note, sort_order) VALUES
  ('neck-disc', '목디스크',
   (SELECT id FROM specialties WHERE slug='neurosurgery'),
   '경추 추간판탈출증,목디스크,경추디스크,목통증',
   '경추 사이 디스크가 밀려나와 신경을 누르는 질환. 팔 저림·목 통증이 흔합니다.',
   '척추 전문병원 지정(보건복지부)과 척추수술 적정성평가 등급을 함께 봅니다. 수술 여부는 보존치료 경과에 따라 달라져 병원 선택 전 진단이 먼저입니다.', 1),

  ('back-disc', '허리디스크',
   (SELECT id FROM specialties WHERE slug='neurosurgery'),
   '요추 추간판탈출증,허리디스크,좌골신경통,다리저림',
   '요추 디스크가 신경근을 압박하는 질환. 다리 방사통이 특징입니다.',
   '척추 전문병원 지정과 요추 추간판탈출증 수술 적정성평가 등급을 근거로 합니다.', 2),

  ('spinal-stenosis', '척추관협착증',
   (SELECT id FROM specialties WHERE slug='neurosurgery'),
   '척추관협착증,협착증,보행시통증',
   '척추관이 좁아져 신경을 압박. 걷다 쉬면 나아지는 간헐적 파행이 특징입니다.',
   '척추 전문병원 지정과 척추수술 적정성평가를 참고합니다.', 3),

  ('knee-arthritis', '무릎 관절염 · 인공관절',
   (SELECT id FROM specialties WHERE slug='orthopedics'),
   '무릎관절염,퇴행성관절염,인공관절,슬관절치환',
   '연골 마모로 통증·변형이 생기는 질환. 진행 정도에 따라 치료가 달라집니다.',
   '관절 전문병원 지정과 슬관절치환술 적정성평가 등급을 봅니다.', 4),

  ('shoulder', '어깨 회전근개',
   (SELECT id FROM specialties WHERE slug='orthopedics'),
   '회전근개,오십견,어깨통증,견관절',
   '어깨 힘줄 손상·염증. 팔을 들기 어렵거나 야간통이 있습니다.',
   '관절 전문병원 지정과 해당 과 전문의 수를 참고합니다.', 5),

  ('stomach-cancer', '위암',
   (SELECT id FROM specialties WHERE slug='oncology'),
   '위암,위선암',
   '국내 발생률이 높은 암. 조기 발견 시 예후가 좋습니다.',
   '위암 적정성평가 등급과 상급종합병원 지정, 암 수술 건수를 함께 봅니다.', 6),

  ('colon-cancer', '대장암',
   (SELECT id FROM specialties WHERE slug='oncology'),
   '대장암,직장암,결장암',
   '대장·직장에 생기는 암. 검진으로 조기 발견이 가능합니다.',
   '대장암 적정성평가 등급과 상급종합병원 지정을 근거로 합니다.', 7),

  ('lung-cancer', '폐암',
   (SELECT id FROM specialties WHERE slug='oncology'),
   '폐암',
   '증상이 늦게 나타나는 암. 저선량 CT 검진이 권고됩니다.',
   '폐암 적정성평가 등급과 상급종합병원 지정을 근거로 합니다.', 8),

  ('breast-cancer', '유방암',
   (SELECT id FROM specialties WHERE slug='oncology'),
   '유방암',
   '여성 암 중 발생률이 높은 암. 정기 검진이 중요합니다.',
   '유방암 적정성평가 등급과 상급종합병원 지정을 근거로 합니다.', 9),

  ('liver-cancer', '간암',
   (SELECT id FROM specialties WHERE slug='oncology'),
   '간암,간세포암',
   'B형·C형 간염, 간경변이 주요 위험요인입니다.',
   '상급종합병원 지정과 장기이식(간이식) 실시기관 여부를 함께 봅니다.', 10),

  ('pediatric-night', '소아 야간·휴일 진료',
   (SELECT id FROM specialties WHERE slug='pediatrics'),
   '소아과,소아청소년과,야간진료,달빛어린이병원,휴일진료',
   '밤이나 휴일에 아이가 아플 때 갈 수 있는 곳.',
   '심평원이 공표하는 소아 야간진료 실시기관 목록과 소아청소년과 전문의 수를 근거로 합니다.', 11),

  ('stroke', '뇌졸중',
   (SELECT id FROM specialties WHERE slug='neurology'),
   '뇌졸중,뇌경색,뇌출혈,중풍',
   '갑작스러운 마비·언어장애. 발병 즉시 응급실로 가야 합니다.',
   '급성기 뇌졸중 적정성평가 등급과 응급의료기관 등급을 함께 봅니다. 응급 상황에서는 등급보다 가장 가까운 병원이 우선입니다.', 12),

  ('heart-attack', '심근경색 · 협심증',
   (SELECT id FROM specialties WHERE slug='cardiology'),
   '심근경색,협심증,관상동맥,스텐트',
   '심장 혈관이 막히는 질환. 가슴 통증이 대표 증상입니다.',
   '급성심근경색증 적정성평가 등급과 심장 전문병원 지정을 근거로 합니다. 응급 시에는 가장 가까운 병원이 우선입니다.', 13),

  ('cataract', '백내장',
   (SELECT id FROM specialties WHERE slug='ophthalmology'),
   '백내장,수정체혼탁',
   '수정체가 뿌옇게 흐려지는 질환. 수술로 교정합니다.',
   '안과 전문의 수와 해당 수술 실시 여부를 참고합니다.', 14),

  ('childbirth', '임신 · 출산',
   (SELECT id FROM specialties WHERE slug='obgyn'),
   '출산,분만,산부인과,제왕절개',
   '분만이 가능한 의료기관은 지역별 편차가 큽니다.',
   '분만 실시기관 여부와 산부인과 전문의 수, 신생아중환자실 보유를 함께 봅니다.', 15);

-- 수집원 ------------------------------------------------------
INSERT INTO sources (slug, name, adapter, base_url, license, enabled, config) VALUES
  ('hira-hosp', '심평원 병원정보서비스', 'hiraHospitalInfo',
   'https://apis.data.go.kr/B551182/hospInfoServicev2/getHospBasisList',
   '공공데이터포털 오픈API · 심평원 제공 (data.go.kr/data/15001698)', 1,
   '{"clCds":["01","11","21"],"numOfRows":500}'),

  ('hira-spcl', '심평원 특수진료병원정보서비스', 'hiraSpecialized',
   'https://apis.data.go.kr/B551182/spclMdlrtHospInfoService',
   '공공데이터포털 오픈API · 심평원 제공 (data.go.kr/data/15001674)', 0,
   '{"note":"활용신청 승인 후 enabled=1. 전문병원 지정·수술별·소아야간진료 목록을 가져온다."}'),

  ('hira-asm', '심평원 병원평가정보서비스', 'hiraAssessment', NULL,
   '공공데이터포털 오픈API · 심평원 제공 (data.go.kr/data/15094093)', 0,
   '{"note":"적정성평가 등급. 요청주소 확인 후 config.endpoint 에 넣고 enabled=1."}'),

  ('hira-detail', '심평원 의료기관별상세정보서비스', 'hiraDetail', NULL,
   '공공데이터포털 오픈API · 심평원 제공 (data.go.kr/data/15001699)', 0,
   '{"note":"진료과목별 전문의 수·장비. 요청주소 확인 후 config.endpoint 에 넣고 enabled=1."}'),

  ('user-report', '이용자 제보', 'userReport', NULL,
   '이용자가 직접 등록한 후기·대기시간 제보 (비의료적 항목만)', 1,
   '{"note":"/api/reviews, /api/wait-reports 로 수집"}');
