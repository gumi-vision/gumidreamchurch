/* ============================================================
   수집 파이프라인 (심평원 공공 오픈API)

   원칙: 우리는 평가하지 않는다. 공표된 것을 그대로 가져와
   출처와 함께 저장한다. 모든 adapter 는 source_id 를 남긴다.
   ============================================================ */

// 헤더 값은 ASCII 로 둔다. 한글을 넣으면 Workers 가 매 요청마다 경고를 뱉는다.
const UA = 'hospital-compass-bot/1.0';

export const todayISO = (now = new Date()) => now.toISOString().slice(0, 10);

const XML_ENTITIES = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&apos;': "'" };
const unescapeXml = (s) => s.replace(/&(amp|lt|gt|quot|apos);/g, m => XML_ENTITIES[m]);

/**
 * 심평원 API 중 일부(특수진료·평가정보)는 XML 전용이라 _type=json 이 통하지 않는다.
 * 응답 구조가 <items><item><tag>값</tag>…</item></items> 로 고정이라
 * 의존성 없이 정규식으로 충분히 안전하게 파싱된다.
 */
function parseXml(text) {
  const pick = (tag) => text.match(new RegExp(`<${tag}>([^<]*)</${tag}>`))?.[1];
  const items = [...text.matchAll(/<item>([\s\S]*?)<\/item>/g)].map(block => {
    const obj = {};
    for (const f of block[1].matchAll(/<([A-Za-z0-9_]+)>([\s\S]*?)<\/\1>/g)) {
      obj[f[1]] = unescapeXml(f[2]);
    }
    return obj;
  });
  return {
    resultCode: pick('resultCode'),
    resultMsg: pick('resultMsg'),
    totalCount: Number(pick('totalCount') || 0),
    items,
  };
}

/** data.go.kr 공통 호출. serviceKey 는 URLSearchParams 가 인코딩한다(디코딩 키 사용). */
async function callApi(endpoint, params, env) {
  const key = (env.HIRA_SERVICE_KEY || '').trim();
  if (!key) throw new Error('HIRA_SERVICE_KEY 시크릿이 없습니다');

  const url = new URL(endpoint);
  url.searchParams.set('serviceKey', key);
  url.searchParams.set('_type', 'json');   // XML 전용 서비스는 그냥 무시한다
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }

  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  const text = await res.text();

  // 미승인·폐기 서비스는 200 으로 오류 문서를 돌려준다. 먼저 걸러낸다.
  if (text.includes('NO_OPENAPI_SERVICE_ERROR')) {
    throw new Error('오픈API 미승인 또는 요청주소 오류 (returnReasonCode 12)');
  }
  if (text.includes('SERVICE_KEY_IS_NOT_REGISTERED')) {
    throw new Error('서비스키가 이 API 에 등록되어 있지 않습니다');
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  if (text.trimStart().startsWith('<')) {
    const x = parseXml(text);
    if (x.resultCode && x.resultCode !== '00') throw new Error(`${x.resultCode} ${x.resultMsg}`);
    return { items: x.items, totalCount: x.totalCount };
  }

  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error('응답을 JSON/XML 어느 쪽으로도 해석하지 못했습니다'); }

  const header = data?.response?.header;
  if (header && header.resultCode !== '00') {
    throw new Error(`${header.resultCode} ${header.resultMsg}`);
  }
  const body = data?.response?.body;
  const raw = body?.items?.item;
  const items = raw == null ? [] : (Array.isArray(raw) ? raw : [raw]);
  return { items, totalCount: Number(body?.totalCount || 0) };
}

/* ---------- 지역 자동 등록 ---------- */
/* 시도·시군구 코드를 하드코딩하지 않고 응답에서 만들어 둔다. */

function slugifySido(name) {
  const map = {
    '서울': 'seoul', '부산': 'busan', '대구': 'daegu', '인천': 'incheon',
    '광주': 'gwangju', '대전': 'daejeon', '울산': 'ulsan', '세종': 'sejong',
    '경기': 'gyeonggi', '강원': 'gangwon', '충북': 'chungbuk', '충남': 'chungnam',
    '전북': 'jeonbuk', '전남': 'jeonnam', '경북': 'gyeongbuk', '경남': 'gyeongnam',
    '제주': 'jeju',
  };
  return map[name] || 'r' + encodeURIComponent(name).replace(/%/g, '').toLowerCase();
}

async function ensureRegions(db, rows) {
  const sidos = new Map();
  const sggus = new Map();
  for (const r of rows) {
    if (r.sidoCd && r.sidoCdNm) sidos.set(String(r.sidoCd), r.sidoCdNm);
    if (r.sgguCd && r.sgguCdNm) sggus.set(String(r.sgguCd), { name: r.sgguCdNm, sido: String(r.sidoCd) });
  }

  if (sidos.size) {
    await db.batch([...sidos].map(([cd, name]) =>
      db.prepare('INSERT INTO regions (sido_cd, slug, name) VALUES (?, ?, ?) ON CONFLICT(sido_cd) DO NOTHING')
        .bind(cd, slugifySido(name), name)));
  }

  const { results: regions } = await db.prepare('SELECT id, sido_cd FROM regions').all();
  const regionByCd = Object.fromEntries(regions.map(r => [r.sido_cd, r.id]));

  if (sggus.size) {
    const stmts = [...sggus]
      .filter(([, v]) => regionByCd[v.sido])
      .map(([cd, v]) =>
        db.prepare('INSERT INTO districts (region_id, sggu_cd, name) VALUES (?, ?, ?) ON CONFLICT(sggu_cd) DO NOTHING')
          .bind(regionByCd[v.sido], cd, v.name));
    for (let i = 0; i < stmts.length; i += 100) await db.batch(stmts.slice(i, i + 100));
  }

  const { results: districts } = await db.prepare('SELECT id, sggu_cd FROM districts').all();
  return {
    regionByCd,
    districtByCd: Object.fromEntries(districts.map(d => [d.sggu_cd, d.id])),
  };
}

/* ---------- Adapters ---------- */

/**
 * 병원정보서비스 — 전국 병원 기본정보.
 * 상급종합/종합병원/병원(clCd 01/11/21)만 담는다. 의원·약국은 이 서비스의 목적이 아니다.
 */
async function hiraHospitalInfo({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  const clCds = config.clCds || ['01', '11', '21'];
  const numOfRows = config.numOfRows || 500;
  const endpoint = source.base_url;

  let all = [];
  for (const clCd of clCds) {
    const first = await callApi(endpoint, { clCd, numOfRows, pageNo: 1 }, env);
    all = all.concat(first.items);
    const pages = Math.ceil(first.totalCount / numOfRows);
    for (let p = 2; p <= pages; p++) {
      const next = await callApi(endpoint, { clCd, numOfRows, pageNo: p }, env);
      all = all.concat(next.items);
    }
  }

  const { regionByCd, districtByCd } = await ensureRegions(db, all);

  const stmt = db.prepare(
    `INSERT INTO hospitals
       (ykiho, name, cl_cd, cl_name, region_id, district_id, emdong, addr, post_no,
        tel, url, lat, lng, estb_dd, dr_total, sdr_count, resident_count, intern_count,
        source_id, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, datetime('now'))
     ON CONFLICT(ykiho) DO UPDATE SET
       name = excluded.name, cl_cd = excluded.cl_cd, cl_name = excluded.cl_name,
       region_id = excluded.region_id, district_id = excluded.district_id,
       emdong = excluded.emdong, addr = excluded.addr, post_no = excluded.post_no,
       tel = excluded.tel, url = excluded.url, lat = excluded.lat, lng = excluded.lng,
       dr_total = excluded.dr_total, sdr_count = excluded.sdr_count,
       resident_count = excluded.resident_count, intern_count = excluded.intern_count,
       updated_at = datetime('now')`
  );

  const batch = all
    .filter(h => h.ykiho && h.yadmNm)
    .map(h => stmt.bind(
      h.ykiho, h.yadmNm, String(h.clCd ?? ''), h.clCdNm ?? null,
      regionByCd[String(h.sidoCd)] ?? null,
      districtByCd[String(h.sgguCd)] ?? null,
      h.emdongNm ?? null, h.addr ?? null, h.postNo ? String(h.postNo) : null,
      h.telno ?? null, h.hospUrl ?? null,
      h.YPos != null ? Number(h.YPos) : null,
      h.XPos != null ? Number(h.XPos) : null,
      h.estbDd ? String(h.estbDd) : null,
      Number(h.drTotCnt) || 0, Number(h.mdeptSdrCnt) || 0,
      Number(h.mdeptResdntCnt) || 0, Number(h.mdeptIntnCnt) || 0,
      source.id
    ));

  for (let i = 0; i < batch.length; i += 100) await db.batch(batch.slice(i, i + 100));
  return { inserted: batch.length };
}

/**
 * 특수진료병원정보서비스 — 전문병원 지정, 수술/시술, 소아 야간진료.
 * "어디가 잘 보나"에 우리가 아닌 정부 지정으로 답하는 핵심 소스.
 */
async function hiraSpecialized({ db, env, source }) {
  const base = source.base_url;
  const config = JSON.parse(source.config || '{}');
  const numOfRows = config.numOfRows || 500;

  // operation -> designations.kind (오퍼레이션명에도 버전 접미사 "1" 이 붙는다)
  const OPS = config.ops || [
    { op: 'getSpcHospList1', kind: '전문병원' },
    { op: 'getChildNightMdlrtList1', kind: '소아야간진료' },
  ];

  const { results: hospRows } = await db.prepare('SELECT id, ykiho FROM hospitals').all();
  const byYkiho = Object.fromEntries(hospRows.map(h => [h.ykiho, h.id]));

  let inserted = 0;
  for (const { op, kind } of OPS) {
    const first = await callApi(`${base}/${op}`, { numOfRows, pageNo: 1 }, env);
    let items = first.items;
    const pages = Math.ceil(first.totalCount / numOfRows);
    for (let p = 2; p <= pages; p++) {
      items = items.concat((await callApi(`${base}/${op}`, { numOfRows, pageNo: p }, env)).items);
    }

    const stmt = db.prepare(
      `INSERT INTO designations (hospital_id, kind, field, source_id, source_url)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(hospital_id, kind, field) DO NOTHING`
    );
    const batch = items
      .filter(it => byYkiho[it.ykiho])
      // field 를 NULL 로 두면 SQLite 가 NULL 끼리 서로 다르다고 보아
      // UNIQUE(hospital_id, kind, field) 중복 방지가 작동하지 않는다. 빈 문자열로 채운다.
      .map(it => stmt.bind(
        byYkiho[it.ykiho], kind,
        it.spcHospTypeNm || it.mdlrtSbjectNm || it.spcifyFieldNm || '',
        source.id, `${base}/${op}`
      ));
    for (let i = 0; i < batch.length; i += 100) await db.batch(batch.slice(i, i + 100));
    inserted += batch.length;
  }
  return { inserted };
}

/**
 * 병원평가정보서비스 — 적정성평가 등급.
 *
 * 응답은 항목코드별 컬럼(asmGrd07, asmGrd08 …)으로 오고 값은 "1"~"5" 또는 "등급제외".
 * clCd 필터가 동작하지 않아 전건(약 3.7만)을 훑어야 하므로,
 * config.cursorPage 에 진행 위치를 남기고 매 실행마다 이어받는다.
 *
 * 항목코드 -> 사람이 읽는 이름은 config.itemNames 로 주입한다.
 * 매핑이 없으면 "평가항목 07" 처럼 코드 그대로 저장하고, 화면에서는 감춘다.
 * 의료 정보라 추측한 이름을 붙이지 않는다.
 */
async function hiraAssessment({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  const endpoint = config.endpoint
    || 'https://apis.data.go.kr/B551182/hospAsmInfoService1/getHospAsmInfo1';
  const numOfRows = config.numOfRows || 500;
  const pagesPerRun = config.pagesPerRun || 25;
  const itemNames = config.itemNames || {};
  const conditionMap = config.conditionMap || {};

  const { results: hospRows } = await db.prepare('SELECT id, ykiho FROM hospitals').all();
  const byYkiho = Object.fromEntries(hospRows.map(h => [h.ykiho, h.id]));
  const { results: condRows } = await db.prepare('SELECT id, slug FROM conditions').all();
  const condBySlug = Object.fromEntries(condRows.map(c => [c.slug, c.id]));

  const first = await callApi(endpoint, { numOfRows, pageNo: 1 }, env);
  const totalPages = Math.max(1, Math.ceil(first.totalCount / numOfRows));

  let page = Math.min(Number(config.cursorPage) || 1, totalPages);
  const stmt = db.prepare(
    `INSERT INTO evaluations (hospital_id, condition_id, subject, grade, year, source_id, source_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     -- condition_id 도 함께 갱신해야 한다. grade 만 갱신하면 매핑을 나중에
     -- 추가했을 때 기존 행의 질환 연결이 NULL 로 남는다.
     ON CONFLICT(hospital_id, subject, year) DO UPDATE SET
       grade = excluded.grade,
       condition_id = excluded.condition_id`
  );

  let inserted = 0;
  const lastPage = Math.min(page + pagesPerRun - 1, totalPages);
  for (; page <= lastPage; page++) {
    const { items } = page === 1 ? first : await callApi(endpoint, { numOfRows, pageNo: page }, env);

    const rows = [];
    for (const it of items) {
      const hospitalId = byYkiho[it.ykiho];
      if (!hospitalId) continue;                  // 병원급 이상만 담는다
      for (const [k, v] of Object.entries(it)) {
        const m = k.match(/^asmGrd(\w+)$/);
        if (!m) continue;
        const grade = Number(v);
        if (!Number.isInteger(grade) || grade < 1 || grade > 5) continue;  // "등급제외" 등 제외
        const code = m[1];
        rows.push(stmt.bind(
          hospitalId, condBySlug[conditionMap[code]] ?? null,
          itemNames[code] || `평가항목 ${code}`, grade, '',
          source.id, endpoint
        ));
      }
    }
    for (let i = 0; i < rows.length; i += 100) await db.batch(rows.slice(i, i + 100));
    inserted += rows.length;
  }

  // 끝까지 돌면 처음으로 되감아 다음 주기에 갱신한다.
  const nextPage = page > totalPages ? 1 : page;
  await db.prepare('UPDATE sources SET config = ? WHERE id = ?')
    .bind(JSON.stringify({ ...config, cursorPage: nextPage, totalPages }), source.id).run();

  return { inserted };
}

/** 의료기관별상세정보서비스 — 진료과목별 전문의 수. */
async function hiraDetail({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  if (!config.endpoint) throw new Error('config.endpoint (요청주소) 가 필요합니다');

  // 병원마다 1회 호출이라 한 번에 다 돌 수 없다(Worker 서브리퀘스트 한도).
  // 아직 안 받아온 병원만 골라 조금씩 진행하고, 매일 크론이 이어받아 채운다.
  const limit = config.limit || 40;
  const { results: hosps } = await db.prepare(
    `SELECT h.id, h.ykiho FROM hospitals h
      WHERE h.cl_cd IN ('01','11','21')
        AND NOT EXISTS (SELECT 1 FROM hospital_specialties hs WHERE hs.hospital_id = h.id)
      ORDER BY h.cl_cd, h.sdr_count DESC
      LIMIT ?`
  ).bind(limit).all();

  const { results: specRows } = await db.prepare('SELECT id, name FROM specialties').all();
  const specByName = Object.fromEntries(specRows.map(s => [s.name, s.id]));

  const stmt = db.prepare(
    `INSERT INTO hospital_specialties (hospital_id, specialty_id, sdr_count)
     VALUES (?, ?, ?) ON CONFLICT(hospital_id, specialty_id) DO UPDATE SET sdr_count = excluded.sdr_count`
  );

  let inserted = 0;
  for (const h of hosps) {
    let items;
    try { ({ items } = await callApi(config.endpoint, { ykiho: h.ykiho }, env)); }
    catch { continue; }
    const batch = items
      .filter(it => specByName[it.dgsbjtCdNm])
      .map(it => stmt.bind(h.id, specByName[it.dgsbjtCdNm], Number(it.dgsbjtPrSdrCnt) || 0));
    if (batch.length) { await db.batch(batch); inserted += batch.length; }
  }
  return { inserted };
}

/**
 * 의료기관 실용정보 — 진료시간·응급실·주차·교통편.
 * 이용자가 실제로 궁금해하는 "이 병원 언제 여나, 주차 되나, 어떻게 가나"를
 * 블로그가 아니라 공식 자료로 채운다. 병원마다 2회 호출이라 이어받기 방식.
 */
async function hiraFacility({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  const base = source.base_url;
  const limit = config.limit || 40;

  // 전문병원 지정을 받은 곳부터 처리한다. 어느 분야 전문병원인지가
  // 질환별 정렬에 바로 쓰이므로 가장 값어치가 크다.
  const { results: hosps } = await db.prepare(
    `SELECT h.id, h.ykiho FROM hospitals h
      WHERE NOT EXISTS (SELECT 1 FROM hospital_details d WHERE d.hospital_id = h.id)
      ORDER BY
        EXISTS (SELECT 1 FROM designations dg
                 WHERE dg.hospital_id = h.id AND dg.kind = '전문병원') DESC,
        h.cl_cd, h.sdr_count DESC
      LIMIT ?`
  ).bind(limit).all();

  const yn = (v) => (v === 'Y' ? 1 : 0);
  // JSON 응답에서는 "0830" 이 숫자 830 으로 온다. 문자열로 바꾸고 4자리로 맞춘다.
  const hhmm = (v) => {
    if (v === undefined || v === null || v === '') return null;
    const s = String(v).padStart(4, '0');
    return /^\d{4}$/.test(s) ? `${s.slice(0, 2)}:${s.slice(2)}` : null;
  };
  const span = (s, e) => {
    const a = hhmm(s), b = hhmm(e);
    return a && b ? `${a} ~ ${b}` : null;
  };

  const dStmt = db.prepare(
    `INSERT INTO hospital_details
       (hospital_id, trmt_weekday, trmt_sat, rcv_week, rcv_sat, lunch_week,
        no_trmt_sun, no_trmt_holi, emy_day, emy_night, emy_tel,
        park_qty, park_paid, park_note, place_name, place_dir, place_dist, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, datetime('now'))
     ON CONFLICT(hospital_id) DO UPDATE SET
       trmt_weekday=excluded.trmt_weekday, trmt_sat=excluded.trmt_sat,
       rcv_week=excluded.rcv_week, rcv_sat=excluded.rcv_sat, lunch_week=excluded.lunch_week,
       no_trmt_sun=excluded.no_trmt_sun, no_trmt_holi=excluded.no_trmt_holi,
       emy_day=excluded.emy_day, emy_night=excluded.emy_night, emy_tel=excluded.emy_tel,
       park_qty=excluded.park_qty, park_paid=excluded.park_paid, park_note=excluded.park_note,
       updated_at=datetime('now')`
  );
  const tStmt = db.prepare(
    `INSERT INTO hospital_transit (hospital_id, kind, line_no, arrive, direction, distance)
     VALUES (?,?,?,?,?,?) ON CONFLICT(hospital_id, kind, line_no, arrive) DO NOTHING`
  );

  let inserted = 0;
  for (const h of hosps) {
    // 세부정보 호출이 실패해도 건너뛰지 않는다. 건너뛰면 hospital_details 행이
    // 생기지 않아 "미처리"로 남고, 매번 같은 병원만 다시 시도하게 된다.
    let detail = {};
    try {
      const { items } = await callApi(`${base}/getDtlInfo2.8`, { ykiho: h.ykiho }, env);
      detail = items[0] || {};
    } catch { /* 세부정보 없는 기관도 있다. 나머지 정보는 계속 받는다. */ }

    const rows = [dStmt.bind(
      h.id,
      span(detail.trmtMonStart, detail.trmtMonEnd),
      span(detail.trmtSatStart, detail.trmtSatEnd),
      detail.rcvWeek || null, detail.rcvSat || null, detail.lunchWeek || null,
      detail.noTrmtSun || null, detail.noTrmtHoli || null,
      yn(detail.emyDayYn), yn(detail.emyNgtYn),
      detail.emyDayTelNo1 || detail.emyNgtTelNo1 || null,
      detail.parkQty ? Number(detail.parkQty) : null,
      yn(detail.parkXpnsYn), detail.parkEtc || null,
      detail.plcNm || null, detail.plcDir || null, detail.plcDist || null
    )];

    try {
      const { items: tr } = await callApi(`${base}/getTrnsprtInfo2.8`, { ykiho: h.ykiho }, env);
      for (const t of tr.slice(0, 6)) {
        rows.push(tStmt.bind(
          h.id, t.trafNm || '', t.lineNo || '', t.arivPlc || '', t.dir || null, t.dist || null
        ));
      }
    } catch { /* 교통정보는 없을 수 있다 */ }

    // 시설(병상 수)
    try {
      const { items } = await callApi(`${base}/getEqpInfo2.8`, { ykiho: h.ykiho }, env);
      const f = items[0];
      if (f) {
        const num = (v) => (v === undefined || v === null || v === '' ? null : Number(v));
        rows.push(db.prepare(
          `INSERT INTO hospital_facility
             (hospital_id, org_type, beds_total, beds_standard, beds_upper,
              icu_adult, icu_child, icu_newborn, beds_isolation, beds_negative,
              beds_emergency, op_rooms, delivery_rooms, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, datetime('now'))
           ON CONFLICT(hospital_id) DO UPDATE SET
             org_type=excluded.org_type, beds_total=excluded.beds_total,
             beds_standard=excluded.beds_standard, beds_upper=excluded.beds_upper,
             icu_adult=excluded.icu_adult, icu_child=excluded.icu_child,
             icu_newborn=excluded.icu_newborn, beds_isolation=excluded.beds_isolation,
             beds_negative=excluded.beds_negative, beds_emergency=excluded.beds_emergency,
             op_rooms=excluded.op_rooms, delivery_rooms=excluded.delivery_rooms,
             updated_at=datetime('now')`
        ).bind(
          h.id, f.orgTyCdNm || null, num(f.permSbdCnt), num(f.stdSickbdCnt), num(f.hghrSickbdCnt),
          num(f.aduChldSprmCnt), num(f.chldSprmCnt), num(f.nbySprmCnt),
          num(f.isnrSbdCnt), num(f.anvirTrrmSbdCnt), num(f.emymCnt),
          num(f.soprmCnt), num(f.partumCnt)
        ));
      }
    } catch { /* 시설정보가 없는 기관도 있다 */ }

    // 의료장비
    try {
      const { items } = await callApi(`${base}/getMedOftInfo2.8`, { ykiho: h.ykiho, numOfRows: 50 }, env);
      const eStmt = db.prepare(
        `INSERT INTO hospital_equipment (hospital_id, code, name, qty) VALUES (?,?,?,?)
         ON CONFLICT(hospital_id, code) DO UPDATE SET qty = excluded.qty`);
      for (const it of items) {
        if (it.oftCd && it.oftCdNm) rows.push(eStmt.bind(h.id, it.oftCd, it.oftCdNm, Number(it.oftCnt) || 0));
      }
    } catch { /* 장비정보 없음 */ }

    // 간호등급 — 건강보험 기준만 쓴다
    try {
      const { items } = await callApi(`${base}/getNursigGrdInfo2.8`, { ykiho: h.ykiho }, env);
      const g = items.find(x => x.tyCd === '01' || x.tyCdNm === '건강보험');
      if (g && g.careGrd) {
        rows.push(db.prepare('UPDATE hospitals SET nursing_grade = ? WHERE id = ?')
          .bind(String(g.careGrd), h.id));
      }
    } catch { /* 간호등급 없음 */ }

    // 전문병원 지정분야 — 어느 분야 전문병원인지 알아야 질환별 정렬에 쓸 수 있다
    try {
      const { items } = await callApi(`${base}/getSpclHospAsgFldList2.8`, { ykiho: h.ykiho }, env);
      const dStmt2 = db.prepare(
        `INSERT INTO designations (hospital_id, kind, field, source_id, source_url)
         VALUES (?, '전문병원', ?, ?, ?)
         ON CONFLICT(hospital_id, kind, field) DO NOTHING`);
      for (const it of items) {
        if (it.srchCdNm) {
          rows.push(dStmt2.bind(h.id, it.srchCdNm, source.id, `${base}/getSpclHospAsgFldList2.8`));
        }
      }
    } catch { /* 전문병원이 아니면 없음 */ }

    for (let i = 0; i < rows.length; i += 60) await db.batch(rows.slice(i, i + 60));
    inserted += rows.length;
  }
  return { inserted };
}

/**
 * 비급여 항목 마스터.
 * 이 서비스의 병원별 "가격" 오퍼레이션은 응답은 정상이나 데이터가 0건이라
 * (2021년 이후 별도 공개 시스템으로 이관된 것으로 보임) 항목 목록만 받는다.
 * 가격을 추정해서 채우지 않는다.
 */
async function hiraNonCovered({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  const numOfRows = config.numOfRows || 900;
  const endpoint = `${source.base_url}/getNonPaymentItemCodeList2`;

  const first = await callApi(endpoint, { numOfRows, pageNo: 1 }, env);
  let items = first.items;
  const pages = Math.ceil(first.totalCount / numOfRows);
  for (let p = 2; p <= pages; p++) {
    items = items.concat((await callApi(endpoint, { numOfRows, pageNo: p }, env)).items);
  }

  const stmt = db.prepare(
    `INSERT INTO noncovered_items (code, name, major, minor, valid_from, source_id)
     VALUES (?,?,?,?,?,?)
     ON CONFLICT(code) DO UPDATE SET
       name = excluded.name, major = excluded.major, minor = excluded.minor`
  );
  const rows = items
    .filter(it => it.npayCd && it.npayKorNm)
    .map(it => stmt.bind(
      it.npayCd, it.npayKorNm, it.npayMdivCdNm || null,
      it.npaySdivCdNm || null, it.adtFrDd || null, source.id
    ));
  for (let i = 0; i < rows.length; i += 100) await db.batch(rows.slice(i, i + 100));
  return { inserted: rows.length };
}

/**
 * 홈페이지 링크 점검.
 * 심평원 hospUrl 은 갱신이 늦어 접속되지 않는 주소가 섞여 있다.
 * 살아있는지만 확인하고 상태를 남긴다. 페이지 내용은 수집하지 않는다.
 */
async function linkCheck({ db, env, source }) {
  const config = JSON.parse(source.config || '{}');
  const limit = config.limit || 60;

  // 미확인 우선, 그다음 오래된 것부터. 30일이 지나면 다시 확인한다.
  const { results: targets } = await db.prepare(
    `SELECT id, url FROM hospitals
      WHERE url IS NOT NULL AND TRIM(url) <> '' AND TRIM(url) <> '-'
        AND (url_checked_at IS NULL OR url_checked_at < datetime('now', '-30 days'))
      ORDER BY url_checked_at IS NOT NULL, url_checked_at
      LIMIT ?`
  ).bind(limit).all();
  if (!targets.length) return { inserted: 0 };

  const normalize = (raw) => {
    const s = String(raw || '').trim();
    if (!s) return null;
    return /^https?:\/\//i.test(s) ? s : 'http://' + s;
  };

  const stmt = db.prepare(
    `UPDATE hospitals SET url_status = ?, url_final = ?, url_checked_at = datetime('now') WHERE id = ?`
  );

  const rows = await Promise.all(targets.map(async (t) => {
    const url = normalize(t.url);
    if (!url) return stmt.bind('dead', null, t.id);
    try {
      // 일부 병원 서버가 HEAD 를 막아 GET 으로 확인하되 본문은 읽지 않는다.
      const res = await fetch(url, {
        method: 'GET',
        redirect: 'follow',
        headers: { 'User-Agent': UA },
        signal: AbortSignal.timeout(8000),
      });
      const ok = res.status < 400;
      return stmt.bind(ok ? 'ok' : 'dead', ok ? res.url : null, t.id);
    } catch {
      return stmt.bind('dead', null, t.id);
    }
  }));

  for (let i = 0; i < rows.length; i += 100) await db.batch(rows.slice(i, i + 100));
  return { inserted: rows.length };
}

/** 이용자 제보는 API 로 직접 들어온다. 배치가 할 일 없음. */
async function userReport() { return { inserted: 0 }; }

export const ADAPTERS = {
  hiraHospitalInfo, hiraSpecialized, hiraAssessment, hiraDetail, hiraFacility,
  hiraNonCovered, linkCheck, userReport,
};

/* ---------- 실행기 ---------- */
export async function runIngestion(env, { only = null } = {}) {
  const db = env.DB;
  let query = 'SELECT * FROM sources WHERE enabled = 1';
  const binds = [];
  if (only) { query += ' AND slug = ?'; binds.push(only); }
  const { results: sources } = await db.prepare(query).bind(...binds).all();

  /*
   * 실행 기록(crawl_runs)을 남기는 일은 부수적이다. 그게 실패해도 수집은 계속돼야 한다.
   *
   * 2026-09-04 새벽 크론 세 번(05:00 / 05:20 / 05:30)이 전부 죽었다. 원인은 아래
   * INSERT 가 try 밖, 반복문 맨 앞에 있었던 것이다. 그게 던지자 첫 수집원의 어댑터를
   * 부르기도 전에 runIngestion 전체가 끝났고, crawl_runs 에는 running 행조차 안 남아
   * 무슨 일이 있었는지 알 수 없었다. 기록하는 코드가 본 작업을 죽이면 안 된다.
   */
  const quietly = async (what, fn) => {
    try { return await fn(); }
    catch (err) { console.error(`${what} 실패`, String(err.message || err)); return null; }
  };

  const report = [];
  for (const source of sources) {
    const run = await quietly(`crawl_runs 기록(${source.slug})`, () => db.prepare(
      'INSERT INTO crawl_runs (source_id, status) VALUES (?, ?) RETURNING id'
    ).bind(source.id, 'running').first());

    // 기록에 실패했으면 갱신할 대상도 없다. 수집은 그대로 진행한다.
    const finish = (sql, ...binds) => run
      ? quietly(`crawl_runs 갱신(${source.slug})`, () => db.prepare(sql).bind(...binds, run.id).run())
      : null;

    try {
      const adapter = ADAPTERS[source.adapter];
      if (!adapter) throw new Error(`알 수 없는 adapter: ${source.adapter}`);
      const { inserted } = await adapter({ db, env, source });

      await finish(
        `UPDATE crawl_runs SET status='ok', inserted=?, finished_at=datetime('now') WHERE id=?`, inserted);
      await quietly(`sources 갱신(${source.slug})`, () => db.prepare(
        `UPDATE sources SET last_run_at=datetime('now') WHERE id=?`).bind(source.id).run());
      report.push({ source: source.slug, status: 'ok', inserted });
    } catch (err) {
      const message = String(err.message || err);
      // DB 기록이 실패하면 이 로그만 남는다. 원인을 여기서 확실히 붙잡아 둔다.
      console.error('수집 실패', source.slug, message, (err && err.stack) || '');
      await finish(
        `UPDATE crawl_runs SET status='error', message=?, finished_at=datetime('now') WHERE id=?`, message);
      report.push({ source: source.slug, status: 'error', message });
    }
  }
  return { date: todayISO(), sources: report };
}
