import { runIngestion, todayISO } from './crawler.js';
import { handleAsk } from './ask.js';
import { checkModels, MODEL_CHAIN } from './ai.js';

const json = (d, status = 200) =>
  Response.json(d, { status, headers: { 'Cache-Control': 'no-store' } });
const bad = (m, status = 400) => json({ error: m }, status);

const median = (nums) => {
  const a = nums.filter(n => n != null).sort((x, y) => x - y);
  if (!a.length) return null;
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : Math.round((a[m - 1] + a[m]) / 2);
};

/* ---------- 조회 ---------- */

async function getBootstrap(env) {
  const [regions, specialties, conditions, fresh] = await Promise.all([
    env.DB.prepare(
      `SELECT r.slug, r.name, COUNT(h.id) AS hospital_count,
              (SELECT json_group_array(json_object('code', d.sggu_cd, 'name', d.name, 'n', dc.n))
                 FROM districts d
                 JOIN (SELECT district_id, COUNT(*) AS n FROM hospitals
                        WHERE district_id IS NOT NULL GROUP BY district_id) dc
                   ON dc.district_id = d.id
                WHERE d.region_id = r.id
                ORDER BY d.name) AS districts
         FROM regions r LEFT JOIN hospitals h ON h.region_id = r.id
        GROUP BY r.id ORDER BY r.id`).all(),
    env.DB.prepare('SELECT slug, name, icon FROM specialties ORDER BY sort_order').all(),
    env.DB.prepare(
      `SELECT c.slug, c.name, c.aka, c.summary, c.basis_note, s.name AS specialty, s.icon
         FROM conditions c JOIN specialties s ON s.id = c.specialty_id
        ORDER BY c.sort_order`).all(),
    env.DB.prepare(
      `SELECT (SELECT COUNT(*) FROM hospitals) AS hospitals,
              (SELECT COUNT(*) FROM designations) AS designations,
              (SELECT COUNT(*) FROM evaluations) AS evaluations,
              (SELECT MAX(updated_at) FROM hospitals) AS updated_at`).first(),
  ]);
  return json({
    regions: regions.results.map(r => ({ ...r, districts: JSON.parse(r.districts || '[]') })),
    specialties: specialties.results,
    conditions: conditions.results, freshness: fresh,
  });
}

/**
 * 질환별 병원 — 우리가 점수를 만들지 않고, 공표된 근거의 "유무와 등급"으로만 정렬한다.
 * 정렬 우선순위: 전문병원 지정 → 적정성평가 등급(1등급이 위) → 해당 진료과 전문의 수 → 전체 전문의 수
 * 화면에는 이 순서를 그대로 명시한다.
 */
async function getByCondition(env, slug, url) {
  const regionSlug = url.searchParams.get('region');
  const limit = Math.min(Number(url.searchParams.get('limit')) || 30, 100);

  const cond = await env.DB.prepare(
    `SELECT c.id, c.slug, c.name, c.summary, c.basis_note, c.aka,
            s.id AS specialty_id, s.name AS specialty, s.slug AS specialty_slug, s.icon
       FROM conditions c JOIN specialties s ON s.id = c.specialty_id
      WHERE c.slug = ?`).bind(slug).first();
  if (!cond) return bad('알 수 없는 질환입니다', 404);

  let region = null;
  if (regionSlug) {
    region = await env.DB.prepare('SELECT id, name, slug FROM regions WHERE slug = ?')
      .bind(regionSlug).first();
    if (!region) return bad('알 수 없는 지역입니다');
  }

  // SELECT 절의 ? 순서와 정확히 맞춘다:
  // is_specialized(condition_id) → dept_sdr(specialty_id) → best_grade(condition_id) → wait(specialty_id)
  const binds = [cond.id, cond.specialty_id, cond.id, cond.specialty_id];

  // 질환과 무관한 기관을 걸러낸다.
  // 치과병원(41)이 허리디스크 목록에 뜨던 문제. 종별과 실제 진료과로 판단한다.
  const conds = [relevanceFilter(cond, binds)];
  if (region) { conds.push('h.region_id = ?'); binds.push(region.id); }

  // 시군구까지 좁히기 (경북 → 포항시)
  const districtCd = url.searchParams.get('district');
  let district = null;
  if (districtCd) {
    district = await env.DB.prepare('SELECT id, name, sggu_cd FROM districts WHERE sggu_cd = ?')
      .bind(districtCd).first();
    if (district) { conds.push('h.district_id = ?'); binds.push(district.id); }
  }
  const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
  binds.push(limit);

  const { results } = await env.DB.prepare(
    `SELECT h.id, h.name, h.cl_name, h.addr, h.tel, h.url, h.dr_total, h.sdr_count,
            r.name AS region, d.name AS district,
            (SELECT GROUP_CONCAT(dg.kind || '·' || COALESCE(dg.field, ''), '|')
               FROM designations dg WHERE dg.hospital_id = h.id) AS designations,
            -- 이 질환에 해당하는 분야의 전문병원인지만 센다.
            -- (심장 전문병원이 허리디스크 상위로 오르면 안 된다)
            (SELECT COUNT(*) FROM designations dg
               JOIN designation_conditions dc ON dc.field = dg.field
              WHERE dg.hospital_id = h.id AND dg.kind = '전문병원'
                AND dc.condition_id = ?) AS is_specialized,
            (SELECT GROUP_CONCAT(dg.field, ', ') FROM designations dg
              WHERE dg.hospital_id = h.id AND dg.kind = '전문병원'
                AND dg.field IS NOT NULL AND dg.field <> '') AS spec_fields,
            (SELECT hs.sdr_count FROM hospital_specialties hs
              WHERE hs.hospital_id = h.id AND hs.specialty_id = ?) AS dept_sdr,
            (SELECT MIN(e.grade) FROM evaluations e
              WHERE e.hospital_id = h.id AND e.condition_id = ? AND e.grade IS NOT NULL) AS best_grade,
            (SELECT COUNT(*) FROM reviews rv WHERE rv.hospital_id = h.id) AS review_count,
            (SELECT COUNT(*) FROM wait_reports w
              WHERE w.hospital_id = h.id AND w.specialty_id = ?) AS wait_reports
       FROM hospitals h
       LEFT JOIN regions r ON r.id = h.region_id
       LEFT JOIN districts d ON d.id = h.district_id
       ${where}
      -- 이제 전문병원 "분야"를 알 수 있으므로(getSpclHospAsgFldList2.8),
      -- 해당 질환 분야의 전문병원만 상위로 올린다.
      ORDER BY is_specialized DESC,
               best_grade IS NULL, best_grade ASC,
               COALESCE(dept_sdr, 0) DESC,
               h.sdr_count DESC
      LIMIT ?`
  ).bind(...binds).all();

  const fresh = await env.DB.prepare(
    `SELECT MAX(last_run_at) AS at FROM sources
      WHERE slug IN ('hira-hosp','hira-asm','hira-spcl','hira-detail')`).first();

  return json({
    condition: cond,
    region: region ? { slug: region.slug, name: region.name } : null,
    district: district ? { code: district.sggu_cd, name: district.name } : null,
    dataAsOf: fresh?.at ? String(fresh.at).slice(0, 10) : null,
    orderExplanation: [
      `보건복지부 ${cond.name} 관련 분야 전문병원 지정`,
      '심평원 적정성평가 등급 (1등급이 상위)',
      '해당 진료과 전문의 수',
      '전체 전문의 수',
    ],
    orderCaveat: null,
    hospitals: results,
  });
}

async function getHospitals(env, url) {
  const regionSlug = url.searchParams.get('region');
  const q = (url.searchParams.get('q') || '').trim();
  const cl = url.searchParams.get('cl');
  const limit = Math.min(Number(url.searchParams.get('limit')) || 40, 100);

  const where = [];
  const binds = [];
  if (regionSlug) {
    where.push('r.slug = ?'); binds.push(regionSlug);
  }
  if (q) { where.push('h.name LIKE ?'); binds.push(`%${q}%`); }
  if (cl) { where.push('h.cl_cd = ?'); binds.push(cl); }
  binds.push(limit);

  const { results } = await env.DB.prepare(
    `SELECT h.id, h.name, h.cl_name, h.addr, h.tel, h.url, h.dr_total, h.sdr_count,
            r.name AS region, d.name AS district,
            (SELECT COUNT(*) FROM designations dg
              WHERE dg.hospital_id = h.id AND dg.kind = '전문병원') AS is_specialized,
            (SELECT COUNT(*) FROM reviews rv WHERE rv.hospital_id = h.id) AS review_count
       FROM hospitals h
       LEFT JOIN regions r ON r.id = h.region_id
       LEFT JOIN districts d ON d.id = h.district_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY is_specialized DESC, h.sdr_count DESC
      LIMIT ?`
  ).bind(...binds).all();

  return json({ count: results.length, hospitals: results });
}

/**
 * 질환과 무관한 기관을 제외하는 SQL 조건을 만든다.
 *
 *  1) 치과 질환은 치과병원(종별 41) 또는 치과를 운영하는 기관만.
 *     반대로 치과 외 질환에서는 치과병원을 제외한다.
 *     (구미시 허리디스크 검색에 치과병원이 뜨던 문제)
 *  2) 진료과 목록을 이미 받아온 기관인데 해당 과가 없으면 제외한다.
 *     아직 수집하지 않은 기관은 "모름"이므로 남긴다.
 *
 * binds 배열에 필요한 값을 순서대로 밀어 넣는다.
 */
function relevanceFilter(cond, binds) {
  const isDental = cond.specialty_slug === 'dentistry';

  if (isDental) {
    binds.push(cond.specialty_id);
    return `(h.cl_cd = '41' OR EXISTS (
               SELECT 1 FROM hospital_specialties hs
                WHERE hs.hospital_id = h.id AND hs.specialty_id = ?))`;
  }

  binds.push(cond.specialty_id);
  return `(h.cl_cd <> '41' AND (
             NOT EXISTS (SELECT 1 FROM hospital_specialties hs WHERE hs.hospital_id = h.id)
             OR EXISTS (SELECT 1 FROM hospital_specialties hs
                         WHERE hs.hospital_id = h.id AND hs.specialty_id = ?)))`;
}

/**
 * 질환을 거쳐 들어온 경우, 그 질환에 해당하는 근거만 따로 뽑아준다.
 * 목디스크로 들어왔는데 주차 정보가 먼저 보이면 아무 소용이 없다.
 */
async function getConditionContext(env, hospitalId, slug) {
  const cond = await env.DB.prepare(
    `SELECT c.id, c.slug, c.name, c.summary, c.basis_note,
            c.tx_conservative, c.tx_surgical, c.cost_note,
            s.id AS specialty_id, s.name AS specialty, s.slug AS specialty_slug
       FROM conditions c JOIN specialties s ON s.id = c.specialty_id
      WHERE c.slug = ?`).bind(slug).first();
  if (!cond) return null;

  const [deptRow, evals, waitRows, reviewRow] = await Promise.all([
    env.DB.prepare(
      'SELECT sdr_count FROM hospital_specialties WHERE hospital_id = ? AND specialty_id = ?'
    ).bind(hospitalId, cond.specialty_id).first(),
    env.DB.prepare(
      `SELECT subject, grade, year FROM evaluations
        WHERE hospital_id = ? AND condition_id = ? ORDER BY grade ASC`
    ).bind(hospitalId, cond.id).all(),
    env.DB.prepare(
      'SELECT wait_days, wait_minutes FROM wait_reports WHERE hospital_id = ? AND specialty_id = ?'
    ).bind(hospitalId, cond.specialty_id).all(),
    env.DB.prepare(
      `SELECT COUNT(*) AS n, ROUND(AVG(explain_score),1) AS explain, ROUND(AVG(wait_score),1) AS wait
         FROM reviews WHERE hospital_id = ? AND specialty_id = ?`
    ).bind(hospitalId, cond.specialty_id).first(),
  ]);

  return {
    condition: {
      slug: cond.slug, name: cond.name, summary: cond.summary,
      basis: cond.basis_note, specialty: cond.specialty, specialtySlug: cond.specialty_slug,
      txConservative: cond.tx_conservative, txSurgical: cond.tx_surgical, costNote: cond.cost_note,
    },
    deptSdr: deptRow?.sdr_count ?? null,
    evaluations: evals.results,
    wait: {
      sample: waitRows.results.length,
      medianDays: median(waitRows.results.map(w => w.wait_days)),
      medianMinutes: median(waitRows.results.map(w => w.wait_minutes)),
    },
    reviews: reviewRow,
  };
}

async function getHospital(env, id, url) {
  const h = await env.DB.prepare(
    `SELECT h.*, r.name AS region, r.slug AS region_slug, d.name AS district,
            s.name AS source_name, s.license AS source_license
       FROM hospitals h
       LEFT JOIN regions r ON r.id = h.region_id
       LEFT JOIN districts d ON d.id = h.district_id
       LEFT JOIN sources s ON s.id = h.source_id
      WHERE h.id = ?`).bind(id).first();
  if (!h) return bad('병원을 찾을 수 없습니다', 404);

  const [desigs, evals, depts, doctors, reviewAgg, reviews, waits,
         details, facility, equipment, transit] = await Promise.all([
    env.DB.prepare('SELECT kind, field, source_url FROM designations WHERE hospital_id = ?').bind(id).all(),
    env.DB.prepare(
      `SELECT e.subject, e.grade, e.year, e.source_url, c.name AS condition
         FROM evaluations e LEFT JOIN conditions c ON c.id = e.condition_id
        WHERE e.hospital_id = ? ORDER BY e.grade IS NULL, e.grade ASC`).bind(id).all(),
    env.DB.prepare(
      `SELECT s.name, s.slug, hs.sdr_count FROM hospital_specialties hs
         JOIN specialties s ON s.id = hs.specialty_id
        WHERE hs.hospital_id = ? ORDER BY hs.sdr_count DESC`).bind(id).all(),
    env.DB.prepare(
      `SELECT d.name, d.title, d.focus_areas, d.profile_url, s.name AS specialty
         FROM doctors d LEFT JOIN specialties s ON s.id = d.specialty_id
        WHERE d.hospital_id = ? ORDER BY d.name`).bind(id).all(),
    env.DB.prepare(
      `SELECT COUNT(*) AS n,
              ROUND(AVG(booking_score),1)  AS booking,
              ROUND(AVG(wait_score),1)     AS wait,
              ROUND(AVG(explain_score),1)  AS explain,
              ROUND(AVG(facility_score),1) AS facility,
              ROUND(AVG(staff_score),1)    AS staff
         FROM reviews WHERE hospital_id = ?`).bind(id).first(),
    env.DB.prepare(
      `SELECT nickname, booking_score, wait_score, explain_score, facility_score,
              staff_score, comment, created_at
         FROM reviews WHERE hospital_id = ? ORDER BY created_at DESC LIMIT 10`).bind(id).all(),
    env.DB.prepare('SELECT wait_days, wait_minutes FROM wait_reports WHERE hospital_id = ?').bind(id).all(),
    env.DB.prepare('SELECT * FROM hospital_details WHERE hospital_id = ?').bind(id).first(),
    env.DB.prepare('SELECT * FROM hospital_facility WHERE hospital_id = ?').bind(id).first(),
    env.DB.prepare(
      'SELECT name, qty FROM hospital_equipment WHERE hospital_id = ? ORDER BY qty DESC LIMIT 14'
    ).bind(id).all(),
    env.DB.prepare(
      'SELECT kind, line_no, arrive, direction, distance FROM hospital_transit WHERE hospital_id = ? LIMIT 8'
    ).bind(id).all(),
  ]);

  const condSlug = url && url.searchParams.get('condition');
  const conditionContext = condSlug ? await getConditionContext(env, id, condSlug) : null;

  // 화면마다 "이 정보가 언제 기준인지" 알 수 있게 수집 시각을 함께 내려준다.
  const { results: srcRuns } = await env.DB.prepare(
    `SELECT slug, last_run_at FROM sources WHERE slug IN
       ('hira-hosp','hira-asm','hira-spcl','hira-facility','hira-detail')`).all();
  const runBySlug = Object.fromEntries(srcRuns.map(s => [s.slug, s.last_run_at]));
  const day = (t) => (t ? String(t).slice(0, 10) : null);

  return json({
    hospital: h,
    conditionContext,
    details: details || null,
    facility: facility || null,
    equipment: equipment.results,
    transit: transit.results,
    freshness: {
      basic: day(h.updated_at) || day(runBySlug['hira-hosp']),
      details: day(details?.updated_at) || day(runBySlug['hira-facility']),
      facility: day(facility?.updated_at) || day(runBySlug['hira-facility']),
      evaluations: day(runBySlug['hira-asm']),
      designations: day(runBySlug['hira-spcl']),
      departments: day(runBySlug['hira-detail']),
      // 심평원 평가 API 응답에 평가 연도 필드가 없다. 없는 것을 있는 척하지 않는다.
      evaluationYearAvailable: false,
    },
    designations: desigs.results,
    evaluations: evals.results,
    departments: depts.results,
    doctors: doctors.results,
    reviewSummary: reviewAgg,
    reviews: reviews.results,
    wait: {
      sample: waits.results.length,
      medianDays: median(waits.results.map(w => w.wait_days)),
      medianMinutes: median(waits.results.map(w => w.wait_minutes)),
    },
  });
}

/* ---------- 쓰기 ---------- */

const clamp5 = (v) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 1 && n <= 5 ? n : null;
};

async function postReview(env, request) {
  let b; try { b = await request.json(); } catch { return bad('JSON 형식이 아닙니다'); }

  const hospitalId = Number(b.hospitalId);
  const nickname = String(b.nickname || '').trim().slice(0, 20);
  const scores = {
    booking: clamp5(b.booking), wait: clamp5(b.wait), explain: clamp5(b.explain),
    facility: clamp5(b.facility), staff: clamp5(b.staff),
  };
  if (!hospitalId || !nickname) return bad('병원과 닉네임을 확인해주세요');
  if (Object.values(scores).some(v => v == null)) return bad('5개 항목을 모두 1~5로 평가해주세요');

  const exists = await env.DB.prepare('SELECT id FROM hospitals WHERE id = ?').bind(hospitalId).first();
  if (!exists) return bad('병원을 찾을 수 없습니다', 404);

  const spec = b.specialty
    ? await env.DB.prepare('SELECT id FROM specialties WHERE slug = ?').bind(b.specialty).first()
    : null;

  const row = await env.DB.prepare(
    `INSERT INTO reviews (hospital_id, specialty_id, nickname, booking_score, wait_score,
                          explain_score, facility_score, staff_score, comment)
     VALUES (?,?,?,?,?,?,?,?,?) RETURNING id`
  ).bind(
    hospitalId, spec?.id ?? null, nickname,
    scores.booking, scores.wait, scores.explain, scores.facility, scores.staff,
    String(b.comment || '').trim().slice(0, 300) || null
  ).first();

  return json({ id: row.id }, 201);
}

async function postWaitReport(env, request) {
  let b; try { b = await request.json(); } catch { return bad('JSON 형식이 아닙니다'); }

  const hospitalId = Number(b.hospitalId);
  const waitDays = b.waitDays == null ? null : Math.max(0, Math.round(Number(b.waitDays)));
  const waitMinutes = b.waitMinutes == null ? null : Math.max(0, Math.round(Number(b.waitMinutes)));
  if (!hospitalId) return bad('병원을 확인해주세요');
  if (waitDays == null && waitMinutes == null) return bad('예약 대기일 또는 현장 대기시간 중 하나는 입력해주세요');

  const spec = b.specialty
    ? await env.DB.prepare('SELECT id FROM specialties WHERE slug = ?').bind(b.specialty).first()
    : null;

  const row = await env.DB.prepare(
    `INSERT INTO wait_reports (hospital_id, specialty_id, wait_days, wait_minutes, visited_on)
     VALUES (?,?,?,?,?) RETURNING id`
  ).bind(hospitalId, spec?.id ?? null, waitDays, waitMinutes,
         String(b.visitedOn || '').slice(0, 10) || null).first();

  return json({ id: row.id }, 201);
}

/* ---------- 운영 ---------- */

/**
 * 비용 안내 — 제도 정보 + 비급여 항목 검색.
 * 개인별 보험금은 계산하지 않는다. 가입 시기·특약에 따라 달라져
 * 숫자를 제시하면 잘못된 기대를 만들기 때문이다.
 */
async function getCost(env, url) {
  const q = (url.searchParams.get('q') || '').trim();

  const [guides, items, total] = await Promise.all([
    env.DB.prepare('SELECT slug, title, body, source_note FROM cost_guides ORDER BY sort_order').all(),
    q
      ? env.DB.prepare(
          `SELECT code, name, major, minor FROM noncovered_items
            WHERE name LIKE ? OR major LIKE ? ORDER BY name LIMIT 40`
        ).bind(`%${q}%`, `%${q}%`).all()
      : env.DB.prepare(
          `SELECT code, name, major, minor FROM noncovered_items
            WHERE major IS NOT NULL ORDER BY major, name LIMIT 40`
        ).all(),
    env.DB.prepare('SELECT COUNT(*) AS n FROM noncovered_items').first(),
  ]);

  return json({
    guides: guides.results,
    items: items.results,
    itemTotal: total.n,
    query: q,
    priceNotice:
      '병원별 비급여 가격은 심평원 오픈API 로 제공되지 않아 이 서비스에서는 금액을 표시하지 않습니다. ' +
      '가격은 병원에 직접 확인하시거나 심평원 비급여 진료비 공개 페이지에서 비교하세요.',
  });
}

async function getStatus(env) {
  const activeModel = await env.DB.prepare("SELECT value, updated_at FROM ai_state WHERE key='ai.active_model'")
    .first().catch(() => null);

  const [runs, sources] = await Promise.all([
    env.DB.prepare(
      `SELECT r.id, r.status, r.inserted, r.started_at, r.finished_at, r.message, s.name AS source
         FROM crawl_runs r LEFT JOIN sources s ON s.id = r.source_id
        ORDER BY r.started_at DESC LIMIT 20`).all(),
    env.DB.prepare('SELECT slug, name, adapter, license, enabled, last_run_at FROM sources ORDER BY id').all(),
  ]);
  return json({
    runs: runs.results,
    sources: sources.results,
    today: todayISO(),
    ai: {
      // 실제로 응답한 모델. 1순위가 사라지면 자동으로 다음 것으로 바뀐다.
      active: activeModel?.value || MODEL_CHAIN[0],
      confirmedAt: activeModel?.updated_at || null,
      chain: MODEL_CHAIN,
    },
  });
}

const isAdmin = (env, req) => {
  const k = (env.ADMIN_KEY || '').trim();
  return !!k && req.headers.get('X-Admin-Key') === k;
};

/* ---------- Router ---------- */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p = url.pathname;
    if (!p.startsWith('/api/')) return env.ASSETS.fetch(request);

    try {
      if (p === '/api/bootstrap') return getBootstrap(env);
      if (p === '/api/hospitals' && request.method === 'GET') return getHospitals(env, url);

      let m = p.match(/^\/api\/hospitals\/(\d+)$/);
      if (m && request.method === 'GET') return getHospital(env, Number(m[1]), url);

      m = p.match(/^\/api\/conditions\/([a-z0-9-]+)$/);
      if (m && request.method === 'GET') return getByCondition(env, m[1], url);

      if (p === '/api/ask' && request.method === 'POST') return handleAsk(request, env);
      if (p === '/api/reviews' && request.method === 'POST') return postReview(env, request);
      if (p === '/api/wait-reports' && request.method === 'POST') return postWaitReport(env, request);
      if (p === '/api/cost') return getCost(env, url);
      if (p === '/api/status') return getStatus(env);

      if (p === '/api/admin/ai-check' && request.method === 'POST') {
        if (!isAdmin(env, request)) return bad('관리자 키가 필요합니다', 401);
        return json(await checkModels(env));
      }

      if (p === '/api/admin/crawl' && request.method === 'POST') {
        if (!isAdmin(env, request)) return bad('관리자 키가 필요합니다', 401);
        return json(await runIngestion(env, { only: url.searchParams.get('source') }));
      }
      return bad('없는 경로입니다', 404);
    } catch (err) {
      return json({ error: '서버 오류', detail: String(err.message || err) }, 500);
    }
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(runIngestion(env).then(
      r => console.log('ingestion', event.cron, JSON.stringify(r)),
      // 오류 객체를 그대로 넘기면 메시지 없이 스택만 찍힌다. 풀어서 남긴다.
      e => console.error('ingestion failed', event.cron, String((e && e.message) || e), (e && e.stack) || '')));
  },
};
