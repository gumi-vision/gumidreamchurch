/* ============================================================
   Workers AI 모델 폴백

   모델 ID 를 코드에 하나만 박아두면 Cloudflare 가 그 모델을 내렸을 때
   기능이 통째로 멈춘다. 후보를 순서대로 두고 실패하면 다음으로 넘어가며,
   성공한 모델을 기억해 다음 요청부터 바로 그것을 쓴다.
   ============================================================ */

/**
 * 앞에 있을수록 우선. 앞이 죽으면 뒤로 자동 전환된다.
 * 2026-09-01 점검 기준으로 모두 한국어 응답이 확인된 모델만 넣었다.
 * (llama-3.1-8b 는 2026-05-30 폐기되어 제외 — 이런 일이 생겨서 이 체인이 필요하다.
 *  qwen3-30b·gpt-oss-20b 는 호출은 되지만 추론형이라 빈 응답이 잦아 제외.)
 */
export const MODEL_CHAIN = [
  '@cf/meta/llama-4-scout-17b-16e-instruct',
  '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
  '@cf/mistralai/mistral-small-3.1-24b-instruct',
];

const STATE_KEY = 'ai.active_model';

async function readActive(env) {
  try {
    const row = await env.DB.prepare('SELECT value FROM ai_state WHERE key = ?')
      .bind(STATE_KEY).first();
    return row?.value || null;
  } catch { return null; }
}

async function writeActive(env, model) {
  try {
    await env.DB.prepare(
      `INSERT INTO ai_state (key, value, updated_at) VALUES (?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
    ).bind(STATE_KEY, model).run();
  } catch { /* 기록 실패해도 응답 자체는 이미 만들어졌다 */ }
}

/** Workers AI 는 모델이 JSON 으로 답하면 문자열이 아닌 객체를 돌려주기도 한다. */
function toText(out) {
  if (typeof out === 'string') return out.trim();
  if (out == null) return '';
  return typeof out === 'object' ? JSON.stringify(out) : String(out).trim();
}

/**
 * 체인을 순서대로 시도한다.
 * 마지막에 성공한 모델을 앞으로 당겨, 죽은 모델을 매번 먼저 찔러보지 않는다.
 */
export async function chat(env, messages, { maxTokens = 700, temperature = 0.2 } = {}) {
  const active = await readActive(env);
  const order = active
    ? [active, ...MODEL_CHAIN.filter(m => m !== active)]
    : [...MODEL_CHAIN];

  const errors = [];
  for (const model of order) {
    try {
      const r = await env.AI.run(model, { messages, max_tokens: maxTokens, temperature });
      const text = toText(r && r.response);
      if (!text) throw new Error('빈 응답');
      if (model !== active) await writeActive(env, model);
      return { text, model };
    } catch (err) {
      errors.push(`${model}: ${String((err && err.message) || err)}`);
    }
  }
  throw new Error('사용 가능한 AI 모델이 없습니다 · ' + errors.join(' | '));
}

/** 어느 모델이 실제로 응답하는지 점검한다. 운영 확인용. */
export async function checkModels(env) {
  const probe = [{ role: 'user', content: '안녕' }];
  const results = [];
  for (const model of MODEL_CHAIN) {
    const started = Date.now();
    try {
      const r = await env.AI.run(model, { messages: probe, max_tokens: 16 });
      results.push({
        model, ok: true, ms: Date.now() - started,
        sample: toText(r && r.response).slice(0, 40),
      });
    } catch (err) {
      results.push({ model, ok: false, error: String((err && err.message) || err).slice(0, 120) });
    }
  }
  return { active: await readActive(env), results };
}
