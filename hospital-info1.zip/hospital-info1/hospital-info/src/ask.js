/* ============================================================
   자연어 질문 → 병원 안내

   설계 원칙
    - LLM 이 병원을 고르지 않는다. 고르는 건 DB(공식 평가 기준)다.
      LLM 은 (1) 질문에서 지역·증상을 뽑고 (2) DB 가 고른 결과를 설명만 한다.
      이렇게 해야 "어느 병원이 좋다"는 판단이 모델의 창작이 아니라
      공표 자료에서 나온다.
    - 진단·치료 판단은 하지 않는다. 응급 신호는 병원 추천보다 먼저 처리한다.
   ============================================================ */

import { chat as aiChat } from './ai.js';

/** 응급 상황은 추천을 멈추고 즉시 안내한다. */
const EMERGENCY_PATTERNS = [
  /의식.?(없|잃)/, /숨.?(안|못).?쉬/, /호흡곤란/, /심정지/, /경련/, /발작/,
  /말이.?어눌/, /한쪽.?(마비|힘)/, /갑자기.*(마비|말)/, /피를.?토/, /대량.?출혈/,
  /가슴.*(쥐어|짓누|극심)/, /자살/, /극단적.?선택/,
];

function detectEmergency(text) {
  return EMERGENCY_PATTERNS.some(re => re.test(text));
}

/** 받침 유무에 따라 "-로 / -으로" 를 고른다. (ㄹ 받침은 "-로") */
function josaRo(word) {
  const last = word.trim().slice(-1);
  const code = last.charCodeAt(0);
  if (code < 0xac00 || code > 0xd7a3) return '로';
  const jong = (code - 0xac00) % 28;
  return jong === 0 || jong === 8 ? '로' : '으로';
}

/** 폴백 체인을 통해 호출한다. 어느 모델이 답했는지는 마지막 응답에 담아 노출한다. */
let lastModelUsed = null;
async function chat(env, messages, maxTokens = 700) {
  const { text, model } = await aiChat(env, messages, { maxTokens });
  lastModelUsed = model;
  return text;
}

/** 1단계 — 질문에서 지역/증상을 우리 분류 안으로 끌어온다. */
async function extract(env, question, regions, conditions) {
  const conditionList = conditions
    .map(c => `${c.slug}: ${c.name} (${c.aka || ''})`).join('\n');
  const regionList = regions.map(r => `${r.slug}: ${r.name}`).join(', ');

  const raw = await chat(env, [
    {
      role: 'system',
      content:
`사용자의 한국어 질문에서 지역과 증상을 뽑아 JSON 만 출력한다. 설명 금지.

[지역 목록]
${regionList}

[증상 목록]
${conditionList}

규칙
- region 은 위 목록의 slug 중 하나. 시·군·구(예: 구미, 포항)가 나오면 그 상위 시·도의 slug 를 쓰고 districtName 에 시·군·구 이름을 넣는다.
- condition 은 위 목록의 slug 중 하나. 확실하지 않으면 null.
- 목록에 없는 증상이면 condition 은 null 로 두고 unmatchedSymptom 에 사용자의 표현을 넣는다.
- 출력 형식: {"region":slug|null,"districtName":문자열|null,"condition":slug|null,"unmatchedSymptom":문자열|null}`,
    },
    { role: 'user', content: question },
  ], 200);

  const m = raw.match(/\{[\s\S]*\}/);
  if (!m) return {};
  try { return JSON.parse(m[0]); } catch { return {}; }
}

/** 2단계 — DB 가 공식 기준으로 병원을 고른다. LLM 은 관여하지 않는다. */
async function pickHospitals(env, { condition, regionSlug, districtName }) {
  const cond = await env.DB.prepare(
    `SELECT c.id, c.slug, c.name, c.basis_note,
            s.id AS specialty_id, s.name AS specialty, s.slug AS specialty_slug
       FROM conditions c JOIN specialties s ON s.id = c.specialty_id
      WHERE c.slug = ?`).bind(condition).first();
  if (!cond) return null;

  // 목록 화면과 같은 기준으로 무관한 기관을 걸러낸다.
  const dental = cond.specialty_slug === 'dentistry';
  const relevance = dental
    ? `(h.cl_cd = '41' OR EXISTS (SELECT 1 FROM hospital_specialties hs
          WHERE hs.hospital_id = h.id AND hs.specialty_id = ${cond.specialty_id}))`
    : `(h.cl_cd <> '41' AND (
          NOT EXISTS (SELECT 1 FROM hospital_specialties hs WHERE hs.hospital_id = h.id)
          OR EXISTS (SELECT 1 FROM hospital_specialties hs
                      WHERE hs.hospital_id = h.id AND hs.specialty_id = ${cond.specialty_id})))`;

  const region = regionSlug
    ? await env.DB.prepare('SELECT id, name, slug FROM regions WHERE slug = ?').bind(regionSlug).first()
    : null;

  let district = null;
  if (region && districtName) {
    district = await env.DB.prepare(
      `SELECT id, name, sggu_cd FROM districts
        WHERE region_id = ? AND (name = ? OR name LIKE ?) LIMIT 1`
    ).bind(region.id, districtName, `%${districtName}%`).first();
  }

  const binds = [cond.specialty_id, cond.id];
  const where = [relevance];
  if (region) { where.push('h.region_id = ?'); binds.push(region.id); }
  if (district) { where.push('h.district_id = ?'); binds.push(district.id); }

  const run = async (conds, bindArgs) => (await env.DB.prepare(
    `SELECT h.id, h.name, h.cl_name, h.addr, h.tel, h.url, h.sdr_count,
            r.name AS region, d.name AS district,
            (SELECT hs.sdr_count FROM hospital_specialties hs
              WHERE hs.hospital_id = h.id AND hs.specialty_id = ?) AS dept_sdr,
            (SELECT MIN(e.grade) FROM evaluations e
              WHERE e.hospital_id = h.id AND e.condition_id = ? AND e.grade IS NOT NULL) AS best_grade
       FROM hospitals h
       LEFT JOIN regions r ON r.id = h.region_id
       LEFT JOIN districts d ON d.id = h.district_id
      ${conds.length ? 'WHERE ' + conds.join(' AND ') : ''}
      ORDER BY best_grade IS NULL, best_grade ASC, COALESCE(dept_sdr,0) DESC, h.sdr_count DESC
      LIMIT 5`).bind(...bindArgs).all()).results;

  let hospitals = await run(where, binds);
  let widened = null;

  // 시·군·구에 결과가 없으면 시·도로 넓힌다. (관련성 필터는 계속 유지)
  if (!hospitals.length && district) {
    hospitals = await run([relevance, 'h.region_id = ?'], [cond.specialty_id, cond.id, region.id]);
    widened = `${district.name}에는 해당 병원이 없어 ${region.name} 전체로 넓혔습니다`;
  }
  // 그래도 없으면 전국으로 넓히되 종합병원급 이상으로 제한한다.
  // 전국 전체를 상관 서브쿼리로 정렬하면 D1 이 감당하지 못한다.
  if (!hospitals.length) {
    hospitals = await run([relevance, "h.cl_cd IN ('01','11')"], [cond.specialty_id, cond.id]);
    widened = `${region ? region.name + '에' : '해당 지역에'} 결과가 없어 전국 종합병원급으로 넓혔습니다`;
  }

  return { cond, region, district, hospitals, widened };
}

/** 3단계 — 고른 결과만 근거로 설명한다. 새 병원을 만들어내지 못하게 막는다. */
async function explain(env, question, picked) {
  const { cond, region, district, hospitals, widened } = picked;
  const place = district ? `${region.name} ${district.name}` : (region ? region.name : '전국');

  const facts = hospitals.map((h, i) =>
    `${i + 1}. ${h.name} (${h.cl_name}, ${h.region} ${h.district || ''})` +
    (h.best_grade ? ` · ${cond.name} 적정성평가 ${h.best_grade}등급` : ' · 해당 질환 평가등급 없음') +
    (h.dept_sdr ? ` · ${cond.specialty} 전문의 ${h.dept_sdr}명` : ` · 전체 전문의 ${h.sdr_count}명`)
  ).join('\n');

  return chat(env, [
    {
      role: 'system',
      content:
`너는 공공데이터 기반 병원 안내 도우미다. 아래 [선정된 병원] 만 근거로 한국어로 답한다.

반드시 지킬 것
- [선정된 병원] 에 없는 병원 이름을 절대 만들지 마라.
- 진단하지 마라. 수술 필요 여부, 치료법 선택 같은 의학적 판단을 하지 마라.
- "가장 잘 본다", "명의", "완치" 같은 표현을 쓰지 마라. 대신 어떤 공식 근거가 있는지 말해라.
- 순서의 근거를 설명해라: ${cond.basis_note}
- 4~6문장으로 짧게. 목록을 그대로 나열하지 말고 왜 이 순서인지 설명해라.
- 마지막에 한 줄로 "진단과 치료 결정은 진료를 받아보신 뒤 의료진과 상의하세요" 취지의 안내를 넣어라.

[사용자가 찾는 것] ${place} / ${cond.name}
${widened ? `[범위 조정] ${widened}` : ''}
[선정된 병원]
${facts}`,
    },
    { role: 'user', content: question },
  ], 600);
}

/* ---------- 엔드포인트 ---------- */
export async function handleAsk(request, env) {
  try {
    return await ask(request, env);
  } catch (err) {
    // 라우터 밖으로 새어나가면 원인 없는 1101 만 남는다. 여기서 붙잡아 남긴다.
    console.error('ask failed', err && err.stack);
    return Response.json({
      error: '답변 생성에 실패했습니다',
      detail: String((err && err.message) || err),
    }, { status: 500 });
  }
}

async function ask(request, env) {
  let body;
  try { body = await request.json(); } catch { return Response.json({ error: 'JSON 형식이 아닙니다' }, { status: 400 }); }

  const question = String(body.question || '').trim().slice(0, 300);
  if (!question) return Response.json({ error: '질문을 입력해주세요' }, { status: 400 });

  if (detectEmergency(question)) {
    return Response.json({
      emergency: true,
      answer:
        '지금 설명하신 증상은 응급 상황일 수 있습니다. 병원을 비교하지 마시고 ' +
        '즉시 119에 신고하거나 가장 가까운 응급실로 가세요. ' +
        '뇌졸중·심근경색은 치료까지 걸린 시간이 결과를 좌우합니다.',
      hospitals: [],
    });
  }

  const [{ results: regions }, { results: conditions }] = await Promise.all([
    env.DB.prepare('SELECT slug, name FROM regions').all(),
    env.DB.prepare('SELECT slug, name, aka FROM conditions ORDER BY sort_order').all(),
  ]);

  const parsed = await extract(env, question, regions, conditions);

  if (!parsed.condition) {
    return Response.json({
      answer:
        (parsed.unmatchedSymptom
          ? `"${parsed.unmatchedSymptom}"에 해당하는 공식 평가 자료를 저희가 아직 가지고 있지 않습니다. `
          : '어떤 증상인지 확실하지 않습니다. ') +
        '이 서비스는 심평원이 등급을 공표한 질환만 안내할 수 있어요. ' +
        '아래 증상 목록에서 골라보시거나, 증상을 조금 더 구체적으로 알려주세요.',
      needCondition: true,
      conditions: conditions.map(c => ({ slug: c.slug, name: c.name })),
      hospitals: [],
    });
  }

  // 지역이 없으면 되묻는다. 병원 선택은 지역이 전제이고,
  // 전국을 통째로 정렬하면 결과도 덜 쓸모 있다.
  if (!parsed.region) {
    const cond = conditions.find(c => c.slug === parsed.condition);
    return Response.json({
      answer: `${cond ? cond.name + josaRo(cond.name) : ''} 병원을 찾으시는군요. ` +
        '어느 지역에서 다니실 수 있는지 알려주시면 그 지역 병원을 공식 평가 기준으로 골라드릴게요. ' +
        '(예: "구미", "부산 해운대구")',
      needRegion: true,
      regions: regions.map(r => r.name),
      condition: cond ? { slug: cond.slug, name: cond.name } : null,
      hospitals: [],
    }, { headers: { 'Cache-Control': 'no-store' } });
  }

  const picked = await pickHospitals(env, {
    condition: parsed.condition,
    regionSlug: parsed.region,
    districtName: parsed.districtName,
  });
  if (!picked || !picked.hospitals.length) {
    return Response.json({
      answer: '조건에 맞는 병원을 찾지 못했습니다. 지역을 넓혀서 다시 물어봐 주세요.',
      hospitals: [],
    });
  }

  const answer = await explain(env, question, picked);

  return Response.json({
    answer,
    condition: { slug: picked.cond.slug, name: picked.cond.name, basis: picked.cond.basis_note },
    place: picked.district
      ? { region: picked.region.name, district: picked.district.name }
      : (picked.region ? { region: picked.region.name } : null),
    widened: picked.widened,
    hospitals: picked.hospitals,
    model: lastModelUsed,
  }, { headers: { 'Cache-Control': 'no-store' } });
}
