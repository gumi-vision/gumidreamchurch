-- 크론 한 번에 doable 한 양으로 맞춘다.
-- 서브리퀘스트 한도 50 중 앞선 수집원이 22콜을 쓴다
-- (central 1 + local 10 + targets 11). 남는 28콜 안에서 상세를 받는다.
UPDATE sources SET config = json_set(config, '$.perRun', 25) WHERE slug = 'details';
