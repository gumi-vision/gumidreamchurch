-- ============================================================
--  혜택나침반 — 내가 받을 수 있는 정부 지원을 찾는다
--
--  원칙 (병원나침반과 같다): 우리가 판정하지 않는다.
--
--  복지 사업 대부분에 "기준 중위소득 OO% 이하" 같은 소득 요건이 붙는다.
--  이건 가구원 수·재산·건강보험료까지 봐야 하는 계산이고, 우리는 그 자료가 없다.
--  "받으실 수 있습니다"라고 단정하면 헛걸음을 시킨다.
--  우리가 하는 일은 "이 조건이면 해당할 수 있으니 확인해 보세요" 까지다.
--
--  그래서 모든 사업에 복지로 원문 링크와 수집 날짜를 함께 남긴다.
--  정보가 낡았을 때 이용자가 원문으로 확인할 수 있어야 한다.
-- ============================================================

-- 지역 --------------------------------------------------------
-- 지자체 사업은 시도·시군구 이름 문자열로 온다. 코드 체계가 없어
-- 이름을 그대로 쓰되, 조회를 위해 목록으로 만들어 둔다.
CREATE TABLE regions (
  id      INTEGER PRIMARY KEY,
  ctpv    TEXT NOT NULL,              -- 시도명 (강원특별자치도)
  sgg     TEXT,                       -- 시군구명. NULL 이면 시도 단위 사업
  n       INTEGER NOT NULL DEFAULT 0, -- 이 지역 사업 수
  UNIQUE (ctpv, sgg)
);
CREATE INDEX idx_regions_ctpv ON regions(ctpv);

-- 사업 --------------------------------------------------------
CREATE TABLE benefits (
  id           INTEGER PRIMARY KEY,
  serv_id      TEXT NOT NULL UNIQUE,  -- WLF00005312
  source       TEXT NOT NULL,         -- central / local
  name         TEXT NOT NULL,
  summary      TEXT,

  -- 어디서 하는 사업인가
  dept         TEXT,                  -- 소관 부처 또는 담당 부서
  ctpv         TEXT,                  -- 지자체 사업이면 시도
  sgg          TEXT,                  -- 지자체 사업이면 시군구

  -- 조건. API 가 이름 문자열로 준다(쉼표 구분).
  life_stages  TEXT,                  -- 영유아,아동,청소년,청년,중장년,노년
  themes       TEXT,                  -- 신체건강,생활지원,주거,일자리,서민금융 …

  -- 지원 형태
  provide_type TEXT,                  -- 현금지급 / 현물지급 / 감면 / 서비스
  cycle        TEXT,                  -- 월 / 년 / 수시
  online_apply TEXT,                  -- 온라인 신청 가능 여부 (중앙부처만)
  tel          TEXT,

  detail_url   TEXT NOT NULL,         -- 복지로 원문. 항상 함께 보여준다
  views        INTEGER,               -- 복지로 조회수. 사람들이 많이 본 순서
  last_mod     TEXT,                  -- 원문 최종 수정일
  fetched_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_benefits_region ON benefits(ctpv, sgg);
CREATE INDEX idx_benefits_source ON benefits(source);

-- 대상특성 태그 -----------------------------------------------
-- 가구상황(한부모·장애인 등)은 API 응답에 안 담기고 필터로만 걸린다.
-- 그래서 코드별로 따로 조회해서 어떤 사업이 걸리는지 표시해 둔다.
--
-- 코드는 문서가 아니라 실제 응답으로 확인했다.
--   010 다문화·탈북민 (북한이탈 10건, 다문화 6건)
--   020 다자녀        030 보훈대상자 (보훈 11, 유공 9)
--   040 장애인 (장애 62건)  050 저소득  060 한부모·조손 (한부모 6건)
CREATE TABLE benefit_targets (
  serv_id  TEXT NOT NULL,
  code     TEXT NOT NULL,
  PRIMARY KEY (serv_id, code)
);
CREATE INDEX idx_targets_code ON benefit_targets(code, serv_id);

-- 수집원 ------------------------------------------------------
CREATE TABLE sources (
  id         INTEGER PRIMARY KEY,
  slug       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  base_url   TEXT NOT NULL,
  license    TEXT NOT NULL,
  enabled    INTEGER NOT NULL DEFAULT 1,
  config     TEXT,
  last_run_at TEXT,
  last_note  TEXT
);

CREATE TABLE settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
