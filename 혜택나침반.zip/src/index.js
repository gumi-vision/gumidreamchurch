import { runIngestion, TARGET_CODES } from './crawler.js';

const json = (d, status = 200) =>
  Response.json(d, { status, headers: { 'Cache-Control': 'no-store' } });
const bad = (m, status = 400) => json({ error: m }, status);

const isAdmin = (env, req) => {
  const k = (env.ADMIN_KEY || '').trim();
  return !!k && req.headers.get('X-Admin-Key') === k;
};

/*
 * 나이 → 생애주기.
 *
 * 복지로가 쓰는 구간에 맞춘다. 경계는 사업마다 조금씩 다르지만
 * (아동수당은 8세 미만, 청년은 34세까지 등) 목록을 좁히는 용도라
 * 넓게 잡아 걸치는 구간은 둘 다 넣는다. 좁게 잡아 놓치는 것보다 낫다.
 */
function lifeStagesFor(age) {
  if (age == null || age === '') return [];
  const a = Number(age);
  if (!Number.isFinite(a) || a < 0) return [];
  const out = [];
  if (a <= 7) out.push('영유아');
  if (a >= 6 && a <= 13) out.push('아동');
  if (a >= 12 && a <= 19) out.push('청소년');
  if (a >= 18 && a <= 39) out.push('청년');
  if (a >= 35 && a <= 69) out.push('중장년');
  if (a >= 60) out.push('노년');
  return out;
}

async function getBootstrap(env) {
  const [regions, themes, fresh] = await Promise.all([
    env.DB.prepare(
      `SELECT ctpv, json_group_array(json_object('sgg', sgg, 'n', n)) AS sggs
         FROM regions GROUP BY ctpv ORDER BY ctpv`).all(),
    env.DB.prepare('SELECT themes FROM benefits WHERE themes IS NOT NULL').all(),
    env.DB.prepare(
      `SELECT (SELECT COUNT(*) FROM benefits) AS total,
              (SELECT COUNT(*) FROM benefits WHERE source='central') AS central,
              (SELECT COUNT(*) FROM benefits WHERE source='local') AS local,
              (SELECT MAX(fetched_at) FROM benefits) AS fetched_at`).first(),
  ]);

  // 관심주제는 쉼표로 묶여 오므로 펼쳐서 목록을 만든다.
  const set = new Map();
  for (const r of themes.results) {
    for (const t of String(r.themes).split(',').map(s => s.trim()).filter(Boolean)) {
      set.set(t, (set.get(t) || 0) + 1);
    }
  }

  return json({
    regions: regions.results.map(r => ({ ctpv: r.ctpv, sggs: JSON.parse(r.sggs || '[]') })),
    themes: [...set].sort((a, b) => b[1] - a[1]).map(([name, n]) => ({ name, n })),
    targets: TARGET_CODES.map(([code, label]) => ({ code, label })),
    freshness: fresh,
  });
}

/**
 * 조건에 맞는 사업 찾기.
 *
 * 우리는 "받을 수 있다"고 판정하지 않는다. 대부분의 사업에 소득 요건이
 * 붙는데 그 자료가 우리에게 없다. 조건이 맞는 목록을 좁혀 보여주고,
 * 판단은 원문과 신청처로 넘긴다.
 */
async function search(env, url) {
  const ctpv = url.searchParams.get('ctpv') || '';
  const sgg = url.searchParams.get('sgg') || '';
  const age = url.searchParams.get('age');
  const themes = (url.searchParams.get('themes') || '').split(',').map(s => s.trim()).filter(Boolean);
  const targets = (url.searchParams.get('targets') || '').split(',').map(s => s.trim()).filter(Boolean);
  const limit = Math.min(Number(url.searchParams.get('limit')) || 60, 200);

  const stages = lifeStagesFor(age);
  const where = [];
  const binds = [];

  // 지역: 중앙부처 사업은 전국 공통이라 항상 포함한다.
  // 지자체 사업은 내 시도(그리고 시군구)만.
  if (ctpv) {
    where.push(`(b.source = 'central' OR (b.ctpv = ?${sgg ? ' AND (b.sgg = ? OR b.sgg IS NULL)' : ''}))`);
    binds.push(ctpv);
    if (sgg) binds.push(sgg);
  }

  // 생애주기: 하나라도 겹치면 포함. 생애주기가 안 적힌 사업은 전 연령 대상으로 본다.
  if (stages.length) {
    where.push(`(b.life_stages IS NULL OR b.life_stages = '' OR ${
      stages.map(() => 'b.life_stages LIKE ?').join(' OR ')})`);
    stages.forEach(s => binds.push(`%${s}%`));
  }

  if (themes.length) {
    where.push(`(${themes.map(() => 'b.themes LIKE ?').join(' OR ')})`);
    themes.forEach(t => binds.push(`%${t}%`));
  }

  // 가구상황은 태그 테이블로 건다. 고른 것 중 하나라도 걸리면 포함.
  if (targets.length) {
    where.push(`EXISTS (SELECT 1 FROM benefit_targets t
                         WHERE t.serv_id = b.serv_id
                           AND t.code IN (${targets.map(() => '?').join(',')}))`);
    binds.push(...targets);
  }

  binds.push(limit);
  const { results } = await env.DB.prepare(
    `SELECT b.*,
            (SELECT GROUP_CONCAT(t.code) FROM benefit_targets t WHERE t.serv_id = b.serv_id) AS target_codes
       FROM benefits b
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      -- 복지로 조회수가 높은 것이 대체로 더 많은 사람에게 해당한다.
      -- 우리가 매긴 점수가 아니라 원문 사이트의 조회수 그대로다.
      ORDER BY b.source = 'local' DESC, COALESCE(b.views, 0) DESC
      LIMIT ?`).bind(...binds).all();

  const labelOf = Object.fromEntries(TARGET_CODES);
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');

  const enriched = results
    // 시행이 끝난 지자체 사업은 뺀다. 끝난 걸 "해당할 수 있다"고 띄우면
    // 헛걸음을 시킨다. 종료일을 아직 못 받은 사업은 그대로 둔다.
    .filter(b => !b.end_ymd || b.end_ymd >= today)
    .map(b => ({
      ...b,
      targetLabels: (b.target_codes || '').split(',').filter(Boolean).map(c => labelOf[c]).filter(Boolean),
      incomeTest: hasIncomeTest(b),
      // 금액은 상세의 지원내용에서 찾는다. 목록 요약에는 금액이 없다.
      amount: amountOf(b),
      hasDetail: !!b.detail_at,
    }));

  // 소득 조건이 안 걸린 것을 앞으로 뺀다. 60건을 뭉뚱그려 주면
  // 뭘 봐야 할지 알 수 없다. "나이·지역만 맞으면 되는 것"이 먼저다.
  const open = enriched.filter(b => !b.incomeTest);
  const conditional = enriched.filter(b => b.incomeTest);

  return json({
    count: enriched.length,
    stages,
    openCount: open.length,
    benefits: [...open, ...conditional],
    caveat: '요약문에 소득·재산 조건이 적혀 있는지로 나눈 것입니다. 요약에 없어도 실제 신청 단계에서 조건이 붙을 수 있으니, 신청 전 원문을 꼭 확인하세요.',
  });
}

/*
 * 소득 조건이 붙는 사업인지 가려낸다.
 *
 * 우리가 수급 자격을 판정하는 게 아니다. 사업 설명에 소득·재산 요건이
 * 적혀 있는지만 본다. 그것만으로도 "나이·지역만 맞으면 되는 것"과
 * "소득을 따져봐야 하는 것"이 갈리고, 목록이 훨씬 읽을 만해진다.
 *
 * 요약에 안 적혀 있어도 실제로는 조건이 있을 수 있다.
 * 그래서 화면에 "요약문 기준"이라고 밝힌다.
 */
const INCOME_WORDS = /기준\s*중위소득|소득인정액|수급자|수급권자|저소득|차상위|기초생활|소득\s*기준|재산\s*기준|소득\s*수준|생계급여|의료급여|주거급여|교육급여/;
function hasIncomeTest(b) {
  return INCOME_WORDS.test(`${b.name || ''} ${b.summary || ''}`);
}

/*
 * 지원 금액을 뽑아낸다. 사람들이 가장 먼저 보고 싶어 하는 숫자다.
 * 요약문에 적힌 것을 그대로 인용할 뿐, 계산하거나 추정하지 않는다.
 * 못 찾으면 아무것도 보여주지 않는다. 지어내지 않는다.
 */
function amountOf(b) {
  // 상세의 지원내용에 실제 금액이 있다. 요약문에는 거의 없다.
  const t = `${b.content || ''} ${b.summary || ''}`;
  const m = t.match(/(월|연간|연|매월|최대|1인당|가구당)?\s*([0-9][0-9,]{0,9})\s*(만\s*원|만원|원)/);
  if (!m) return null;
  const num = m[2].replace(/,/g, '');
  if (!num || Number(num) === 0) return null;
  const unit = m[3].replace(/\s/g, '');
  const prefix = m[1] ? m[1].replace('간', '') : '';
  return `${prefix ? prefix + ' ' : ''}${Number(num).toLocaleString('ko-KR')}${unit}`;
}

async function getStatus(env) {
  const [srcs, fresh] = await Promise.all([
    env.DB.prepare('SELECT slug, name, license, last_run_at, last_note FROM sources ORDER BY id').all(),
    env.DB.prepare(
      `SELECT (SELECT COUNT(*) FROM benefits) AS benefits,
              (SELECT COUNT(*) FROM benefit_targets) AS tags,
              (SELECT COUNT(*) FROM regions) AS regions,
              (SELECT MAX(fetched_at) FROM benefits) AS fetched_at`).first(),
  ]);
  return json({ sources: srcs.results, freshness: fresh });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p = url.pathname;
    if (!p.startsWith('/api/')) return env.ASSETS.fetch(request);

    try {
      if (p === '/api/bootstrap') return getBootstrap(env);
      if (p === '/api/search') return search(env, url);
      if (p === '/api/status') return getStatus(env);

      if (p === '/api/admin/crawl' && request.method === 'POST') {
        if (!isAdmin(env, request)) return bad('관리 키가 필요합니다', 401);
        return json(await runIngestion(env, { only: url.searchParams.get('source') }));
      }
      return bad('없는 경로입니다', 404);
    } catch (err) {
      return json({ error: '서버 오류', detail: String(err.message || err) }, 500);
    }
  },

  async scheduled(event, env, ctx) {
    // 목록 수집과 대상특성 태깅을 한 번에 돌린다.
    // 목록 11콜 + 태깅 11콜 = 22콜로, 무료 플랜 서브리퀘스트 한도(50) 안쪽이다.
    // 태깅은 하루에 코드 하나씩만 돌아 6일이면 한 바퀴다.
    ctx.waitUntil(runIngestion(env).then(
      r => console.log('ingestion', event.cron, JSON.stringify(r)),
      e => console.error('ingestion failed', e)));
  },
};
