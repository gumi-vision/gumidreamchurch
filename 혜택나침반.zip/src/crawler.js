/* ============================================================
   수집 — 한국사회보장정보원 복지서비스

   하루 100회 한도가 있다. 그래서 조회할 때마다 API 를 부르지 않고,
   매일 한 번 전량을 받아 D1 에 담아두고 조회는 전부 우리 DB 에서 한다.
   500건씩 받으면 중앙부처 1회, 지자체 10회면 끝난다.

   응답은 XML 전용이다. _type=json 이 통하지 않는다.
   ============================================================ */

const UA = '혜택나침반-bot/1.0';

const XML_ENT = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&apos;': "'" };
const unesc = (s) => s.replace(/&(amp|lt|gt|quot|apos);/g, m => XML_ENT[m]);

function parseXml(text) {
  const pick = (tag) => text.match(new RegExp(`<${tag}>([^<]*)</${tag}>`))?.[1];
  const items = [...text.matchAll(/<servList>([\s\S]*?)<\/servList>/g)].map(block => {
    const o = {};
    for (const f of block[1].matchAll(/<([A-Za-z0-9_]+)>([\s\S]*?)<\/\1>/g)) o[f[1]] = unesc(f[2]);
    return o;
  });
  return {
    raw: text,
    totalCount: Number(pick('totalCount') || 0),
    resultCode: pick('resultCode'),
    resultMessage: pick('resultMessage'),
    items,
  };
}

/*
 * 이 API 는 가끔 이유 없이 99 UNKNOWN_ERROR 를 돌려준다.
 * 같은 요청을 다시 보내면 대개 성공한다(10페이지 연속 호출은 전부 성공했다).
 * 한 페이지 실패로 수집 전체를 버리면 그날 자료가 통째로 빈다. 재시도한다.
 */
async function call(endpoint, params, env, tries = 3) {
  const key = (env.SERVICE_KEY || '').trim();
  if (!key) throw new Error('SERVICE_KEY 시크릿이 없습니다');

  const url = new URL(endpoint);
  url.searchParams.set('serviceKey', key);
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }

  let last;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, { headers: { 'User-Agent': UA } });
      const text = await res.text();
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const x = parseXml(text);
      if (x.resultCode && x.resultCode !== '0') {
        throw new Error(`${x.resultCode} ${x.resultMessage || ''}`.trim());
      }
      return x;
    } catch (err) {
      last = err;
      // 서비스키 문제나 잘못된 파라미터는 다시 보내도 같으므로 바로 포기한다.
      if (/SERVICE_KEY|INVALID_REQUEST|HTTP 4/.test(String(err.message))) throw err;
    }
  }
  throw last;
}

/** 시도·시군구 목록을 응답에서 만들어 둔다. 코드 체계를 하드코딩하지 않는다. */
async function ensureRegions(db, rows) {
  const seen = new Map();
  for (const r of rows) {
    if (!r.ctpvNm) continue;
    seen.set(`${r.ctpvNm}|${r.sggNm || ''}`, [r.ctpvNm, r.sggNm || null]);
  }
  if (!seen.size) return;
  const stmt = db.prepare(
    'INSERT INTO regions (ctpv, sgg) VALUES (?,?) ON CONFLICT(ctpv, sgg) DO NOTHING');
  const batch = [...seen.values()].map(([c, s]) => stmt.bind(c, s));
  for (let i = 0; i < batch.length; i += 100) await db.batch(batch.slice(i, i + 100));
}

const upsert = (db) => db.prepare(
  `INSERT INTO benefits
     (serv_id, source, name, summary, dept, ctpv, sgg, life_stages, themes,
      provide_type, cycle, online_apply, tel, detail_url, views, last_mod, fetched_at)
   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, datetime('now'))
   ON CONFLICT(serv_id) DO UPDATE SET
     name=excluded.name, summary=excluded.summary, dept=excluded.dept,
     ctpv=excluded.ctpv, sgg=excluded.sgg, life_stages=excluded.life_stages,
     themes=excluded.themes, provide_type=excluded.provide_type, cycle=excluded.cycle,
     online_apply=excluded.online_apply, tel=excluded.tel, detail_url=excluded.detail_url,
     views=excluded.views, last_mod=excluded.last_mod, fetched_at=datetime('now')`);

function bindRow(stmt, r, source) {
  return stmt.bind(
    r.servId, source, r.servNm, r.servDgst || null,
    r.jurMnofNm || r.bizChrDeptNm || null,
    r.ctpvNm || null, r.sggNm || null,
    // 중앙부처는 lifeArray/intrsThemaArray, 지자체는 lifeNmArray/intrsThemaNmArray 로 온다.
    r.lifeNmArray || r.lifeArray || null,
    r.intrsThemaNmArray || r.intrsThemaArray || null,
    r.srvPvsnNm || null, r.sprtCycNm || null,
    r.onapPsbltYn || null, r.rprsCtadr || null,
    r.servDtlLink || '', r.inqNum ? Number(r.inqNum) : null,
    r.lastModYmd || r.svcfrstRegTs || null,
  );
}

/** 전량 수집. 페이지를 끝까지 돈다. */
async function fetchAll({ db, env, source, extra = {} }) {
  const cfg = JSON.parse(source.config || '{}');
  const numOfRows = cfg.numOfRows || 500;
  const base = { callTp: 'L', numOfRows, ...extra };
  if (cfg.srchKeyCode) base.srchKeyCode = cfg.srchKeyCode;

  const first = await call(source.base_url, { ...base, pageNo: 1 }, env);
  let rows = first.items;
  const pages = Math.ceil(first.totalCount / numOfRows);
  for (let p = 2; p <= pages; p++) {
    rows = rows.concat((await call(source.base_url, { ...base, pageNo: p }, env)).items);
  }
  return { rows, total: first.totalCount };
}

async function crawlList({ db, env, source }) {
  const kind = source.slug;                      // central / local
  const { rows, total } = await fetchAll({ db, env, source });

  if (kind === 'local') await ensureRegions(db, rows);

  const stmt = upsert(db);
  const batch = rows.filter(r => r.servId && r.servNm).map(r => bindRow(stmt, r, kind));
  for (let i = 0; i < batch.length; i += 100) await db.batch(batch.slice(i, i + 100));

  // 지역별 사업 수를 갱신해 둔다. 화면에서 "우리 동네 N건"을 보여주기 위해서다.
  if (kind === 'local') {
    await db.prepare(
      `UPDATE regions SET n = (SELECT COUNT(*) FROM benefits b
                                WHERE b.ctpv = regions.ctpv
                                  AND (b.sgg = regions.sgg OR (b.sgg IS NULL AND regions.sgg IS NULL)))`
    ).run();
  }
  return { inserted: batch.length, note: `총 ${total}건` };
}

/**
 * 대상특성 태깅.
 *
 * 가구상황(한부모·장애인 등)은 응답에 안 담기고 필터로만 걸린다.
 * 코드별로 따로 조회해야 하는데, 코드가 6개고 지자체는 10페이지라
 * 한 번에 다 돌면 하루 한도를 넘는다. 하루에 한 코드씩 돌아가며 채운다.
 * 6일이면 한 바퀴고, 그 뒤로는 계속 갱신된다.
 */
const TARGET_CODES = [
  ['010', '다문화·탈북민'], ['020', '다자녀'], ['030', '보훈대상자'],
  ['040', '장애인'], ['050', '저소득'], ['060', '한부모·조손'],
];

async function crawlTargets({ db, env, source }) {
  const cfg = JSON.parse(source.config || '{}');
  const cursor = Number(cfg.cursor || 0) % TARGET_CODES.length;
  const [code, label] = TARGET_CODES[cursor];

  const { results: srcs } = await db.prepare(
    "SELECT * FROM sources WHERE slug IN ('central','local')").all();

  let n = 0;
  for (const s of srcs) {
    const { rows } = await fetchAll({ db, env, source: s, extra: { trgterIndvdlArray: code } });
    const stmt = db.prepare(
      'INSERT INTO benefit_targets (serv_id, code) VALUES (?,?) ON CONFLICT DO NOTHING');
    const batch = rows.filter(r => r.servId).map(r => stmt.bind(r.servId, code));
    for (let i = 0; i < batch.length; i += 100) await db.batch(batch.slice(i, i + 100));
    n += batch.length;
  }

  await db.prepare('UPDATE sources SET config = ? WHERE id = ?')
    .bind(JSON.stringify({ ...cfg, cursor: cursor + 1 }), source.id).run();
  return { inserted: n, note: `${label} ${n}건` };
}

/**
 * 상세 정보 수집.
 *
 * 목록 요약에는 금액이 없다. 상세에는 금액·선정기준·신청방법이 다 있고,
 * 그게 이용자가 실제로 알고 싶은 것이다.
 *
 * 사업 하나당 호출 한 번이라 5,219건을 한 번에 못 받는다.
 * 복지로 조회수가 높은 것부터 채운다. 많이 보는 사업이 먼저 채워지므로
 * 전부 못 채워도 체감 효과는 금방 난다.
 */
const LOCAL_DETAIL = 'https://apis.data.go.kr/B554287/LocalGovernmentWelfareInformations/LcgvWelfaredetailed';

async function crawlDetails({ db, env, source }) {
  const cfg = JSON.parse(source.config || '{}');
  const perRun = cfg.perRun || 60;

  const { results: todo } = await db.prepare(
    `SELECT serv_id, source FROM benefits
      WHERE detail_at IS NULL
      ORDER BY COALESCE(views, 0) DESC
      LIMIT ?`).bind(perRun).all();

  if (!todo.length) {
    // 다 채웠으면 오래된 것부터 다시 훑어 갱신한다. 금액은 해마다 바뀐다.
    const { results: old } = await db.prepare(
      'SELECT serv_id, source FROM benefits ORDER BY detail_at LIMIT ?').bind(perRun).all();
    todo.push(...old);
  }

  const stmt = db.prepare(
    `UPDATE benefits SET target_detail=?, criteria=?, content=?, apply_how=?,
            crtr_year=?, end_ymd=?, detail_at=datetime('now') WHERE serv_id=?`);

  let ok = 0;
  const rows = [];
  for (const t of todo) {
    let x;
    try {
      // 중앙부처와 지자체는 상세 엔드포인트가 다르다.
      const ep = t.source === 'local' ? LOCAL_DETAIL : source.base_url;
      x = await call(ep, { callTp: 'D', servId: t.serv_id }, env, 2);
    } catch { continue; }          // 한 건 실패가 전체를 막으면 안 된다

    // 상세 응답은 servList 로 안 감싸여 오므로 본문에서 직접 뽑는다.
    const get = (tag) => x.raw?.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`))?.[1] || null;
    const clean = (s) => (s ? unesc(s).replace(/&#13;/g, '\n').trim().slice(0, 1200) : null);

    // 중앙부처와 지자체는 같은 정보를 다른 이름으로 준다.
    //   지원대상  중앙 tgtrDtlCn        / 지자체 sprtTrgtCn
    //   신청방법  중앙 servSeDetailLink / 지자체 aplyMtdCn
    //   기준연도  중앙 crtrYr           / 지자체는 시행기간(enfcBgngYmd~enfcEndYmd)
    const applies = [...(x.raw || '').matchAll(/<servSeDetailLink>([\s\S]*?)<\/servSeDetailLink>/g)]
      .map(m => unesc(m[1]).trim()).filter(Boolean);
    const applyHow = applies.length ? applies.join('\n') : clean(get('aplyMtdCn'));

    // 지자체 사업에는 시행 종료일이 있다. 이미 끝난 사업을 "받을 수 있다"고
    // 띄우면 헛걸음을 시키므로, 받아 두었다가 화면에서 걸러낸다.
    const endYmd = get('enfcEndYmd');

    rows.push(stmt.bind(
      clean(get('tgtrDtlCn')) || clean(get('sprtTrgtCn')),
      clean(get('slctCritCn')),
      clean(get('alwServCn')),
      applyHow ? applyHow.slice(0, 800) : null,
      get('crtrYr'), endYmd, t.serv_id));
    ok++;
  }
  for (let i = 0; i < rows.length; i += 100) await db.batch(rows.slice(i, i + 100));

  const left = await db.prepare(
    'SELECT COUNT(*) AS n FROM benefits WHERE detail_at IS NULL').first();
  return { inserted: ok, note: `${ok}건 채움 · 남은 ${left?.n ?? '?'}건` };
}

const ADAPTERS = { central: crawlList, local: crawlList, targets: crawlTargets, details: crawlDetails };

export async function runIngestion(env, { only = null } = {}) {
  const db = env.DB;
  let q = 'SELECT * FROM sources WHERE enabled = 1';
  const binds = [];
  if (only) {
    const list = Array.isArray(only) ? only : [only];
    q += ` AND slug IN (${list.map(() => '?').join(',')})`;
    binds.push(...list);
  }
  const { results } = await db.prepare(q).bind(...binds).all();

  const report = [];
  for (const source of results) {
    try {
      const { inserted, note } = await ADAPTERS[source.slug]({ db, env, source });
      await db.prepare("UPDATE sources SET last_run_at=datetime('now'), last_note=? WHERE id=?")
        .bind(note || null, source.id).run();
      report.push({ source: source.slug, status: 'ok', inserted, note });
    } catch (err) {
      const msg = String(err.message || err);
      await db.prepare("UPDATE sources SET last_run_at=datetime('now'), last_note=? WHERE id=?")
        .bind(`오류: ${msg}`, source.id).run();
      report.push({ source: source.slug, status: 'error', message: msg });
    }
  }
  return { report };
}

export { TARGET_CODES };
