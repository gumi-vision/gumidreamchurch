/* ============================================================
   혜택나침반 · 프론트엔드

   두 가지를 지킨다.
     ① 우리는 "받을 수 있다"고 판정하지 않는다.
     ② 그렇다고 뭉뚱그려 던지지도 않는다.
        소득 조건이 붙는 것과 안 붙는 것을 갈라주면
        판정하지 않고도 "뭘 먼저 볼지"는 분명해진다.
   ============================================================ */

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const n = (v) => Number(v || 0).toLocaleString('ko-KR');

// 저장소 접근은 감싼다. 막힌 환경에서 읽기만 해도 예외가 나고,
// 그러면 스크립트 전체가 죽어 아무 버튼도 동작하지 않는다.
let mem = {};
const store = {
  get(k) { try { return localStorage.getItem(k) ?? mem[k] ?? ''; } catch { return mem[k] ?? ''; } },
  set(k, v) { mem[k] = v; try { localStorage.setItem(k, v); } catch {} },
};

let BOOT = null;
const picked = { themes: new Set(), targets: new Set() };

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast'; el.textContent = msg;
  $('#toast').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

async function api(path) {
  const res = await fetch(path);
  const d = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(d.error || `요청 실패 (${res.status})`);
  return d;
}

/* ---------- 문장형 입력 ----------
   라벨 붙은 칸을 나열하면 민원 서류처럼 보인다.
   읽히는 문장 안에 넣으면 같은 정보를 받으면서도 말을 거는 느낌이 된다. */
function sentenceHtml() {
  const ctpv = store.get('bc.ctpv');
  const sgg = store.get('bc.sgg');
  const age = store.get('bc.age');
  const region = BOOT.regions.find(r => r.ctpv === ctpv);
  const sggs = (region?.sggs || []).filter(s => s.sgg);

  const sel = (id, val, opts, placeholder) => `
    <select class="inl ${val ? '' : 'empty'}" id="${id}">
      <option value="">${esc(placeholder)}</option>
      ${opts.map(o => `<option value="${esc(o.v)}"${o.v === val ? ' selected' : ''}>${esc(o.t)}</option>`).join('')}
    </select>`;

  return `
    <div class="sentence">
      <div class="line">저는
        ${sel('fCtpv', ctpv, BOOT.regions.map(r => ({ v: r.ctpv, t: r.ctpv })), '어디')}
        ${sggs.length ? sel('fSgg', sgg, sggs.map(s => ({ v: s.sgg, t: s.sgg })), '전체') : ''}
        에 살고,
      </div>
      <div class="line">
        <input class="inl ${age ? '' : 'empty'}" id="fAge" type="number" inputmode="numeric"
               value="${esc(age)}" placeholder="00" maxlength="3"> 살입니다.
      </div>

      <div class="opt">
        <h3>해당되는 상황이 있나요? <span>없으면 넘어가세요</span></h3>
        <div class="chips" id="fTargets">
          ${BOOT.targets.map(t => `<button class="chip" data-t="${esc(t.code)}">${esc(t.label)}</button>`).join('')}
        </div>
      </div>

      <div class="opt">
        <h3>관심 분야 <span>안 고르면 전체</span></h3>
        <div class="chips" id="fThemes">
          ${BOOT.themes.slice(0, 12).map(t => `<button class="chip" data-h="${esc(t.name)}">${esc(t.name)}</button>`).join('')}
        </div>
      </div>

      <button class="go" id="go">${n(BOOT.freshness?.total)}개 사업에서 찾아보기</button>
    </div>`;
}

function bindForm() {
  const mark = (el) => el.classList.toggle('empty', !el.value);
  const wire = (id, key, rerender) => {
    const el = $(id); if (!el) return;
    el.addEventListener('change', () => {
      store.set(key, el.value); mark(el);
      if (rerender) { store.set('bc.sgg', ''); render(); }
    });
    el.addEventListener('input', () => mark(el));
  };
  wire('#fCtpv', 'bc.ctpv', true);
  wire('#fSgg', 'bc.sgg');
  wire('#fAge', 'bc.age');

  const toggle = (sel, attr, set) => document.querySelectorAll(sel + ' .chip').forEach(b => {
    const v = b.dataset[attr];
    if (set.has(v)) b.classList.add('on');
    b.addEventListener('click', () => {
      set.has(v) ? set.delete(v) : set.add(v);
      b.classList.toggle('on');
    });
  });
  toggle('#fTargets', 't', picked.targets);
  toggle('#fThemes', 'h', picked.themes);

  $('#go')?.addEventListener('click', search);
}

/* ---------- 결과 ---------- */
/*
 * 카드.
 *
 * 복지로에서는 목록에서 한 번 더 눌러야 금액·선정기준·신청처가 보인다.
 * 우리는 그걸 카드에 바로 펼친다. 그게 이 서비스가 더 나은 지점이다.
 * 아직 상세를 못 받은 사업은 요약만 보여주고 원문으로 넘긴다.
 */
const cut = (s, n) => {
  const v = String(s || '').replace(/\s*\n\s*/g, ' ').trim();
  return v.length > n ? v.slice(0, n) + '…' : v;
};

const cardHtml = (b, i) => `
  <a class="card" href="${esc(b.detail_url)}" target="_blank" rel="noopener noreferrer"
     style="animation-delay:${Math.min(i, 12) * 26}ms">
    <span class="arrow">→</span>
    <div class="nm">${esc(b.name)}</div>

    ${b.amount ? `<div class="amount">${esc(b.amount)}</div>` : ''}

    <div class="dg">${esc(cut(b.content || b.summary, 150))}</div>

    ${b.criteria ? `<div class="row"><span class="k">받는 조건</span>
       <span class="v">${esc(cut(b.criteria, 110))}</span></div>` : ''}
    ${b.apply_how ? `<div class="row"><span class="k">신청</span>
       <span class="v">${esc(cut(b.apply_how, 90))}</span></div>` : ''}

    <div class="meta">
      <span class="tag place">${b.source === 'local'
        ? esc([b.ctpv, b.sgg].filter(Boolean).join(' ')) || '지자체'
        : esc(b.dept || '중앙부처')}</span>
      ${b.provide_type ? `<span class="tag">${esc(b.provide_type)}</span>` : ''}
      ${b.crtr_year ? `<span class="tag">${esc(b.crtr_year)}년 기준</span>` : ''}
      ${(b.targetLabels || []).map(t => `<span class="tag target">${esc(t)}</span>`).join('')}
      ${b.hasDetail ? '' : '<span class="tag pending">상세 준비 중</span>'}
    </div>
  </a>`;

async function search() {
  const q = new URLSearchParams();
  const ctpv = store.get('bc.ctpv'), sgg = store.get('bc.sgg'), age = store.get('bc.age');
  if (ctpv) q.set('ctpv', ctpv);
  if (sgg) q.set('sgg', sgg);
  if (age) q.set('age', age);
  if (picked.themes.size) q.set('themes', [...picked.themes].join(','));
  if (picked.targets.size) q.set('targets', [...picked.targets].join(','));
  q.set('limit', '60');

  const out = $('#results');
  out.innerHTML = '<div class="loading">찾는 중…</div>';

  let d;
  try { d = await api('/api/search?' + q); }
  catch (err) { out.innerHTML = `<div class="none">${esc(err.message)}</div>`; return; }

  const asOf = BOOT.freshness?.fetched_at ? String(BOOT.freshness.fetched_at).slice(0, 10) : '';
  const open = d.benefits.filter(b => !b.incomeTest);
  const cond = d.benefits.filter(b => b.incomeTest);

  out.innerHTML = `
    <div class="rhead">
      <h2>조건이 맞는 사업 <b>${n(d.count)}건</b></h2>
      ${asOf ? `<span class="as-of">${esc(asOf)} 수집</span>` : ''}
    </div>

    ${open.length ? `
      <div class="rhead" style="margin:20px 0 8px">
        <h2 style="font-size:17px">소득 조건 없이 신청할 수 있어 보이는 것 <b>${n(open.length)}건</b></h2>
      </div>
      ${open.map(cardHtml).join('')}` : ''}

    ${cond.length ? `
      <div class="rhead" style="margin:26px 0 8px">
        <h2 style="font-size:17px">소득·재산 조건을 따져봐야 하는 것 <b>${n(cond.length)}건</b></h2>
      </div>
      ${cond.map(cardHtml).join('')}` : ''}

    ${d.count ? `<div class="caveat" style="margin:18px 0 0">${esc(d.caveat)}</div>`
      : `<div class="none">조건에 맞는 사업을 찾지 못했습니다.<br>
           시·군·구를 “전체”로 바꾸거나 분야 선택을 줄여보세요.</div>`}`;

  out.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ---------- 화면 ---------- */
function render() {
  const f = BOOT.freshness || {};
  $('#app').innerHTML = `
    <div class="hero">
      <h1>몰라서 못 받는 지원,<br><em>있는지부터</em> 봅시다.</h1>
      <p>사는 곳과 나이만 넣으면 됩니다. 중앙부처와 우리 지역 사업을 함께 찾아
         소득 조건이 붙는 것과 아닌 것으로 갈라 보여드립니다.</p>
    </div>

    <div class="counts">
      <div><b>${n(f.total)}</b><span>전체 사업</span></div>
      <div><b>${n(f.central)}</b><span>중앙부처</span></div>
      <div><b>${n(f.local)}</b><span>지자체</span></div>
    </div>

    ${sentenceHtml()}
    <div id="results"></div>`;
  bindForm();
}

function about() {
  const f = BOOT.freshness || {};
  $('#app').innerHTML = `
    <a class="back" href="#/">← 처음으로</a>
    <div class="hero"><h1>자료 출처</h1></div>
    <div class="doc">
      <h2>어디서 가져오나요</h2>
      <p><b>한국사회보장정보원</b>이 공공데이터포털로 공개하는 복지서비스 정보를 매일 수집합니다.
         중앙부처 ${n(f.central)}건, 지자체 ${n(f.local)}건이며,
         각 사업의 원문은 정부 복지포털 <b>복지로</b>로 연결됩니다.</p>
    </div>
    <div class="doc">
      <h2>“받을 수 있다”고 말하지 않는 이유</h2>
      <p>복지 사업 대부분에 “기준 중위소득 OO% 이하” 같은 요건이 붙습니다.
         가구원 수·소득·재산을 함께 봐야 하는 계산이고, 저희에게는 그 자료가 없습니다.
         확실하지 않은 것을 확실한 것처럼 말하면 헛걸음을 하시게 됩니다.</p>
    </div>
    <div class="doc">
      <h2>대신 하는 일</h2>
      <p>사업 설명에 소득·재산 요건이 적혀 있는지를 보고 두 갈래로 나눕니다.
         판정은 아니지만, <b>무엇을 먼저 볼지</b>는 분명해집니다.
         요약에 안 적혀 있어도 신청 단계에서 조건이 붙을 수 있어 원문 확인이 필요합니다.</p>
    </div>
    <div class="doc">
      <h2>최종 수집</h2>
      <p>${esc(String(f.fetched_at || '—').slice(0, 16))} · 매일 새벽 자동 갱신</p>
    </div>`;
}

function route() { location.hash === '#/about' ? about() : render(); }
window.addEventListener('hashchange', route);
window.addEventListener('error', (e) => {
  $('#app').innerHTML = `<div class="none">화면 오류: ${esc(e.message)}</div>`;
});

(async () => {
  try { BOOT = await api('/api/bootstrap'); route(); }
  catch (err) { $('#app').innerHTML = `<div class="none">${esc(err.message)}</div>`; }
})();
