INSERT INTO sources (slug, name, base_url, license, enabled, config) VALUES
  ('central', '한국사회보장정보원 중앙부처복지서비스',
   'https://apis.data.go.kr/B554287/NationalWelfareInformationsV001/NationalWelfarelistV001',
   '공공데이터포털 오픈API · 한국사회보장정보원 제공 (data.go.kr/data/15090532)', 1,
   '{"numOfRows":500,"srchKeyCode":"001"}'),

  ('local', '한국사회보장정보원 지자체복지서비스',
   'https://apis.data.go.kr/B554287/LocalGovernmentWelfareInformations/LcgvWelfarelist',
   '공공데이터포털 오픈API · 한국사회보장정보원 제공 (data.go.kr/data/15108347)', 1,
   '{"numOfRows":500}'),

  -- 대상특성은 응답에 안 담겨서 코드별로 따로 조회해야 한다.
  -- 하루 100회 한도라 한 번에 다 못 돌린다. 코드를 하나씩 돌아가며 채운다.
  ('targets', '대상특성 태깅 (한부모·장애인 등)',
   'https://apis.data.go.kr/B554287/NationalWelfareInformationsV001/NationalWelfarelistV001',
   '위 두 수집원과 같은 API 를 조건별로 조회', 1,
   '{"cursor":0,"numOfRows":500}');
