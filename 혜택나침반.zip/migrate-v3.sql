-- 지자체 사업에는 시행 종료일이 있다. 이미 끝난 사업을 목록에 띄우면
-- 헛걸음을 시키므로 받아 두었다가 화면에서 걸러낸다.
ALTER TABLE benefits ADD COLUMN end_ymd TEXT;
