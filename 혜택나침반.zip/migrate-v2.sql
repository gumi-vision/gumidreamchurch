-- ============================================================
--  v2 — 상세 정보를 끌어온다 (이 서비스의 차별화 지점)
--
--  목록 API 의 요약문에는 금액이 없다. "일정금액의 연금을 지급합니다"
--  같은 문장뿐이라, 이용자가 가장 궁금해하는 것에 답하지 못한다.
--
--  상세 API 에는 다 있다.
--    alwServCn    지원 내용 → "기준연금액(349,700원)"
--    slctCritCn   선정 기준 → "만 65세 이상 / 소득인정액 …"
--    applmetList  신청 방법 → "읍·면·동 주민센터, 국민연금공단 지사"
--    crtrYr       기준 연도
--
--  복지로에서는 목록에서 한 번 더 눌러야 보이는 것들이다.
--  조건을 넣으면 이게 카드에 바로 펼쳐지는 것이 우리가 더 나은 지점이다.
--
--  다만 사업 하나당 호출 한 번이고 하루 100회 한도라 5,219건을 한 번에
--  못 받는다. 복지로 조회수가 높은 것부터 채운다. 사람들이 실제로 많이
--  보는 사업이 먼저 채워지므로, 며칠이면 체감상 대부분 채워진다.
-- ============================================================

ALTER TABLE benefits ADD COLUMN target_detail TEXT;   -- 지원 대상
ALTER TABLE benefits ADD COLUMN criteria      TEXT;   -- 선정 기준
ALTER TABLE benefits ADD COLUMN content       TEXT;   -- 지원 내용 (금액이 여기 있다)
ALTER TABLE benefits ADD COLUMN apply_how     TEXT;   -- 신청 방법
ALTER TABLE benefits ADD COLUMN crtr_year     TEXT;   -- 기준 연도
ALTER TABLE benefits ADD COLUMN detail_at     TEXT;   -- 상세를 받아온 시각

-- 아직 상세를 안 받은 것부터, 조회수 높은 순으로 고르기 위한 인덱스
CREATE INDEX idx_benefits_detail ON benefits(detail_at, views DESC);

INSERT INTO sources (slug, name, base_url, license, enabled, config) VALUES
  ('details', '복지서비스 상세 (금액·선정기준·신청방법)',
   'https://apis.data.go.kr/B554287/NationalWelfareInformationsV001/NationalWelfaredetailedV001',
   '공공데이터포털 오픈API · 한국사회보장정보원 제공', 1,
   '{"perRun":60}');
