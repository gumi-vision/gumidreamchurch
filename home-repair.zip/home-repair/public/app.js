/* ============================================================
   화면. 공간 → 부위 → 증상 → 해결.

   가장 중요한 것은 상세 화면 맨 위의 판정이다. 해결 방법보다 먼저 온다.
   "이건 내가 해도 되는 일인가"에 답하는 것이 이 사이트의 일이다.
   ============================================================ */

const $ = (s) => document.querySelector(s);
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
};
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const bold = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

const state = { space: null, part: null, problem: null, q: '', symptom: null, tool: null, panel: null, data: null };

/* ---------- 뒤로가기 ----------
 * 화면 전환을 주소에 남기지 않으면, 휴대폰에서 뒤로가기를 눌렀을 때 한 단계
 * 돌아가는 대신 사이트 밖으로 나가 버린다. 모바일에서는 이게 곧 이탈이다.
 *
 * 서버 라우팅이 없는 정적 사이트라 해시(#/…)를 쓴다.
 */
const BLANK = { space: null, part: null, problem: null, q: '', symptom: null, tool: null, panel: null };

function toHash() {
  const s = state;
  if (s.problem) return `#/p/${encodeURIComponent(s.problem)}`;
  if (s.symptom) return `#/s/${encodeURIComponent(s.symptom)}`;
  if (s.tool)    return `#/t/${encodeURIComponent(s.tool)}`;
  if (s.q)       return `#/q/${encodeURIComponent(s.q)}`;
  if (s.panel)   return `#/${s.panel}`;
  if (s.part)    return `#/${s.space}/${s.part}`;
  if (s.space)   return `#/${s.space}`;
  return '#/';
}

function fromHash(hash) {
  const parts = String(hash || '').replace(/^#\/?/, '').split('/').filter(Boolean)
    .map(x => { try { return decodeURIComponent(x); } catch { return x; } });
  const s = { ...BLANK };
  if (!parts.length) return s;
  const [a, b] = parts;

  if (a === 'p') {
    const p = state.data.problems.find(x => x.id === b);
    if (p) Object.assign(s, { space: p.space, part: p.part, problem: p.id });
    return s;
  }
  if (a === 's') { s.symptom = b || null; return s; }
  if (a === 't') { s.tool = b || null; return s; }
  if (a === 'q') { s.q = b || ''; return s; }
  if (a === 'emergency' || a === 'tenancy') { s.panel = a; return s; }

  const space = state.data.spaces.find(x => x.id === a);
  if (space) {
    s.space = space.id;
    if (b && space.parts.some(p => p.id === b)) s.part = b;
  }
  return s;
}

/*
 * 화면을 바꾸는 유일한 통로. 여기서만 히스토리를 쌓는다.
 * replace 는 검색어를 칠 때처럼 한 글자마다 기록이 쌓이면 안 되는 경우에 쓴다.
 */
function go(patch, { replace = false } = {}) {
  Object.assign(state, BLANK, patch);
  const hash = toHash();
  if (replace || hash === location.hash) history.replaceState(null, '', hash);
  else history.pushState(null, '', hash);
  render();
}

/* ---------- 우리 집 위치 메모 ----------
 * 브라우저에만 남는다. 서버로 보내지 않는다. 사생활이 담기는 정보라 그렇게 둔다.
 * 저장이 막힌 환경(사생활 보호 모드 등)에서도 화면은 그대로 동작해야 한다.
 */
const MEMO_KEY = 'home-repair.locations';
function readMemo() {
  try { return JSON.parse(localStorage.getItem(MEMO_KEY) || '{}'); }
  catch { return {}; }
}
function writeMemo(memo) {
  try { localStorage.setItem(MEMO_KEY, JSON.stringify(memo)); return true; }
  catch { return false; }
}

function renderMyHome() {
  const box = $('#my-home');
  box.textContent = '';
  const memo = readMemo();

  for (const loc of state.data.locations) {
    const row = el('label', 'memo-row');
    row.append(el('span', 'memo-label', `${esc(loc.label)}<small>${esc(loc.hint)}</small>`));
    const input = el('input');
    input.type = 'text';
    input.value = memo[loc.id] || '';
    input.placeholder = '예) 현관 신발장 오른쪽 위';
    input.oninput = () => {
      const next = readMemo();
      next[loc.id] = input.value;
      if (!writeMemo(next)) {
        box.querySelector('.memo-warn')?.remove();
        box.append(el('p', 'memo-warn', '이 브라우저에서는 저장이 막혀 있습니다. 사진으로 찍어 두세요.'));
      }
    };
    row.append(input);
    box.append(row);
  }
}

/* ---------- 전세·월세 ----------
 * 법이 얽힌 영역이라 판정을 단정하지 않는다. 이 화면의 알맹이는 판정이 아니라
 * 증거를 남기는 방법이다. 증거는 어느 쪽이 맞든 필요하다.
 */
function renderTenancy() {
  const box = $('#tenancy');
  const t = state.data.tenancy;
  box.textContent = '';

  box.append(el('div', 'disclaimer', bold(t.disclaimer.trim())));

  for (const s of t.sections) {
    const sec = el('div', 'ten-sec');
    sec.append(el('div', 'ten-when', esc(s.when)));
    sec.append(el('h3', null, esc(s.title)));
    if (s.lead) sec.append(el('p', 'lead', esc(s.lead.trim())));

    if (s.items?.length) {
      sec.append(el('ul', 'plain', s.items.map(i => `<li>${bold(i)}</li>`).join('')));
    }
    if (s.columns?.length) {
      const cols = el('div', 'ten-cols');
      for (const c of s.columns) {
        const col = el('div', 'ten-col');
        col.append(el('h4', null, esc(c.side)));
        col.append(el('ul', 'plain', c.items.map(i => `<li>${bold(i)}</li>`).join('')));
        cols.append(col);
      }
      sec.append(cols);
    }
    if (s.note) sec.append(el('p', 'ten-note', bold(s.note.trim())));
    box.append(sec);
  }

  // 자주 다투는 것 — 양쪽 주장을 나란히 두고, 가르는 법과 증거를 붙인다.
  const dis = el('div', 'ten-sec');
  dis.append(el('div', 'ten-when', '쟁점'));
  dis.append(el('h3', null, '자주 다투는 것'));
  for (const d of t.disputes) {
    const card = el('div', 'dispute');
    card.append(el('h4', null, esc(d.title)));
    const two = el('div', 'dispute-two');
    two.append(el('div', 'side tenant', `<b>세입자 쪽으로 보는 경우</b><p>${esc(d.tenant_side)}</p>`));
    two.append(el('div', 'side landlord', `<b>임대인 쪽으로 보는 경우</b><p>${esc(d.landlord_side)}</p>`));
    card.append(two);
    if (d.how_to_tell) {
      card.append(el('p', 'how', `<b>가르는 법</b> ${esc(d.how_to_tell.trim())}`));
    }
    card.append(el('p', 'evidence', `<b>남길 증거</b> ${esc(d.evidence)}`));

    if (d.related?.length) {
      const links = el('p', 'related');
      links.append(el('span', null, '관련 증상 '));
      for (const id of d.related) {
        const p = state.data.problems.find(x => x.id === id);
        if (!p) continue;
        const b = el('button', 'linkish', esc(p.title));
        b.onclick = () => {
          go({ space: p.space, part: p.part, problem: p.id });
          scrollTo({ top: 0, behavior: 'smooth' });
        };
        links.append(b);
      }
      card.append(links);
    }
    dis.append(card);
  }
  box.append(dis);

  // 51건에 흩어진 tenant_note 를 한자리에 모은 것.
  const list = t.landlord_items || [];
  if (list.length) {
    const sec = el('div', 'ten-sec');
    sec.append(el('div', 'ten-when', '모아 보기'));
    sec.append(el('h3', null, `집주인에게 먼저 알릴 일 ${list.length}가지`));
    sec.append(el('p', 'lead',
      '고쳐 놓고 청구하면 대개 못 받습니다. 아래 항목들은 손대기 전에 알리는 편이 낫습니다.'));
    const ul = el('ul', 'plain');
    for (const it of list) {
      const li = el('li');
      const b = el('button', 'linkish', esc(it.title));
      b.onclick = () => {
        go({ space: it.space, part: it.part, problem: it.id });
        scrollTo({ top: 0, behavior: 'smooth' });
      };
      li.append(b);
      li.append(el('span', 'where', ` ${esc(whereOf(it))}`));
      ul.append(li);
    }
    sec.append(ul);
    box.append(sec);
  }
}

/* ---------- 급할 때 ---------- */
function renderEmergency() {
  const box = $('#emergency');
  box.textContent = '';
  box.append(el('p', 'emg-lead', '고치는 것은 나중입니다. 먼저 잠그고, 나오고, 알리세요.'));

  for (const it of state.data.emergency) {
    const card = el('div', 'emg');
    card.append(el('h3', null, esc(it.title)));
    if (it.also_called?.length) {
      card.append(el('p', 'aka', it.also_called.map(esc).join(' · ')));
    }
    const step = (title, items, cls) => {
      if (!items?.length) return;
      card.append(el('h4', cls, esc(title)));
      card.append(el('ul', `plain ${cls || ''}`, items.map(i => `<li>${bold(i)}</li>`).join('')));
    };
    step('먼저 이것부터', it.first);
    step('그다음', it.then);
    step('절대 하지 마세요', it.never, 'never');
    box.append(card);
  }
}

const VERDICT = {
  yes:     { label: '직접 할 수 있어요', head: '직접 해도 됩니다' },
  careful: { label: '조심해서',          head: '할 수는 있지만, 조심해야 합니다' },
  no:      { label: '손대지 마세요',      head: '직접 하지 마세요' },
};
const TENANT = {
  self:     '세입자가 해도 되는 일',
  landlord: '집주인 부담일 수 있음',
  ask:      '집주인에게 먼저 물어볼 것',
};

/* ---------- 상세 ---------- */

function block(title, node, cls) {
  const b = el('div', `block ${cls || ''}`);
  b.append(el('h4', null, esc(title)), node);
  return b;
}
const list = (items, cls) =>
  el('ul', `plain ${cls || ''}`, items.map(i => `<li>${bold(i)}</li>`).join(''));

function renderDetail(p) {
  const wrap = el('div');
  wrap.append(el('h3', null, esc(p.title)));
  if (p.also_called?.length) {
    wrap.append(el('p', 'aka', '이렇게도 부릅니다 — ' + p.also_called.map(esc).join(' · ')));
  }

  /*
   * 판정이 맨 위에 온다. 방법을 먼저 보여주면 판정을 안 읽는다.
   */
  const v = VERDICT[p.diy] || VERDICT.careful;
  const j = el('div', `judgement ${p.diy}`);
  j.append(el('div', 'head', esc(v.head)));
  if (p.diy === 'no' && p.diy_reason) j.append(el('p', null, esc(p.diy_reason.trim())));
  else if (p.likely_cause) j.append(el('p', null, esc(p.likely_cause.trim())));
  wrap.append(j);

  const meta = el('div', 'meta');
  if (p.tenant) meta.append(el('span', null, esc(TENANT[p.tenant])));
  if (p.time) meta.append(el('span', null, '⏱ ' + esc(p.time)));
  if (p.tools?.length) meta.append(el('span', null, '🧰 ' + p.tools.map(esc).join(', ')));
  if (meta.children.length) wrap.append(meta);

  // 집주인 몫일 수 있다는 안내는 방법보다 앞에 둔다. 고쳐 놓고 청구하면 다투게 된다.
  if (p.tenant_note) {
    wrap.append(block('전세·월세라면', el('p', null, esc(p.tenant_note.trim())), 'tenant-box'));
  }

  if (p.diy === 'no' && p.likely_cause) {
    wrap.append(block('왜 이런가', el('p', null, esc(p.likely_cause.trim()))));
  }
  if (p.check_first?.length) {
    wrap.append(block('대신 이것부터 확인하세요', list(p.check_first)));
  }
  if (p.steps?.length) {
    wrap.append(block('해보기',
      el('ol', 'steps', p.steps.map(s => `<li>${bold(s)}</li>`).join(''))));
  }
  if (p.stop_if?.length) {
    wrap.append(block('여기서 멈추세요', list(p.stop_if), 'danger'));
  }
  if (p.caution?.length) {
    wrap.append(block('주의', list(p.caution), 'danger'));
  }

  /*
   * 영상은 박아 넣지 않고 검색어를 준다. 링크는 죽지만 검색어는 안 죽는다.
   * 그리고 초보자가 막히는 지점은 대개 "이걸 뭐라고 부르는지 모르는 것"이다.
   */
  if (p.search?.terms?.length) {
    const box = el('div', 'search-box');
    if (p.search.why) box.append(el('p', 'why', esc(p.search.why.trim())));
    const terms = el('div', 'terms');
    for (const t of p.search.terms) {
      const a = el('a', 'term', `<span>${esc(t)}</span><em>유튜브에서 보기 ↗</em>`);
      a.href = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(t);
      a.target = '_blank'; a.rel = 'noopener';
      terms.append(a);
    }
    box.append(terms);
    wrap.append(block('이렇게 검색하세요', box));
  }
  return wrap;
}

/* ---------- 목록 ---------- */

/*
 * 부위 id 는 공간 안에서만 유일하다. sink 가 화장실(세면대)에도 주방(싱크대)에도
 * 있어서, 공간을 안 따지고 찾으면 주방 항목이 "세면대"로 표시된다.
 */
function whereOf(p) {
  const space = state.data.spaces.find(s => s.id === p.space);
  const part = space?.parts.find(x => x.id === p.part);
  return [space?.name, part?.name].filter(Boolean).join(' · ');
}

function problemRow(p) {
  const v = VERDICT[p.diy] || VERDICT.careful;
  const row = el('button', 'row');
  row.append(el('div', 'row-title',
    `${esc(p.title)}${state.part ? '' : `<small>${esc(whereOf(p))}</small>`}`));
  row.append(el('span', `verdict v-${p.diy}`, esc(v.label)));
  row.onclick = () => go({ space: p.space, part: p.part, problem: p.id });
  return row;
}

function matches(p) {
  if (state.symptom) return (p.symptoms || []).includes(state.symptom);
  if (state.tool) return (p.tools || []).some(t => t.replace(/\(.*?\)/g, '').trim() === state.tool);
  if (state.q) {
    const hay = [p.title, ...(p.also_called || []), p.likely_cause,
      ...(p.symptoms || []), ...(p.search?.terms || [])].join(' ').toLowerCase();
    return hay.includes(state.q.toLowerCase());
  }
  return p.space === state.space && p.part === state.part;
}

function renderCrumbs() {
  const c = $('#crumbs');
  c.textContent = '';
  if (state.symptom) { c.textContent = `증상 — ${state.symptom}`; return; }
  if (state.tool) { c.textContent = `도구 — ${state.tool}`; return; }
  if (state.q) { c.textContent = `‘${state.q}’ 검색 결과`; return; }
  if (!state.space) return;

  const space = state.data.spaces.find(s => s.id === state.space);
  const add = (label, onClick) => {
    if (c.children.length) c.append(el('span', null, '›'));
    if (!onClick) { c.append(el('b', null, esc(label))); return; }
    const b = el('button', null, esc(label));
    b.onclick = onClick;
    c.append(b);
  };
  add(space.name, state.part ? () => go({ space: state.space }) : null);

  if (state.part) {
    const part = space.parts.find(p => p.id === state.part);
    add(part.name, state.problem ? () => go({ space: state.space, part: state.part }) : null);
  }
  if (state.problem) {
    add(state.data.problems.find(p => p.id === state.problem).title, null);
  }
}

function render() {
  renderCrumbs();
  // 검색·증상·도구는 모두 "목록을 바로 보여주는" 경로다.
  const listing = !!(state.q || state.symptom || state.tool);

  // 뒤로가기로도 들어오므로, 화면은 늘 state 만 보고 그린다.
  $('#emergency').hidden = state.panel !== 'emergency';
  $('#tenancy').hidden = state.panel !== 'tenancy';
  $('#sos').setAttribute('aria-expanded', String(state.panel === 'emergency'));
  $('#tenancy-btn').setAttribute('aria-expanded', String(state.panel === 'tenancy'));

  if ($('#q').value !== state.q) $('#q').value = state.q;
  for (const [host, key] of [[$('#symptom-list'), 'symptom'], [$('#tool-list'), 'tool']]) {
    for (const chip of host.children) {
      chip.setAttribute('aria-pressed', String(chip.dataset.name === state[key]));
    }
  }

  const inPanel = !!state.panel;
  $('#step-space').hidden = inPanel || listing || !!state.space;
  $('#step-part').hidden = inPanel || listing || !state.space || !!state.part;
  $('#step-problem').hidden = inPanel ? true : (listing ? false : (!state.part || !!state.problem));
  $('#detail').hidden = !state.problem;

  if (state.problem) {
    const p = state.data.problems.find(x => x.id === state.problem);
    $('#detail').textContent = '';
    $('#detail').append(renderDetail(p));
    return;
  }

  if (listing || state.part) {
    const found = state.data.problems.filter(matches);
    const box = $('#problem-list');
    box.textContent = '';
    if (!found.length) {
      box.append(el('p', 'empty', '해당하는 증상을 아직 못 담았습니다. 지금은 화장실만 채워져 있습니다.'));
    }
    for (const p of found) box.append(problemRow(p));
  }

  if (state.space && !state.part) {
    const space = state.data.spaces.find(s => s.id === state.space);
    const box = $('#part-list');
    box.textContent = '';
    for (const part of space.parts) {
      const b = el('button', 'pick', `<b>${esc(part.name)}</b><span>${part.n}가지 증상</span>`);
      b.onclick = () => go({ space: state.space, part: part.id });
      box.append(b);
    }
  }
}

/* ---------- 시작 ---------- */

async function init() {
  state.data = await (await fetch('/data.json')).json();

  const box = $('#space-list');
  for (const s of state.data.spaces) {
    const ready = s.n > 0;
    const b = el('button', 'pick',
      `<b>${esc(s.name)}</b><span>${ready ? `${s.n}가지 증상` : '준비 중'}</span>`);
    b.disabled = !ready;
    b.onclick = () => go({ space: s.id });
    box.append(b);
  }

  // 증상·도구 칩. 데이터를 새로 안 만들고 있는 51건을 다른 축으로 다시 꿴 것이다.
  const chipRow = (host, items, key, label) => {
    for (const it of items) {
      const b = el('button', 'chip', `${esc(label(it))}<em>${it.n ?? it.ids.length}</em>`);
      b.dataset.name = it.name;
      b.setAttribute('aria-pressed', 'false');
      b.onclick = () => go(state[key] === it.name ? {} : { [key]: it.name });
      host.append(b);
    }
  };
  chipRow($('#symptom-list'), state.data.symptoms, 'symptom', it => it.name);
  chipRow($('#tool-list'), state.data.tools, 'tool', it => it.name);

  renderMyHome();
  renderEmergency();
  renderTenancy();

  const panelBtn = (btnSel, name) => {
    $(btnSel).onclick = () => {
      go(state.panel === name ? {} : { panel: name });
      if (state.panel === name) $(`#${name}`).scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
  };
  panelBtn('#sos', 'emergency');
  panelBtn('#tenancy-btn', 'tenancy');

  // 한 글자마다 히스토리를 쌓으면 뒤로가기가 글자 단위로 되돌아간다.
  // 검색을 시작할 때만 한 칸 쌓고, 그 뒤로는 덮어쓴다.
  $('#q').oninput = (e) => {
    const q = e.target.value.trim();
    go({ q }, { replace: !!state.q });
  };
  $('#home').onclick = (e) => { e.preventDefault(); go({}); };

  // 뒤로가기·앞으로가기. 주소만 보고 화면을 다시 그린다.
  addEventListener('popstate', () => {
    Object.assign(state, fromHash(location.hash));
    render();
  });

  const n = state.data.problems.length;
  const no = state.data.problems.filter(p => p.diy === 'no').length;
  $('#freshness').textContent =
    `증상 ${n}가지 수록 · 그중 ${no}가지는 직접 하지 말라고 안내합니다 · ${state.data.built_at} 기준`;

  // 주소에 담긴 화면으로 시작한다. 링크를 받은 사람이 그 증상을 바로 보게 된다.
  Object.assign(state, fromHash(location.hash));
  history.replaceState(null, '', toHash());
  render();
}

init().catch(err => {
  $('#step-space').append(el('p', 'empty', '데이터를 불러오지 못했습니다. npm run build 를 먼저 실행하세요.'));
  console.error(err);
});
