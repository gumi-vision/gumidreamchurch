/* ============================================================
   빌드 — data/*.yaml 을 검증해서 public/data.json 으로 만든다.

   이 사이트는 앞의 것들과 위험이 다르다. 틀린 API 한도는 시간을 버리게
   하지만, 틀린 수리 안내는 사람을 다치게 하거나 아랫집 천장을 적신다.

   그래서 검증이 안전 쪽으로 기울어 있다. 특히:
     - diy: no 인데 steps 가 있으면 세운다. 방법을 반쯤 보여주면 반쯤 하다 사고 난다
     - diy: careful 인데 stop_if 가 없으면 세운다. 언제 멈춰야 하는지 없는 주의는 주의가 아니다
   ============================================================ */

import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'js-yaml';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

const DIY = ['yes', 'careful', 'no'];
const TENANT = ['self', 'landlord', 'ask'];

const problems = [];
const warnings = [];
const fail = (where, msg) => problems.push(`${where}: ${msg}`);
const warn = (where, msg) => warnings.push(`${where}: ${msg}`);

const load = (p) => yaml.load(readFileSync(p, 'utf8'));

/* ---------- 공간·부위 ---------- */
const spaceDoc = load(join(ROOT, 'data', 'spaces.yaml'));
const spaces = spaceDoc.spaces || [];
const partIndex = new Map();          // "bathroom/sink" -> {space, part}
for (const s of spaces) {
  for (const p of s.parts || []) partIndex.set(`${s.id}/${p.id}`, { space: s, part: p });
}

/* ---------- 증상 ---------- */
const files = readdirSync(join(ROOT, 'data', 'problems')).filter(f => f.endsWith('.yaml'));
const all = [];
const seenIds = new Set();

for (const file of files) {
  const doc = load(join(ROOT, 'data', 'problems', file));
  const key = `${doc.space}/${doc.part}`;
  if (!partIndex.has(key)) {
    fail(file, `모르는 공간/부위: ${key} — data/spaces.yaml 에 정의된 것만 쓸 수 있다`);
    continue;
  }

  for (const p of doc.problems || []) {
    const where = `${file} › ${p.id || '(id 없음)'}`;

    for (const k of ['id', 'title', 'likely_cause', 'diy', 'tenant', 'search']) {
      if (p[k] === undefined) fail(where, `필수 항목 ${k} 가 없다`);
    }
    if (seenIds.has(p.id)) fail(where, `id 가 중복이다: ${p.id}`);
    seenIds.add(p.id);

    if (p.diy !== undefined && !DIY.includes(p.diy)) {
      fail(where, `diy 값이 이상하다: ${p.diy} (가능: ${DIY.join(', ')})`);
    }
    if (p.tenant !== undefined && !TENANT.includes(p.tenant)) {
      fail(where, `tenant 값이 이상하다: ${p.tenant} (가능: ${TENANT.join(', ')})`);
    }

    /*
     * 안전 규칙. 여기서 세우는 것들은 타협하지 않는다.
     */
    if (p.diy === 'no') {
      if (p.steps?.length) {
        fail(where, 'diy: no 인데 steps 가 있다. 방법을 반쯤 보여주면 반쯤 하다 사고가 난다');
      }
      if (!p.diy_reason) fail(where, 'diy: no 인데 이유(diy_reason)가 없다. 왜 안 되는지 말해야 납득한다');
      if (!p.check_first?.length && !p.stop_if?.length) {
        warn(where, 'diy: no 인데 대신 무엇을 확인하라는 안내가 없다');
      }
    }
    if (p.diy === 'careful' && !p.stop_if?.length) {
      fail(where, 'diy: careful 인데 stop_if 가 없다. 언제 멈춰야 하는지 없는 주의는 주의가 아니다');
    }
    if (p.diy === 'yes' && !p.steps?.length) {
      fail(where, 'diy: yes 인데 steps 가 없다');
    }

    // 물이 얽힌 일은 아랫집으로 번진다. 세입자 판정이 ask/landlord 면 이유를 적게 한다.
    if ((p.tenant === 'ask' || p.tenant === 'landlord') && !p.tenant_note) {
      fail(where, `tenant: ${p.tenant} 인데 tenant_note 가 없다. 왜 집주인 몫인지 적어야 연락할 때 쓴다`);
    }

    // 검색어가 이 사이트의 핵심 전달물이다. 용어를 알려주는 것 자체가 값어치다.
    if (!p.search?.terms?.length) fail(where, 'search.terms 가 없다');
    if (p.search?.terms?.length && !p.search.why) {
      warn(where, '검색어를 적었는데 왜 그 말이어야 하는지(why)가 없다');
    }

    all.push({ ...p, space: doc.space, part: doc.part });
  }
}

/* ---------- 전세·월세 ---------- */
const tenancy = load(join(ROOT, 'data', 'tenancy.yaml'));
if (!tenancy.disclaimer) {
  // 법이 얽힌 문서다. 한계를 밝히지 않은 채 내보내면 안 된다.
  fail('tenancy.yaml', 'disclaimer 가 없다');
}
for (const s of tenancy.sections || []) {
  const where = `tenancy.yaml › ${s.id || '(id 없음)'}`;
  for (const k of ['id', 'when', 'title']) if (!s[k]) fail(where, `필수 항목 ${k} 가 없다`);
  if (!s.items?.length && !s.columns?.length) fail(where, 'items 나 columns 중 하나는 있어야 한다');
}
for (const d of tenancy.disputes || []) {
  const where = `tenancy.yaml › ${d.id || '(id 없음)'}`;
  for (const k of ['id', 'title', 'tenant_side', 'landlord_side', 'evidence']) {
    if (!d[k]) fail(where, `필수 항목 ${k} 가 없다`);
  }
  // 오타 하나로 링크가 조용히 끊기는 것을 막는다.
  for (const id of d.related || []) {
    if (!seenIds.has(id)) fail(where, `없는 증상을 가리킨다: ${id}`);
  }
}

/* ---------- 급할 때 보는 것 ---------- */
const emergency = load(join(ROOT, 'data', 'emergency.yaml'));
for (const it of emergency.items || []) {
  const where = `emergency.yaml › ${it.id || '(id 없음)'}`;
  for (const k of ['id', 'title', 'first', 'never']) {
    if (!it[k]) fail(where, `필수 항목 ${k} 가 없다`);
  }
  // 급할 때 보는 화면에 "하지 말 것"이 없으면 안 된다. 거기서 사고가 난다.
  if (it.never && !it.never.length) fail(where, 'never 가 비어 있다');
}

/*
 * 증상 유형 축. 사용자는 부위 이름을 모를 때가 많다.
 * "어디선가 물이 새는데 어디서 새는지 모르겠어요"가 실제 상황이다.
 *
 * 51건에 태그를 손으로 붙이는 대신 제목과 별칭에서 뽑는다. 규칙을 여기 모아
 * 두면 어디가 틀렸는지 한눈에 보이고, 필요하면 증상 파일에 symptoms 를 적어
 * 덮어쓸 수 있다.
 */
const SYMPTOM_RULES = [
  ['물이 새요',            /새요|새는|누수|젖|물이 떨어|물이 고여|고여요|역류|넘쳐/],
  ['물이 안 내려가요',      /안 내려가|안 빠|막혔|막힘|배수/],
  ['물이 안 나오거나 약해요', /물이 약|수압|온수|물이 안 나와|찔끔/],
  ['냄새가 나요',          /냄새|악취/],
  ['곰팡이·때',            /곰팡이|결로|물이 맺|김이 서|거뭇|줄눈|변색/],
  ['틈·들뜸·벌어짐',        /벌어|틈|들뜨|들떠|떨어지고|갈라/],
  ['안 열려요·안 닫혀요',   /안 닫|안 열|안 잠|뻑뻑|헛돌|걸려|처짐/],
  ['소리가 나요',          /소리|소음|삐걱|시끄/],
  ['안 켜져요·전기',       /안 켜|깜빡|전기|차단기|두꺼비집|콘센트/],
  ['불이 안 붙어요·불꽃',   /불이 안|불꽃|점화/],
  ['에러·고장 표시',       /에러|코드/],
  ['환기·연기',            /흡입|안 빨려|연기|후드/],
  ['춥거나 안 따뜻해요',    /안 따뜻|추워|웃풍|바람이 들어|난방/],
  ['벌레가 나와요',        /벌레|파리|초파리/],
  ['미리 해둘 것',         /예방|비웁니다|장기 ?외출/],
];

function symptomsOf(p) {
  if (p.symptoms?.length) return p.symptoms;          // 직접 적었으면 그대로 쓴다
  const hay = [p.title, ...(p.also_called || [])].join(' ');
  return SYMPTOM_RULES.filter(([, re]) => re.test(hay)).map(([name]) => name);
}
for (const p of all) {
  p.symptoms = symptomsOf(p);
  if (!p.symptoms.length) warn(`${p.id}`, '증상 유형이 하나도 안 붙었다 — SYMPTOM_RULES 를 보완하거나 symptoms 를 직접 적을 것');
}

/*
 * 도구 역인덱스. 새 데이터 없이 tools 를 뒤집기만 하면 된다.
 * "드라이버 하나로 해결되는 것 N가지" — 자취를 시작하는 사람에게 답이 된다.
 */

/*
 * 집에 이미 있는 것들은 뺀다. "고무장갑으로 18가지 해결" 은 정보가 아니다.
 * 이 목록의 쓸모는 "이걸 사 두면 N가지를 직접 할 수 있다" 이므로,
 * 사야 하는 것만 남겨야 뜻이 산다.
 */
const COMMON = /^(고무장갑|장갑|마른 걸레|걸레|수건|마스크|비닐봉지|신문지|화장지|휴지|대야|가위|못 쓰는 칫솔|이쑤시개|면봉|물|미지근한 물|뜨거운 물|사다리 또는 튼튼한 의자)$/;

const toolMap = new Map();
for (const p of all) {
  for (const t of p.tools || []) {
    const key = t.replace(/\(.*?\)/g, '').trim();     // "윤활제(WD-40 등)" → "윤활제"
    if (!key || COMMON.test(key)) continue;
    if (!toolMap.has(key)) toolMap.set(key, []);
    toolMap.get(key).push(p.id);
  }
}
const tools = [...toolMap]
  .map(([name, ids]) => ({ name, ids }))
  .filter(t => t.ids.length >= 2)                     // 하나뿐인 도구는 목록을 어지럽힌다
  .sort((a, b) => b.ids.length - a.ids.length);

for (const w of warnings) console.warn(`  ! ${w}`);
if (problems.length) {
  console.error('\n빌드를 세운다:');
  for (const p of problems) console.error(`  × ${p}`);
  process.exit(1);
}

// 화면에서 쓰기 좋게, 부위별 증상 수를 미리 세어 둔다.
const out = {
  built_at: new Date().toISOString().slice(0, 10),
  spaces: spaces.map(s => ({
    ...s,
    parts: (s.parts || []).map(p => ({
      ...p, n: all.filter(x => x.space === s.id && x.part === p.id).length,
    })),
    n: all.filter(x => x.space === s.id).length,
  })),
  problems: all,
  emergency: emergency.items || [],
  locations: emergency.locations || [],
  tenancy: {
    ...tenancy,
    // 51건에 흩어진 tenant_note 를 모은다. 이게 흩어져 있으면 아무도 못 읽는다.
    landlord_items: all
      .filter(p => p.tenant === 'landlord' || p.tenant === 'ask')
      .map(p => ({ id: p.id, title: p.title, space: p.space, part: p.part, tenant: p.tenant })),
  },
  symptoms: SYMPTOM_RULES.map(([name]) => name)
    .map(name => ({ name, n: all.filter(p => p.symptoms.includes(name)).length }))
    .filter(s => s.n > 0),
  tools,
};
writeFileSync(join(ROOT, 'public', 'data.json'), JSON.stringify(out, null, 1));

const byDiy = (v) => all.filter(p => p.diy === v).length;
console.log(`\n완료 — 증상 ${all.length}건`);
console.log(`직접 가능 ${byDiy('yes')} · 조심해서 ${byDiy('careful')} · 손대지 말 것 ${byDiy('no')}`);
console.log(`긴급 ${out.emergency.length}건 · 증상 유형 ${out.symptoms.length}종 · 도구 ${tools.length}종`);
if (warnings.length) console.log(`경고 ${warnings.length}건`);
