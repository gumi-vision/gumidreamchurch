/* ============================================================
   빌드 — data/*.yaml 을 검증해서 public/data.json 으로 만든다.

   원본은 사람이 쓴 yaml 이다. 사람이 쓰면 오타가 나고, 오타가 난 채로
   배포되면 화면에 빈 칸이 뜬다. 여기서 걸러 낸다.

   --check-links 를 주면 signup_url / docs_url 이 살아 있는지도 본다.
   발급 페이지 주소는 조용히 바뀐다. 실제로 도로명주소가 그랬다.
   죽은 링크는 이 사이트의 신뢰를 가장 빨리 깎아먹는다.
   ============================================================ */

import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'js-yaml';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const CHECK_LINKS = process.argv.includes('--check-links');

const CATEGORIES = [
  '지도·위치·주소', '로그인·인증', '결제·정산', '알림', 'AI·LLM',
  '이미지·미디어', '데이터', '개발 인프라', '검색·번역', '커뮤니케이션',
];
const AUTH = ['apiKey', 'oauth2', 'token', 'none'];
const APPROVAL = ['instant', 'review', 'waitlist'];
const FREE_KIND = ['perpetual', 'trial', 'credit'];
const VERIFIED_BY = ['signup', 'docs', null];

const problems = [];
const warnings = [];
const fail = (file, msg) => problems.push(`${file}: ${msg}`);
const warn = (file, msg) => warnings.push(`${file}: ${msg}`);

/*
 * yaml 은 따옴표 없는 2026-09-04 를 Date 로 읽는다. 그대로 JSON 에 넣으면
 * "2026-09-04T00:00:00.000Z" 가 되어 화면에 시각까지 찍힌다.
 * 작성자에게 따옴표를 씌우라고 요구하는 대신 여기서 되돌린다.
 */
function normalize(v) {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (Array.isArray(v)) return v.map(normalize);
  if (v && typeof v === 'object') {
    return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, normalize(x)]));
  }
  return v;
}

function loadDir(sub) {
  const dir = join(ROOT, 'data', sub);
  return readdirSync(dir)
    .filter(f => f.endsWith('.yaml'))
    .map(f => ({
      file: `${sub}/${f}`,
      id: basename(f, '.yaml'),
      doc: normalize(yaml.load(readFileSync(join(dir, f), 'utf8'))),
    }));
}

/* 검증. 틀린 데이터를 배포하느니 빌드를 세우는 게 낫다. */
function checkApi({ file, id, doc }) {
  const need = ['id', 'name', 'provider', 'tasks', 'signup_url',
                'docs_url', 'auth', 'card_required', 'approval', 'free_kind',
                'korea_ok', 'korean_ui', 'individual_ok', 'verified_by'];
  for (const k of need) {
    if (doc[k] === undefined) fail(file, `필수 항목 ${k} 가 없다`);
  }
  if (doc.id !== id) fail(file, `id(${doc.id})가 파일명(${id})과 다르다`);

  /*
   * tasks 는 분야별로 묶는다: { '지도·위치·주소': [...], '로그인·인증': [...] }
   *
   * 예전엔 categories 와 tasks 를 따로 적었는데, 그러면 어느 작업이 어느 분야
   * 것인지 데이터가 모른다. 카카오의 "카카오 로그인"이 지도 분야 칩으로 뜨는
   * 식이었다. 분야를 키로 두면 그 일이 안 생기고, categories 는 키에서 나온다.
   */
  if (doc.categories) {
    fail(file, 'categories 는 이제 적지 않는다. tasks 의 키에서 자동으로 나온다');
  }
  if (doc.tasks && (Array.isArray(doc.tasks) || typeof doc.tasks !== 'object')) {
    fail(file, "tasks 는 분야별 묶음이어야 한다 — tasks:\\n  데이터: [환율 조회, ...]");
  } else {
    for (const [cat, list] of Object.entries(doc.tasks || {})) {
      if (!CATEGORIES.includes(cat)) fail(file, `모르는 분야: ${cat}`);
      if (!Array.isArray(list) || !list.length) fail(file, `${cat} 에 작업이 비어 있다`);
    }
    doc.categories = Object.keys(doc.tasks || {});
    if (!doc.categories.length) fail(file, '분야가 하나도 없다');
  }

  /*
   * 카탈로그는 API 하나가 아니라 수천 개를 담은 포털이다. tasks 로는 못 덮는다.
   * covers(분야 + 그 분야를 가리키는 말들)와 검색 주소를 반드시 갖춰야 한다.
   */
  if (doc.kind && !['api', 'catalog'].includes(doc.kind)) {
    fail(file, `kind 값이 이상하다: ${doc.kind} (가능: api, catalog)`);
  }
  if (doc.kind === 'catalog') {
    if (!doc.search_url_template?.includes('{q}')) {
      fail(file, 'catalog 인데 search_url_template 에 {q} 자리가 없다');
    }
    if (!doc.covers?.length) fail(file, 'catalog 인데 covers 가 없다');
    for (const c of doc.covers || []) {
      if (!c.domain || !c.keywords?.length) fail(file, `covers 항목에 domain 이나 keywords 가 없다: ${JSON.stringify(c)}`);
    }
  }
  const oneOf = (k, list) => {
    if (doc[k] !== undefined && !list.includes(doc[k])) {
      fail(file, `${k} 값이 이상하다: ${doc[k]} (가능: ${list.join(', ')})`);
    }
  };
  oneOf('auth', AUTH);
  oneOf('approval', APPROVAL);
  oneOf('free_kind', FREE_KIND);
  oneOf('verified_by', VERIFIED_BY);

  // 애매하면 비워 두라고 스키마에 적어 뒀다. 비워 둔 것을 탓하지 않는다.
  // 다만 무엇이 비었는지는 알고 있어야 한다.
  if (doc.free_quota == null) warn(file, '무료 한도(free_quota)가 비어 있다');
  if (doc.card_required == null) warn(file, '카드 필요 여부(card_required)가 비어 있다');
  if (doc.verified_by === 'docs') warn(file, '아직 직접 발급받아 확인하지 않았다');
  if (!doc.verified_by) warn(file, '확인된 적이 없다 — 화면에 내보내지 않는다');

  // 근거 없이 적힌 숫자는 나중에 아무도 검증할 수 없다.
  if (doc.free_quota != null && !doc.sources && !doc.sources_note) {
    warn(file, `한도를 적었는데 근거(sources)가 없다`);
  }
}

function checkScenario({ file, id, doc }, apiIds) {
  for (const k of ['id', 'title', 'summary', 'needs']) {
    if (doc[k] === undefined) fail(file, `필수 항목 ${k} 가 없다`);
  }
  if (doc.id !== id) fail(file, `id(${doc.id})가 파일명(${id})과 다르다`);
  for (const n of doc.needs || []) {
    for (const a of [...(n.apis || []), n.pick].filter(Boolean)) {
      if (!apiIds.has(a)) fail(file, `없는 API 를 가리킨다: ${a}`);
    }
    if (n.pick && !n.why) warn(file, `${n.pick} 을 골라 놓고 이유(why)가 없다`);
  }
}

async function checkLinks(apis) {
  console.log('\n링크 확인 중…');
  for (const a of apis) {
    for (const key of ['signup_url', 'docs_url']) {
      const url = a[key];
      if (!url) continue;
      try {
        // HEAD 를 막아 두는 사이트가 있어 GET 으로 본다.
        const res = await fetch(url, { redirect: 'follow' });
        if (!res.ok) fail(`${a.id}.yaml`, `${key} 가 HTTP ${res.status} — ${url}`);
        else if (new URL(res.url).pathname !== new URL(url).pathname) {
          warn(`${a.id}.yaml`, `${key} 가 다른 곳으로 넘어간다 → ${res.url}`);
        }
      } catch (err) {
        /*
         * 404 는 확실한 증거지만 네트워크 실패는 아니다. 프록시, 봇 차단,
         * 일시적인 장애일 수 있다. t.me/BotFather 가 실제로 그랬다 —
         * 브라우저에서는 멀쩡히 열리는데 여기서는 fetch 가 실패했다.
         * 이걸로 빌드를 세우면 멀쩡한 링크를 지우게 된다. 알리기만 한다.
         */
        warn(`${a.id}.yaml`, `${key} 에 닿지 못했다 (${String(err.message || err)}) — 직접 열어 확인할 것: ${url}`);
      }
    }
  }
}

const apiDocs = loadDir('apis');
const scenarioDocs = loadDir('scenarios');
const apiIds = new Set(apiDocs.map(d => d.id));

apiDocs.forEach(checkApi);
scenarioDocs.forEach(d => checkScenario(d, apiIds));

const apis = apiDocs.map(d => d.doc);
if (CHECK_LINKS) await checkLinks(apis);

for (const w of warnings) console.warn(`  ! ${w}`);
if (problems.length) {
  console.error('\n빌드를 세운다:');
  for (const p of problems) console.error(`  × ${p}`);
  process.exit(1);
}

/*
 * 확인된 적 없는 항목은 내보내지 않는다. 모른다고 말하는 가이드는 쓸모가
 * 있지만, 틀리게 말하는 가이드는 없느니만 못하다.
 */
const published = apis.filter(a => a.verified_by);
const dropped = apis.length - published.length;

const out = {
  built_at: new Date().toISOString().slice(0, 10),
  categories: CATEGORIES,
  apis: published,
  scenarios: scenarioDocs.map(d => d.doc),
};
writeFileSync(join(ROOT, 'public', 'data.json'), JSON.stringify(out, null, 1));

const signup = published.filter(a => a.verified_by === 'signup').length;
console.log(`\n완료 — API ${published.length}건${dropped ? ` (미확인 ${dropped}건 제외)` : ''}, 시나리오 ${out.scenarios.length}건`);
console.log(`직접 발급으로 확인된 것: ${signup}/${published.length}건. 이 숫자가 이 사이트의 값어치다.`);
if (warnings.length) console.log(`경고 ${warnings.length}건 — docs/verify-checklist.md 참고`);
