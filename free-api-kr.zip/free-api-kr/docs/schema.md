# 데이터 스키마

API 하나가 `data/apis/<id>.yaml` 파일 하나다. 사람이 쓰고 사람이 읽는다.
PR 로 고칠 수 있어야 하므로 DB 가 아니라 텍스트 파일이다.

## 왜 이 필드들인가

"어떤 API 가 있나"를 알려주는 목록은 이미 넘친다. 사람들이 그런데도 일일이
찾아보는 이유는, 정작 궁금한 걸 그 목록들이 안 알려주기 때문이다.

> 이거 진짜 공짜인가 · 카드 넣어야 하나 · 발급에 얼마나 걸리나 · 한도가 충분한가

이 스키마는 API 를 설명하기 위한 게 아니라 **발급 마찰**을 기록하기 위한 것이다.
설명은 공식 문서가 더 잘한다. 마찰은 아무도 안 적어 둔다.

## 필드

| 필드 | 필수 | 설명 |
|---|---|---|
| `id` | ✔ | 파일명과 같게. 소문자 kebab-case |
| `name` | ✔ | 개발자가 부르는 이름 |
| `provider` | ✔ | 제공사 |
| `tasks` | ✔ | **분야별로 묶는다.** 아래 참고 |
| `keywords` | | 이름에 안 들어가지만 사람들이 검색할 만한 말 |
| `kind` | | `api`(기본) 또는 `catalog`. 아래 참고 |
| `signup_url` | ✔ | **발급 화면 직링크.** 회사 홈페이지가 아니다 |
| `docs_url` | ✔ | 문서 |
| `auth` | ✔ | `apiKey` / `oauth2` / `token` / `none` |
| `card_required` | ✔ | 가입·발급에 결제수단 등록이 필요한가 |
| `approval` | ✔ | `instant` / `review` / `waitlist` |
| `free_kind` | ✔ | `perpetual` / `trial` / `credit` |
| `free_quota` | ✔ | **원문 그대로 인용.** 계산하거나 환산하지 않는다 |
| `rate_limit` | | 초당·분당 제한 |
| `korea_ok` | ✔ | 한국에서 가입·사용 가능한가 |
| `korean_ui` | ✔ | 콘솔이나 문서가 한국어인가 |
| `individual_ok` | ✔ | 사업자등록번호 없이 개인이 발급받을 수 있는가 |
| `gotchas` | | 해봐야 아는 함정. 이 사이트의 알맹이다 |
| `verified_at` | ✔ | 마지막으로 확인한 날짜 (`YYYY-MM-DD`) 또는 `null` |
| `verified_by` | ✔ | `signup`(직접 발급) / `docs`(문서만 봄) / `null`(미확인) |
| `sources` | | 값의 근거가 된 URL. 공식 문서를 확인했을 때 적는다 |
| `sources_note` | | 공식 문서를 확인하지 못했을 때 그 사정을 적는다 |
| `free_quota_detail` | | 한도가 API 별로 갈릴 때 항목별로 적는다 |
| `card_note` | | `card_required` 가 단순 참/거짓으로 안 끝날 때 |
| `approval_note` | | 승인 조건이 데이터셋·상품마다 갈릴 때 |

`sources` 가 붙은 값과 안 붙은 값은 신뢰도가 다르다. 화면에서 구분할지는
나중에 정하더라도, 데이터에는 남겨 둔다. 근거 없이 적힌 숫자는 나중에
누구도 검증할 수 없다.

## 값의 의미

### `tasks` — 분야별로 묶는다

```yaml
tasks:
  지도·위치·주소: [지도 렌더링, 좌표→주소 변환, 장소 검색, 길찾기]
  로그인·인증: [소셜 로그인]
```

**`categories` 는 따로 적지 않는다.** 여기 키에서 자동으로 나온다.

예전엔 둘을 따로 적었는데, 그러면 어느 작업이 어느 분야 것인지 데이터가 모른다.
카카오의 "카카오 로그인"이 지도 분야 칩으로 뜨고, 네이버클라우드의 "SMS 발송"이
지도를 보러 온 사람에게 보였다. 분야를 키로 두면 그 일이 안 생긴다.
출처가 하나면 둘이 어긋날 수도 없다.

### `kind: catalog` — 포털은 API 가 아니다

공공데이터포털처럼 수천 개 데이터셋을 담은 곳은 `tasks` 로 못 덮는다.
무엇을 적어도 빠지는 게 생긴다. 실제로 "의료"로 검색했을 때 0건이 나왔다 —
거기엔 병원 오픈API 만 179건이 있는데도.

그래서 열거하지 않는다. 대신 그 포털이 **실제로 쓰는 분류체계**를 `covers` 에
담고, 검색은 포털로 넘긴다.

```yaml
kind: catalog
search_url_template: "https://…?keyword={q}&dType=API"   # {q} 자리 필수
covers:
  - { domain: 보건의료, keywords: [의료, 병원, 약국, 진료, 건강] }
  - { domain: 교통물류, keywords: [교통, 버스, 지하철, 주차] }
```

`domain` 은 포털 화면에 실제로 있는 이름을 그대로 쓴다. 우리가 지어내면
사용자가 포털에 가서 그 이름을 못 찾는다. `keywords` 는 그 분야를 가리키는
말들이다 — 사용자는 "보건의료"라고 치지 않고 "병원"이라고 친다.


### `free_kind` — "무료"의 실체

셋을 섞으면 안 된다. 사용자가 가장 크게 배신감을 느끼는 지점이다.

- `perpetual` — 영구 무료 구간이 있다. 한도 안에서는 계속 공짜다
- `trial` — 기간이 끝나면 끊긴다
- `credit` — 크레딧을 다 쓰면 과금된다. **무료가 아니라 유예다**

### `approval` — 발급까지 걸리는 시간

- `instant` — 가입 즉시 키가 나온다
- `review` — 사람이 심사한다. `approval_note` 에 대략의 소요를 적는다
- `waitlist` — 대기열. 언제 될지 모른다

### `card_required` — 가장 많이 묻는 것

무료라고 써 놓고 카드를 요구하는 곳이 흔하다. 이 필드 하나로 필터가 되면
사이트의 절반은 성공한 것이다. **애매하면 `null` 로 두고 확인 대상에 올린다.
추측해서 `false` 로 적으면 사용자를 카드 등록 화면으로 보내게 된다.**

### `free_quota` — 인용만 한다

```yaml
free_quota: "일 300,000회"        # 좋다. 원문 그대로다
free_quota: "하루 30만 번이니 넉넉" # 나쁘다. 해석이 붙었다
```

혜택나침반에서 지원 금액을 요약문에서 뽑기만 하고 계산하지 않았던 것과 같다.
해석을 붙이는 순간 틀리고, 틀리면 이 사이트를 쓸 이유가 없어진다.

### `verified_by` — 신뢰의 근거

- `signup` — **직접 발급받아 봤다.** 이 데이터만 진짜다
- `docs` — 공식 문서를 읽고 적었다. 카드 요구·승인 대기·개인 가입 가능 여부는
  문서에 안 적혀 있거나 현실과 다른 경우가 많다. 참고용이다
- `null` — 아직 아무것도 확인 안 했다. 화면에 내보내지 않는다

문서만 보고 채운 데이터는 반드시 틀린다. `signup` 으로 채워진 항목의 수가
이 사이트의 실제 가치다.

## 카테고리

`categories` 는 이 목록에서만 고른다.

```
지도·위치·주소
로그인·인증
결제·정산
알림
AI·LLM
이미지·미디어
데이터
개발 인프라
검색·번역
커뮤니케이션
```

## 예시

```yaml
id: example-api
name: 예시 API
provider: 예시사
categories: [데이터]
tasks: [무언가 조회]

signup_url: https://example.com/console/keys
docs_url: https://example.com/docs

auth: apiKey
card_required: false
approval: instant
free_kind: perpetual
free_quota: "일 1,000회"
rate_limit: "초당 5회"

korea_ok: true
korean_ui: false
individual_ok: true

gotchas:
  - 키 발급 후 반영까지 10분 정도 걸린다

verified_at: 2026-09-04
verified_by: signup
```
