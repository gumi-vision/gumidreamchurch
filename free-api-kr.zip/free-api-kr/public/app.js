/* ============================================================
   화면.

   데이터가 수백 건이라 통째로 받아 브라우저에서 거른다. 서버 왕복이 없다.
   ============================================================ */

const $ = (s) => document.querySelector(s);
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
};
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// yaml 에서 **굵게** 를 쓰는 곳이 있다. 함정 문구에서 한 군데 강조하려는 용도다.
const bold = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

const state = { q: '', category: null, topic: null, scenario: null, data: null };

const isCatalog = (a) => a.kind === 'catalog';
const searchUrl = (a, q) => a.search_url_template.replace('{q}', encodeURIComponent(q));

/* 카탈로그 안에서 이 말이 어느 분야에 걸리는지. 없으면 null. */
function coverFor(a, q) {
  if (!isCatalog(a) || !q) return null;
  const t = q.toLowerCase();
  return (a.covers || []).find(c =>
    c.domain.toLowerCase().includes(t) || c.keywords.some(k => k.toLowerCase().includes(t))) || null;
}

const APPROVAL_LABEL = { instant: '즉시 발급', review: '심사 있음', waitlist: '대기열' };
const FREE_LABEL = {
  perpetual: { text: '영구 무료 구간', cls: '' },
  trial: { text: '체험 기간만', cls: 'warn' },
  credit: { text: '크레딧 소진형', cls: 'warn' },
};

/* ---------- 카드 ---------- */

function apiCard(a) {
  const card = el('article', 'api');

  card.append(el('div', 'api-head',
    `<b>${esc(a.name)}</b><span class="provider">${esc(a.provider)}</span>`));

  // 이걸로 뭘 할 수 있는지. 분야를 골랐으면 그 분야 것만 보여준다.
  // 지도를 보러 온 사람에게 "SMS 발송"을 보여줄 이유가 없다.
  if (!isCatalog(a)) {
    const t = state.category
      ? (a.tasks || {})[state.category] || []
      : Object.values(a.tasks || {}).flat();
    if (t.length) card.append(el('p', 'tasks', t.map(esc).join(' · ')));
  }

  // 한도. 모르면 모른다고 말한다. 지어내지 않는다.
  const quota = el('p', 'quota', a.free_quota
    ? esc(a.free_quota)
    : '<span class="unknown">무료 한도 미확인 — 발급 화면에서 확인하세요</span>');
  if (a.free_quota_detail?.length) {
    quota.append(el('ul', null, a.free_quota_detail.map(d => `<li>${esc(d)}</li>`).join('')));
  }
  card.append(quota);

  const badges = el('div', 'badges');
  const badge = (text, cls) => badges.append(el('span', `badge ${cls || ''}`, esc(text)));

  if (a.card_required === false) badge('카드 등록 불필요');
  else if (a.card_required === true) badge('결제수단 등록 필요', 'stop');
  else badge('카드 필요 여부 미확인', 'warn');

  badge(APPROVAL_LABEL[a.approval] || a.approval, a.approval === 'instant' ? '' : 'warn');

  const f = FREE_LABEL[a.free_kind];
  if (f) badge(f.text, f.cls);
  if (a.individual_ok === false) badge('사업자 필요', 'stop');
  if (a.korean_ui) badge('한국어');
  card.append(badges);

  const actions = el('div', 'api-actions');
  actions.append(el('a', 'btn', '발급받기'), el('a', 'btn ghost', '문서'));
  actions.children[0].href = a.signup_url;
  actions.children[1].href = a.docs_url;
  for (const link of actions.children) { link.target = '_blank'; link.rel = 'noopener'; }
  card.append(actions);

  /*
   * 카탈로그는 안에 수천 건이 들어 있다. 우리가 그걸 다 열거할 수는 없고,
   * 해서도 안 된다. 포털이 쓰는 분류를 그대로 보여주고 검색으로 넘긴다.
   */
  if (isCatalog(a)) {
    const hit = coverFor(a, state.q) || (state.topic && a.covers.find(c => c.domain === state.topic));
    const box = el('div', 'covers');
    box.append(el('p', 'covers-label',
      hit ? `‘${esc(hit.domain)}’ 분야로 바로 가기` : '안에 담긴 분야 — 눌러서 그 분야만 보기'));
    const chips = el('div', 'chips');
    for (const c of a.covers) {
      const link = el('a', 'chip' + (hit && hit.domain === c.domain ? ' on' : ''), esc(c.domain));
      link.href = searchUrl(a, c.domain);
      link.target = '_blank'; link.rel = 'noopener';
      chips.append(link);
    }
    box.append(chips);
    if (state.q) {
      const direct = el('a', 'btn ghost wide', `공공데이터포털에서 ‘${esc(state.q)}’ 검색`);
      direct.href = searchUrl(a, state.q);
      direct.target = '_blank'; direct.rel = 'noopener';
      box.append(direct);
    }
    card.append(box);
  }

  // 함정. 해본 사람만 아는 것들이고, 이 사이트에서 유일하게 베낄 수 없는 부분이다.
  if (a.gotchas?.length) {
    const d = el('details');
    d.append(el('summary', null, `알아둘 것 ${a.gotchas.length}가지`));
    d.append(el('ul', null, a.gotchas.map(g => `<li>${bold(g)}</li>`).join('')));
    card.append(d);
  }

  // 언제 확인한 정보인지 밝히지 않으면 거짓말이 된다.
  const how = a.verified_by === 'signup' ? '직접 발급해 확인' : '공식 문서 기준';
  const soft = a.sources_note ? ' · 공식 확인 안 됨' : '';
  card.append(el('p', 'verified', `${esc(a.verified_at || '확인 날짜 없음')} ${esc(how)}${soft}`));

  return card;
}

/* ---------- 목록 ---------- */

function matches(a) {
  if ($('#f-nocard').checked && a.card_required !== false) return false;
  if ($('#f-instant').checked && a.approval !== 'instant') return false;
  if ($('#f-perpetual').checked && a.free_kind !== 'perpetual') return false;
  if ($('#f-individual').checked && a.individual_ok !== true) return false;
  if (state.category && !(a.categories || []).includes(state.category)) return false;
  if (state.topic && !topicsOf(a).includes(state.topic)) return false;

  if (state.q) {
    // 카탈로그는 담고 있는 분야의 말로도 걸려야 한다. "의료"가 안 걸리던 이유다.
    const hay = [
      a.name, a.provider, ...(a.categories || []), ...(a.keywords || []),
      ...Object.values(a.tasks || {}).flat(),
      ...(a.covers || []).flatMap(c => [c.domain, ...c.keywords]),
    ].join(' ').toLowerCase();
    if (!hay.includes(state.q.toLowerCase())) return false;
  }
  return true;
}

function renderScenario(s) {
  const wrap = el('div');
  wrap.append(el('h2', null, `${esc(s.title)} — 필요한 것`));
  wrap.append(el('p', 'need-summary', esc(s.summary)));

  for (const n of s.needs || []) {
    const box = el('div', 'need');
    box.append(el('p', 'task', esc(n.task)));
    if (n.why) box.append(el('p', 'why', esc(n.why)));
    const api = state.data.apis.find(a => a.id === n.pick);
    if (api) box.append(apiCard(api));
    else box.append(el('p', 'why', '(아직 확인되지 않은 API 라 표시하지 않습니다)'));
    wrap.append(box);
  }
  if (s.note) wrap.append(el('div', 'note', esc(s.note.trim())));
  return wrap;
}

function render() {
  const results = $('#results');
  results.textContent = '';

  if (state.scenario) {
    const s = state.data.scenarios.find(x => x.id === state.scenario);
    $('#count').textContent = '';
    results.append(renderScenario(s));
    return;
  }

  const list = state.data.apis.filter(matches);
  // 카드 없이 바로 되는 것을 앞으로 뺀다. 대부분 그걸 찾아서 온다.
  list.sort((a, b) => (a.card_required === false ? 0 : 1) - (b.card_required === false ? 0 : 1));

  $('#count').textContent = `${list.length}건`;
  if (!list.length) {
    results.append(emptyState());
    return;
  }
  for (const a of list) results.append(apiCard(a));

  /*
   * 필터에 가려진 게 있으면 몇 건인지 알린다. "문자"로 검색하면 카드가 필요한
   * 것들이 조용히 빠지는데, 그러면 사용자는 문자에 카드가 필요하다는 사실
   * 자체를 못 배운다. 없는 것과 가려진 것은 다르다.
   */
  const hidden = hiddenCount(list.length);
  if (hidden) {
    const p = el('p', 'hidden-note');
    p.append(el('span', null, `필터에 가려진 것이 ${hidden}건 더 있습니다.`));
    const btn = el('button', 'linkish', '모두 보기');
    btn.onclick = () => {
      for (const id of ['f-nocard', 'f-instant', 'f-perpetual', 'f-individual']) $('#' + id).checked = false;
      render();
    };
    p.append(btn);
    results.append(p);
  }
}

/*
 * 빈 화면으로 돌려보내지 않는다. 우리가 수록하지 않은 주제라도 공공데이터포털
 * 안에는 있을 수 있다. 실제로 "의료"가 그랬다 — 우리는 0건인데 거기엔 179건이었다.
 */
/*
 * 왜 비었는지 말해 준다. "알림" 분야를 고르면 주제 칩은 뜨는데 결과가 0건인데,
 * 켜져 있는 필터 때문이라는 걸 사용자는 알 수 없다. 끄면 몇 건이 나오는지까지 보여준다.
 */
/* 필터를 전부 끄면 몇 건이 더 나오는지. 검색어와 분야 선택은 그대로 둔다. */
function hiddenCount(shown) {
  const ids = ['f-nocard', 'f-instant', 'f-perpetual', 'f-individual'];
  const was = ids.map(id => $('#' + id).checked);
  if (!was.some(Boolean)) return 0;

  for (const id of ids) $('#' + id).checked = false;
  const all = state.data.apis.filter(matches).length;
  ids.forEach((id, i) => { $('#' + id).checked = was[i]; });
  return all - shown;
}

function blockingFilter() {
  const known = [
    ['f-nocard', '카드 등록 불필요'], ['f-instant', '즉시 발급'],
    ['f-perpetual', '영구 무료'], ['f-individual', '개인 가입 가능'],
  ];
  for (const [id, label] of known) {
    const box = $('#' + id);
    if (!box.checked) continue;
    box.checked = false;
    const n = state.data.apis.filter(matches).length;
    box.checked = true;
    if (n) return { id, label, n };
  }
  return null;
}

function emptyState() {
  const box = el('div', 'empty');
  const cat = state.data.apis.find(a => isCatalog(a) && a.search_url_template);
  const blocked = blockingFilter();

  if (blocked) {
    box.append(el('p', null, '조건에 맞는 것이 없습니다.'));
    box.append(el('p', 'muted',
      `‘${esc(blocked.label)}’ 를 끄면 ${blocked.n}건 나옵니다.`));
    const btn = el('button', 'btn', `‘${esc(blocked.label)}’ 끄기`);
    btn.onclick = () => { $('#' + blocked.id).checked = false; render(); };
    box.append(btn);
    return box;
  }

  if (state.q && cat) {
    box.append(el('p', null, `수록된 것 중에는 ‘${esc(state.q)}’ 에 맞는 게 없습니다.`));
    box.append(el('p', 'muted', '다만 공공데이터포털 안에는 있을 수 있습니다. 정부·지자체 데이터라면 대개 거기 있습니다.'));
    const go = el('a', 'btn', `공공데이터포털에서 ‘${esc(state.q)}’ 검색`);
    go.href = searchUrl(cat, state.q);
    go.target = '_blank'; go.rel = 'noopener';
    box.append(go);
  } else {
    box.append(el('p', null, '조건에 맞는 것이 없습니다.'));
    box.append(el('p', 'muted', '필터를 풀거나 다른 분야를 골라 보세요.'));
  }
  return box;
}

/* ---------- 시작 ---------- */

/*
 * 고른 분야 안에서 더 좁힐 주제들. 지금은 카탈로그의 분류가 유일한 출처다.
 * "데이터"를 고르면 보건의료·교통물류… 16개가 나온다. 타이핑하지 않아도 된다.
 */
function topicsOf(a) {
  if (!state.category) return [];
  // 카탈로그는 담고 있는 분야가 곧 주제다. 일반 API 는 그 분야에서 할 수 있는 일.
  if (isCatalog(a)) return (a.covers || []).map(c => c.domain);
  return (a.tasks || {})[state.category] || [];
}

function renderTopics() {
  const wrap = $('#topic-wrap');
  const list = $('#topic-list');
  list.textContent = '';

  const inCat = state.data.apis.filter(a =>
    (a.categories || []).includes(state.category));
  const domains = [...new Set(inCat.flatMap(topicsOf))];

  // 분야를 아직 안 골랐으면 감춘다. 처음부터 다 늘어놓으면 그게 더 어지럽다.
  wrap.hidden = !state.category || !domains.length;
  if (wrap.hidden) return;

  for (const d of domains) {
    const b = el('button', 'chip', esc(d));
    b.setAttribute('aria-pressed', String(state.topic === d));
    b.onclick = () => {
      state.topic = state.topic === d ? null : d;
      for (const x of list.children) x.setAttribute('aria-pressed', String(x.textContent === state.topic));
      render();
    };
    list.append(b);
  }
}

function setScenario(id) {
  state.scenario = state.scenario === id ? null : id;
  for (const b of document.querySelectorAll('.scenario')) {
    b.setAttribute('aria-pressed', String(b.dataset.id === state.scenario));
  }
  $('#browse').hidden = !!state.scenario;
  render();
}

async function init() {
  const res = await fetch('/data.json');
  state.data = await res.json();

  const sList = $('#scenario-list');
  for (const s of state.data.scenarios) {
    const b = el('button', 'scenario', `<b>${esc(s.title)}</b><span>${esc(s.summary)}</span>`);
    b.dataset.id = s.id;
    b.setAttribute('aria-pressed', 'false');
    b.onclick = () => setScenario(s.id);
    sList.append(b);
  }

  const cList = $('#category-list');
  const used = new Set(state.data.apis.flatMap(a => a.categories || []));
  for (const c of state.data.categories.filter(c => used.has(c))) {
    const b = el('button', 'chip', esc(c));
    b.setAttribute('aria-pressed', 'false');
    b.onclick = () => {
      state.category = state.category === c ? null : c;
      state.topic = null;
      for (const x of cList.children) x.setAttribute('aria-pressed', String(x.textContent === state.category));
      renderTopics();
      render();
    };
    cList.append(b);
  }

  $('#q').oninput = (e) => {
    state.q = e.target.value.trim();
    if (state.q && state.scenario) setScenario(state.scenario);  // 검색하면 시나리오에서 빠져나온다
    else render();
  };
  for (const id of ['f-nocard', 'f-instant', 'f-perpetual', 'f-individual']) {
    $('#' + id).onchange = render;
  }

  const signup = state.data.apis.filter(a => a.verified_by === 'signup').length;
  $('#freshness').textContent =
    `${state.data.apis.length}건 수록 · 그중 ${signup}건은 직접 발급해 확인 · ${state.data.built_at} 기준`;

  render();
}

init().catch(err => {
  $('#results').append(el('p', 'empty', '데이터를 불러오지 못했습니다. npm run build 를 먼저 실행하세요.'));
  console.error(err);
});
